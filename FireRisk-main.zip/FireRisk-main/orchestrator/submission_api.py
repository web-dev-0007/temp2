import os
import sys
import json
import logging
from pathlib import Path
from typing import Dict, Any, List, Optional
import pandas as pd
from pydantic import BaseModel, Field
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

# Ensure project root in sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from schemas.contracts import (
    AgentVerdict,
    BusinessImpactVerdict,
    LOBType,
    ExecutionMode,
    RiskTier
)
from orchestrator.graph import run_underwriting_workflow
from agents.poc_fire_risk_detector import rank_fire_prone_areas
from data_factory.noaa_ingestor import NOAAIngestor
from config.loader import load_settings

logger = logging.getLogger("SubmissionAPI")

app = FastAPI(
    title="Fire Risk AI — Underwriting & Portfolio Monitoring API",
    version="1.0.0",
    description="Multi-agent P&C fire peril underwriting platform powered by classical ML and deterministic decision rules."
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

SAMPLES_DIR = ROOT_DIR / "data_factory" / "generated_samples"


# -------------------------------------------------------------------------
# Request & Response Models
# -------------------------------------------------------------------------
class EvaluationRequest(BaseModel):
    property_id: Optional[str] = Field(default="PROP_CUSTOM", description="Unique policy or property ID")
    name: Optional[str] = Field(default="Commercial Insured", description="Property or insured business name")
    lob: LOBType = Field(default=LOBType.COMMERCIAL, description="Line of business: COMMERCIAL or RESIDENTIAL")
    execution_mode: ExecutionMode = Field(default=ExecutionMode.SUBMISSION_RENEWAL, description="Execution mode")
    enable_hard_veto: bool = Field(default=True, description="Enable regulatory Hard Veto override (floor >= 75.0)")
    baseline_score: Optional[float] = Field(default=None, description="Prior baseline hazard score for active monitoring delta")
    archetype_id: Optional[str] = Field(default=None, description="Load pre-packaged canonical archetype (1-4)")
    
    # Custom payload overrides (used if archetype_id is None)
    acord_payload: Optional[Dict[str, Any]] = None
    website_scrape_text: Optional[str] = None
    iot_telemetry: Optional[List[Dict[str, Any]]] = None
    noaa_series: Optional[List[Dict[str, Any]]] = None
    news_articles: Optional[List[Dict[str, Any]]] = None
    raws_10hr_fuel_moisture_pct: Optional[float] = 12.0


class EvaluationResponse(BaseModel):
    property_id: str
    lob: LOBType
    execution_mode: ExecutionMode
    final_hazard_score: float
    final_risk_tier: RiskTier
    aggregate_confidence: float
    veto_triggered: bool
    score_delta_from_baseline: Optional[float] = None
    risk_avoidance_action: str
    risk_pricing_signal: str
    reserving_trigger: str
    agent_verdicts: Dict[str, Any]
    audit_trail: List[str]
    execution_logs: List[str]
    executive_memo: Optional[Dict[str, Any]] = None


# -------------------------------------------------------------------------
# Archetype Helper Loader
# -------------------------------------------------------------------------
def load_archetype_payload(archetype_key: str) -> Dict[str, Any]:
    key_mapping = {
        "1": "archetype_1_benign",
        "archetype_1": "archetype_1_benign",
        "archetype_1_benign": "archetype_1_benign",
        "2": "archetype_2_wui_surge",
        "archetype_2": "archetype_2_wui_surge",
        "archetype_2_wui_surge": "archetype_2_wui_surge",
        "3": "archetype_3_internal_fault",
        "archetype_3": "archetype_3_internal_fault",
        "archetype_3_internal_fault": "archetype_3_internal_fault",
        "4": "archetype_4_midterm",
        "archetype_4": "archetype_4_midterm",
        "archetype_4_midterm": "archetype_4_midterm",
    }
    prefix = key_mapping.get(archetype_key.lower())
    if not prefix:
        raise HTTPException(status_code=404, detail=f"Archetype '{archetype_key}' not found. Choose 1, 2, 3, or 4.")

    json_path = SAMPLES_DIR / f"{prefix}.json"
    telemetry_path = SAMPLES_DIR / f"{prefix}_telemetry.csv"
    noaa_path = SAMPLES_DIR / f"{prefix}_noaa.csv"

    if not json_path.exists():
        raise HTTPException(status_code=500, detail=f"Archetype metadata file missing: {json_path.name}")

    with open(json_path, "r", encoding="utf-8") as f:
        payload = json.load(f)

    if telemetry_path.exists():
        payload["iot_telemetry"] = pd.read_csv(telemetry_path)
    if noaa_path.exists():
        payload["noaa_series"] = pd.read_csv(noaa_path)

    return payload


# -------------------------------------------------------------------------
# Endpoints
# -------------------------------------------------------------------------
@app.get("/")
def get_root():
    return {
        "service": "Fire Risk AI — Multi-Agent Underwriting Platform",
        "status": "OPERATIONAL",
        "version": "1.0.0",
        "documentation": "/docs",
        "endpoints": [
            "GET /v1/health",
            "GET /v1/archetypes",
            "GET /v1/archetypes/{id}",
            "GET /v1/hotspots/california",
            "POST /v1/evaluate"
        ]
    }


@app.get("/v1/health")
def get_health():
    settings = load_settings()
    xgb_path = ROOT_DIR / settings.get("ml_models_config", {}).get("sensor_classifier_xgb_path", "models/sensor_classifier_xgb.json")
    iso_path = ROOT_DIR / settings.get("ml_models_config", {}).get("isolation_forest_path", "models/iso_forest.joblib")

    return {
        "status": "HEALTHY",
        "python_version": sys.version.split()[0],
        "ml_engine": {
            "huber_regressor": "ACTIVE (Scikit-Learn)",
            "isolation_forest_status": "LOADED" if iso_path.exists() else "HEURISTIC_FALLBACK (Huber Residual)",
            "sensor_classifier_status": "LOADED" if xgb_path.exists() else "HEURISTIC_FALLBACK (EN54 Calibration)"
        },
        "gemini_router": {
            "primary_complex": settings.get("gemini_config", {}).get("primary_complex_model", "gemini-3.8-flash"),
            "secondary_complex": settings.get("gemini_config", {}).get("secondary_complex_model", "gemini-3.6-flash"),
            "lite_model": settings.get("gemini_config", {}).get("lite_model", "gemini-3.5-flash-lite")
        }
    }


@app.get("/v1/archetypes")
def list_archetypes():
    return {
        "archetypes": [
            {
                "id": "1",
                "code": "ARCHETYPE_1_BENIGN_BASELINE",
                "name": "Pacific Harbor Logistics — Modern Coastal Distribution",
                "lob": "COMMERCIAL",
                "description": "Class 4 Masonry built in 2018 with 100% NFPA 13 sprinkler. Verified aerosol nuisance false-alarm rejection.",
                "expected_tier": "LOW",
                "expected_verdict": "AUTO_BIND_ELIGIBLE (-10% rate credit)"
            },
            {
                "id": "2",
                "code": "ARCHETYPE_2_WUI_MACRO_SURGE",
                "name": "Pine Ridge Canyon Residence — WUI Wildfire Aridity Surge",
                "lob": "RESIDENTIAL",
                "description": "1988 Frame home with untreated Wood Shake roof in canyon. 4.8% fuel moisture + Red Flag fire weather.",
                "expected_tier": "HIGH",
                "expected_verdict": "PRE_BIND_DECLINE_HOLD (+100% distressed surcharge)"
            },
            {
                "id": "3",
                "code": "ARCHETYPE_3_INTERNAL_DIVERGENT_FAULT",
                "name": "Apex Storage & Supply — Undeclared Battery Assembly & Fault",
                "lob": "COMMERCIAL",
                "description": "Deceptive ACORD declaration vs. lithium-ion battery welding website text + OSHA citations. Huber Z=17.57 thermal divergence.",
                "expected_tier": "HIGH",
                "expected_verdict": "HARD_VETO_TRIGGERED (Score >= 75.0, 2.0x reserve step up)"
            },
            {
                "id": "4",
                "code": "ARCHETYPE_4_MIDTERM_DEGRADATION",
                "name": "Valley Oak Craft Roasters — Active Monitoring Degradation",
                "lob": "COMMERCIAL",
                "description": "Low baseline (S=22.0) degrading midterm due to municipal water main rupture and electrical grid transients.",
                "expected_tier": "HIGH",
                "expected_verdict": "EMERGENCY_LOSS_CONTROL_DISPATCH (ΔS >= +15.0, 2.0x reserve step up)"
            }
        ]
    }


@app.get("/v1/archetypes/{archetype_id}")
def get_archetype_details(archetype_id: str):
    payload = load_archetype_payload(archetype_id)
    # Serialize DataFrames for JSON response
    telemetry_df = payload.get("iot_telemetry")
    noaa_df = payload.get("noaa_series")

    out = {**payload}
    if isinstance(telemetry_df, pd.DataFrame):
        out["iot_telemetry_rows"] = len(telemetry_df)
        out["iot_telemetry_summary"] = telemetry_df.describe().to_dict()
        del out["iot_telemetry"]
    if isinstance(noaa_df, pd.DataFrame):
        out["noaa_series_rows"] = len(noaa_df)
        del out["noaa_series"]

    return out


@app.get("/v1/hotspots/california")
def get_california_hotspots(snapshot_date: Optional[str] = Query(default=None, description="Date in YYYY-MM-DD format (e.g. 2026-10-06)")):
    try:
        ingestor = NOAAIngestor()
        df = ingestor.load_noaa_series()
    except Exception as e:
        logger.warning(f"Could not load raw NOAA ASOS series: {e}. Using sample NOAA stations.")
        sample_path = SAMPLES_DIR / "archetype_2_wui_surge_noaa.csv"
        if sample_path.exists():
            df = pd.read_csv(sample_path)
            df["station"] = "UKI"
        else:
            raise HTTPException(status_code=500, detail="NOAA ASOS data unavailable.")

    # Filter by date if provided
    if snapshot_date:
        df["date_str"] = pd.to_datetime(df["timestamp"]).dt.strftime("%Y-%m-%d")
        df_filtered = df[df["date_str"] == snapshot_date]
        if df_filtered.empty:
            df_filtered = df.tail(100)  # fallback to latest observations
    else:
        # Default to latest observation per station
        df_filtered = df.groupby("station").last().reset_index()

    # Rank fire-prone areas
    ranked = rank_fire_prone_areas(df_filtered)

    records = []
    for _, row in ranked.iterrows():
        records.append({
            "rank": int(row.get("rank", 1)),
            "station": str(row.get("station", "UNKNOWN")),
            "fire_hazard_index": float(row.get("fire_hazard_index", 0.0)),
            "temp_c": float(row.get("temp_c", 0.0)),
            "rel_humidity_pct": float(row.get("rel_humidity_pct", 0.0)),
            "wind_gust_mph": float(row.get("wind_gust_mph", 0.0)),
            "vpd_kpa": float(row.get("vpd_kpa", 0.0)),
            "fosberg_fwi": float(row.get("fosberg_fwi", 0.0)),
            "drought_kbdi_index": float(row.get("drought_kbdi_index", 0.0)),
            "red_flag_condition": bool(row.get("red_flag_condition", False))
        })

    return {
        "snapshot_date": snapshot_date or "LATEST_AVAILABLE",
        "station_count": len(records),
        "rankings": records
    }


@app.post("/v1/evaluate", response_model=EvaluationResponse)
def evaluate_submission(req: EvaluationRequest):
    # 1. Load payload from pre-packaged archetype if ID provided
    if req.archetype_id:
        payload = load_archetype_payload(req.archetype_id)
        if req.execution_mode == ExecutionMode.ACTIVE_MONITORING:
            payload["execution_mode"] = req.execution_mode.value
            payload["baseline_score"] = req.baseline_score or payload.get("baseline_score", 22.0)
    else:
        # Build payload from request body
        payload = {
            "property_id": req.property_id,
            "name": req.name,
            "lob": req.lob.value,
            "execution_mode": req.execution_mode.value,
            "baseline_score": req.baseline_score,
            "acord_payload": req.acord_payload or {},
            "website_scrape_text": req.website_scrape_text or "",
            "iot_telemetry": pd.DataFrame(req.iot_telemetry) if req.iot_telemetry else None,
            "noaa_series": pd.DataFrame(req.noaa_series) if req.noaa_series else None,
            "news_articles": req.news_articles or [],
            "raws_10hr_fuel_moisture_pct": req.raws_10hr_fuel_moisture_pct or 12.0
        }

    # 2. Invoke LangGraph StateGraph workflow
    try:
        state = run_underwriting_workflow(payload, enable_hard_veto=req.enable_hard_veto)
    except Exception as e:
        logger.error(f"Underwriting workflow failure: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Workflow execution error: {e}")

    final_verdict: BusinessImpactVerdict = state["final_business_verdict"]

    # 3. Format individual agent results
    agent_summaries = {}
    for key in ["iot_verdict", "occupancy_verdict", "news_verdict"]:
        v = state.get(key)
        if v:
            agent_summaries[v.agent_id] = {
                "hazard_score": v.hazard_score,
                "risk_tier": v.risk_tier.value,
                "confidence": v.confidence,
                "risk_drivers": [
                    {
                        "driver_code": d.driver_code,
                        "severity": d.severity.value,
                        "is_critical_veto_candidate": d.is_critical_veto_candidate,
                        "description": d.description
                    }
                    for d in v.risk_drivers
                ]
            }

    return EvaluationResponse(
        property_id=final_verdict.property_id,
        lob=final_verdict.lob,
        execution_mode=final_verdict.execution_mode,
        final_hazard_score=final_verdict.final_hazard_score,
        final_risk_tier=final_verdict.final_risk_tier,
        aggregate_confidence=final_verdict.aggregate_confidence,
        veto_triggered=final_verdict.veto_triggered,
        score_delta_from_baseline=final_verdict.score_delta_from_baseline,
        risk_avoidance_action=final_verdict.risk_avoidance_action,
        risk_pricing_signal=final_verdict.risk_pricing_signal,
        reserving_trigger=final_verdict.reserving_trigger,
        agent_verdicts=agent_summaries,
        audit_trail=final_verdict.audit_trail,
        execution_logs=state.get("execution_logs", []),
        executive_memo=final_verdict.executive_memo.model_dump() if final_verdict.executive_memo else None
    )

