import sys
import json
import warnings
from pathlib import Path
import pytest
import pandas as pd
import numpy as np

warnings.filterwarnings("ignore")

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

SAMPLES_DIR = ROOT_DIR / "data_factory" / "generated_samples"

from orchestrator.graph import run_underwriting_workflow
from schemas.contracts import RiskTier, ExecutionMode
from agents.poc_fire_risk_detector import fit_and_detect_residual_anomalies


def load_archetype(prefix: str) -> dict:
    json_path = SAMPLES_DIR / f"{prefix}.json"
    telemetry_path = SAMPLES_DIR / f"{prefix}_telemetry.csv"
    noaa_path = SAMPLES_DIR / f"{prefix}_noaa.csv"

    with open(json_path, "r", encoding="utf-8") as f:
        payload = json.load(f)

    payload["iot_telemetry"] = pd.read_csv(telemetry_path)
    payload["noaa_series"] = pd.read_csv(noaa_path)
    return payload


# -------------------------------------------------------------------------
# Test 1: Archetype 1 (Benign Commercial Warehouse Baseline)
# -------------------------------------------------------------------------
def test_archetype_1_benign_auto_bind():
    payload = load_archetype("archetype_1_benign")
    res = run_underwriting_workflow(payload, enable_hard_veto=True)
    verdict = res["final_business_verdict"]

    assert verdict.final_risk_tier == RiskTier.LOW
    assert verdict.final_hazard_score < 36.0
    assert not verdict.veto_triggered
    assert "AUTO_BIND_ELIGIBLE" in verdict.risk_avoidance_action
    assert "PREFERRED_TIER_CREDIT" in verdict.risk_pricing_signal
    assert verdict.executive_memo is not None
    summary_lower = verdict.executive_memo.executive_summary.lower()
    assert "bind" in summary_lower or "approved" in summary_lower or "eligible" in summary_lower


# -------------------------------------------------------------------------
# Test 2: Archetype 2 (WUI Wildfire Canyon Residence)
# -------------------------------------------------------------------------
def test_archetype_2_wui_wildfire_surge():
    payload = load_archetype("archetype_2_wui_surge")
    res = run_underwriting_workflow(payload, enable_hard_veto=True)
    verdict = res["final_business_verdict"]

    assert verdict.final_risk_tier == RiskTier.HIGH
    assert verdict.final_hazard_score >= 70.0
    assert not verdict.veto_triggered  # External macro surge, not internal defect
    assert "PRE_BIND_DECLINE_HOLD" in verdict.risk_avoidance_action
    assert "DISTRESSED_SURCHARGE" in verdict.risk_pricing_signal
    assert payload["raws_10hr_fuel_moisture_pct"] <= 6.0


# -------------------------------------------------------------------------
# Test 3: Archetype 3 (Internal Divergent Fault & Deception Hard Veto)
# -------------------------------------------------------------------------
def test_archetype_3_internal_fault_hard_veto():
    payload = load_archetype("archetype_3_internal_fault")
    res = run_underwriting_workflow(payload, enable_hard_veto=True)
    verdict = res["final_business_verdict"]

    # Hard Veto assertions
    assert verdict.final_risk_tier == RiskTier.HIGH
    assert verdict.final_hazard_score >= 75.0
    assert verdict.veto_triggered
    assert "PRE_BIND_DECLINE_HOLD" in verdict.risk_avoidance_action
    assert "ACUTE_STEP_UP" in verdict.reserving_trigger

    # Agent-level verification
    iot_v = res["iot_verdict"]
    occ_v = res["occupancy_verdict"]
    news_v = res["news_verdict"]

    assert any(d.driver_code == "DIVERGENT_INTERNAL_ANOMALY" for d in iot_v.risk_drivers)
    assert any(d.driver_code == "UNDECLARED_HIGH_HAZARD_OPERATIONS" for d in occ_v.risk_drivers)
    assert any("OSHA" in d.driver_code for d in news_v.risk_drivers)

    # Executive memo check
    assert verdict.executive_memo is not None
    summary_upper = verdict.executive_memo.executive_summary.upper()
    assert "DECLINE" in summary_upper or "HOLD" in summary_upper or "VETO" in summary_upper


# -------------------------------------------------------------------------
# Test 4: Archetype 4 (Active Monitoring Mid-Term Degradation)
# -------------------------------------------------------------------------
def test_archetype_4_active_monitoring_surge():
    payload = load_archetype("archetype_4_midterm")
    payload["execution_mode"] = "ACTIVE_MONITORING"
    payload["baseline_score"] = 22.0

    res = run_underwriting_workflow(payload, enable_hard_veto=True)
    verdict = res["final_business_verdict"]

    assert verdict.score_delta_from_baseline is not None
    assert verdict.score_delta_from_baseline >= 15.0
    assert "EMERGENCY_LOSS_CONTROL_DISPATCH" in verdict.risk_avoidance_action
    assert "ACUTE_STEP_UP" in verdict.reserving_trigger


# -------------------------------------------------------------------------
# Test 5: Hard Veto Toggle Override Logic
# -------------------------------------------------------------------------
def test_hard_veto_toggle_override():
    payload = load_archetype("archetype_3_internal_fault")

    # With Hard Veto enabled -> floor >= 75.0
    res_veto = run_underwriting_workflow(payload, enable_hard_veto=True)
    v_veto = res_veto["final_business_verdict"]
    assert v_veto.veto_triggered
    assert v_veto.final_hazard_score >= 75.0

    # With Hard Veto disabled -> standard weighted average without regulatory floor
    res_no_veto = run_underwriting_workflow(payload, enable_hard_veto=False)
    v_no_veto = res_no_veto["final_business_verdict"]
    assert not v_no_veto.veto_triggered


# -------------------------------------------------------------------------
# Test 6: Scikit-Learn HuberRegressor Transient Glitch Resistance
# -------------------------------------------------------------------------
def test_huber_regressor_outlier_resistance():
    df = load_archetype("archetype_1_benign")["iot_telemetry"].copy()
    
    # Baseline nominal
    res_clean = fit_and_detect_residual_anomalies(df["noaa_temp_c"], df["panel_temp_c"])
    assert not res_clean["is_divergent_fault"]
    assert res_clean["max_z_score"] < 3.0

    # Inject transient +30°C hardware sensor glitch at step 30
    df_glitch = df.copy()
    df_glitch.loc[30, "panel_temp_c"] += 30.0

    res_glitch = fit_and_detect_residual_anomalies(df_glitch["noaa_temp_c"], df_glitch["panel_temp_c"])
    # Huber slope beta should remain stable (resistant to leverage points)
    assert abs(res_glitch["beta"] - res_clean["beta"]) < 0.20
