import os
import logging
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field

from data_factory.llm_client import GeminiModelRouter

logger = logging.getLogger("SyntheticOccupancyGen")


class SprinklerDetails(BaseModel):
    installed: bool = Field(description="Whether automatic fire sprinklers are installed")
    standard: str = Field(description="e.g., 'NFPA 13 Wet Pipe', 'None', etc.")
    coverage_pct: int = Field(description="0 to 100 percentage coverage")
    annual_cert_status: str = Field(description="e.g., 'CURRENT_VERIFIED', 'EXPIRED_DEFICIENT', 'N/A'")


class AlarmDetails(BaseModel):
    installed: bool = Field(description="Whether fire alarm is installed")
    type: str = Field(description="e.g., 'Central station automatic smoke/heat', 'Local battery', etc.")
    monitoring_service: str = Field(description="e.g., 'ADT Commercial 24/7', 'Self-monitored', 'None'")


class ACORDStructure(BaseModel):
    policy_type: str = Field(description="'COMMERCIAL' or 'RESIDENTIAL'")
    form_type: str = Field(description="'ACORD 125/140' or 'ACORD 80'")
    named_insured: str = Field(description="Legal entity or applicant name")
    property_address: str = Field(description="Property physical address")
    year_built: int = Field(description="Year structure was built")
    square_footage: int = Field(description="Total square footage")
    iso_construction_class: str = Field(description="e.g., 'Class 4 - Masonry Non-Combustible', 'Class 1 - Frame'")
    roof_type: str = Field(description="e.g., 'Built-up Class A', 'Wood Shake'")
    roof_age_years: int = Field(description="Age of roof in years")
    electrical_panel_type: str = Field(description="e.g., 'Square D Modern', 'Federal Pacific Stab-Lok'")
    occupancy_description: str = Field(description="Declared operations on ACORD form")
    fuel_load_category: str = Field(description="'LOW_COMBUSTIBLE', 'MODERATE_RETAIL', 'HIGH_FLAMMABLE'")
    hazmat_storage: bool = Field(description="Declared hazardous materials storage")
    sprinkler_system: SprinklerDetails
    fire_alarm: AlarmDetails
    fire_hydrant_distance_feet: int
    nearest_fire_station_miles: float
    iso_ppc_rating: int = Field(description="ISO Public Protection Class 1 to 10")
    secondary_heating: Optional[str] = None
    wui_vegetation_clearance_feet: Optional[int] = None


class OccupancyBundle(BaseModel):
    property_id: str
    lob: str
    acord_payload: ACORDStructure
    website_scrape_text: str = Field(
        description="Authentic corporate website operations text. If deceptive discrepancy is requested, undeclared high hazards like lithium-ion battery assembly or welding must be described naturally and professionally. Never use words like 'synthetic', 'fake', or denial codes."
    )
    expected_discrepancy: bool


class SyntheticOccupancyGenerator:
    """
    Generates realistic ACORD 125/140 & ACORD 80 payloads paired with authentic
    company website text via LangChain structured outputs with Gemini.
    """

    def __init__(self, use_llm: bool = True):
        self.use_llm = use_llm
        self.router = GeminiModelRouter()

    def generate_archetype_1_benign(self) -> Dict[str, Any]:
        """
        Archetype 1: Benign Commercial Office / Light Storage (True Low Risk)
        Uses lite model for simple/routine generation.
        """
        fallback = self._get_fallback_archetype_1()
        if not self.use_llm or not self.router.api_key:
            return fallback

        prompt = (
            "Generate an authentic ACORD 125/140 commercial property insurance application for 'Pacific Harbor Logistics LLC' "
            "in Los Angeles, CA (Class 4 Masonry, 100% NFPA 13 sprinkler, modern 2018 construction, dry goods warehousing). "
            "Include a professional company website description that perfectly matches the declared dry goods warehousing operations. "
            "Enforce strict realism guardrails: never use the word 'synthetic' or placeholder codes."
        )

        try:
            bundle: OccupancyBundle = self.router.generate_structured(
                schema=OccupancyBundle,
                prompt=prompt,
                is_complex_task=False,  # Use lite model to conserve complex budget
                fallback_data=OccupancyBundle(**fallback)
            )
            return bundle.model_dump()
        except Exception as e:
            logger.warning(f"Occupancy Gen Archetype 1 LLM failed, using fallback: {e}")
            return fallback

    def generate_archetype_2_wui_macro_surge(self) -> Dict[str, Any]:
        """
        Archetype 2: Residential Home in High WUI Corridor (External Macro Surge)
        """
        fallback = self._get_fallback_archetype_2()
        if not self.use_llm or not self.router.api_key:
            return fallback

        prompt = (
            "Generate an authentic ACORD 80 homeowner insurance application for a single-family residence on 'Pine Ridge Canyon Rd' "
            "in Ukiah, CA (1988 Frame construction, untreated Wood Shake roof, 15ft brush clearance, wood-burning stove). "
            "Website text should reflect a standard residential property with no commercial activity. "
            "Enforce strict realism guardrails: never use the word 'synthetic' or placeholder codes."
        )

        try:
            bundle: OccupancyBundle = self.router.generate_structured(
                schema=OccupancyBundle,
                prompt=prompt,
                is_complex_task=False,  # Routine residential, use lite model
                fallback_data=OccupancyBundle(**fallback)
            )
            return bundle.model_dump()
        except Exception as e:
            logger.warning(f"Occupancy Gen Archetype 2 LLM failed, using fallback: {e}")
            return fallback

    def generate_archetype_3_internal_fault(self) -> Dict[str, Any]:
        """
        Archetype 3: Commercial Warehouse with Undeclared High-Hazard Battery Operations
        Uses complex model (gemini-3.8-flash -> gemini-3.6-flash fallback) to ensure realistic deception.
        """
        fallback = self._get_fallback_archetype_3()
        if not self.use_llm or not self.router.api_key:
            return fallback

        prompt = (
            "Generate a highly realistic commercial underwriting case for 'Apex Storage & Supply Inc' in Ukiah, CA. "
            "On the ACORD 125/140 form, the applicant deceptively declares 'Standard non-hazardous retail dry goods storage' "
            "with obsolete Federal Pacific Stab-Lok panels and an expired sprinkler certification. "
            "However, on their official company website, describe their actual operations: Northern California's custom "
            "high-density lithium-ion battery pack assembly, automated laser welding cells, and industrial electrolyte storage. "
            "The website text must read completely authentic, marketing their technical prowess without any hint that it is simulated. "
            "Strictly ban the word 'synthetic', 'fake', or denial codes."
        )

        try:
            bundle: OccupancyBundle = self.router.generate_structured(
                schema=OccupancyBundle,
                prompt=prompt,
                is_complex_task=True,  # Uses primary gemini-3.8-flash -> gemini-3.6-flash
                fallback_data=OccupancyBundle(**fallback)
            )
            return bundle.model_dump()
        except Exception as e:
            logger.warning(f"Occupancy Gen Archetype 3 LLM failed, using fallback: {e}")
            return fallback

    def generate_archetype_4_midterm(self) -> Dict[str, Any]:
        """
        Archetype 4: Active Monitoring Account (Bound at Low Risk, Degrades Mid-Term)
        """
        fallback = self._get_fallback_archetype_4()
        if not self.use_llm or not self.router.api_key:
            return fallback

        prompt = (
            "Generate an authentic ACORD 125/140 payload for 'Valley Oak Craft Roasters' wholesale coffee roasting facility "
            "in Ukiah, CA (Non-combustible Class 3, modern 2015 construction, full NFPA 13 sprinkler + UL 300 hood suppression). "
            "Website describes commercial wholesale roasting with low-emission Loring machinery. "
            "Enforce strict realism guardrails: never use the word 'synthetic' or placeholder codes."
        )

        try:
            bundle: OccupancyBundle = self.router.generate_structured(
                schema=OccupancyBundle,
                prompt=prompt,
                is_complex_task=False,
                fallback_data=OccupancyBundle(**fallback)
            )
            return bundle.model_dump()
        except Exception as e:
            logger.warning(f"Occupancy Gen Archetype 4 LLM failed, using fallback: {e}")
            return fallback

    # --- Pre-configured High-Fidelity Fallbacks ---

    @staticmethod
    def _get_fallback_archetype_1() -> Dict[str, Any]:
        return {
            "property_id": "PROP_ARCHETYPE_1_BENIGN",
            "lob": "COMMERCIAL",
            "acord_payload": {
                "policy_type": "COMMERCIAL",
                "form_type": "ACORD 125/140",
                "named_insured": "Pacific Harbor Logistics LLC",
                "property_address": "1200 Coastal Blvd, Los Angeles, CA 90245",
                "year_built": 2018,
                "square_footage": 45000,
                "iso_construction_class": "Class 4 - Masonry Non-Combustible",
                "roof_type": "Built-up Class A Fire Rated",
                "roof_age_years": 6,
                "electrical_panel_type": "Square D Modern Circuit Breakers (2018)",
                "occupancy_description": "General dry goods warehousing and executive administrative offices.",
                "fuel_load_category": "LOW_COMBUSTIBLE",
                "hazmat_storage": False,
                "sprinkler_system": {
                    "installed": True,
                    "standard": "NFPA 13 Wet Pipe Automatic Sprinkler System",
                    "coverage_pct": 100,
                    "annual_cert_status": "CURRENT_VERIFIED"
                },
                "fire_alarm": {
                    "installed": True,
                    "type": "UL-Listed Central Station Automatic Smoke & Heat Detection",
                    "monitoring_service": "ADT Commercial 24/7"
                },
                "fire_hydrant_distance_feet": 150,
                "nearest_fire_station_miles": 1.2,
                "iso_ppc_rating": 2,
                "secondary_heating": None,
                "wui_vegetation_clearance_feet": None
            },
            "website_scrape_text": (
                "Welcome to Pacific Harbor Logistics. Founded in 2018, we operate premier modern "
                "coastal distribution facilities specializing in packaged dry retail goods, consumer electronics "
                "fulfillment, and professional supply chain consulting. Our modern facility features climate-controlled "
                "inventory racking, certified eco-friendly lighting, and fully automated logistics management."
            ),
            "expected_discrepancy": False
        }

    @staticmethod
    def _get_fallback_archetype_2() -> Dict[str, Any]:
        return {
            "property_id": "PROP_ARCHETYPE_2_WUI",
            "lob": "RESIDENTIAL",
            "acord_payload": {
                "policy_type": "RESIDENTIAL",
                "form_type": "ACORD 80",
                "named_insured": "Elena Rostova",
                "property_address": "845 Pine Ridge Canyon Rd, Ukiah, CA 95482",
                "year_built": 1988,
                "square_footage": 3200,
                "iso_construction_class": "Class 1 - Frame",
                "roof_type": "Wood Shake (Class C untreated)",
                "roof_age_years": 24,
                "electrical_panel_type": "Original 1988 200A Breaker Panel",
                "occupancy_description": "Single-family primary residence with attached garage.",
                "fuel_load_category": "LOW_COMBUSTIBLE",
                "hazmat_storage": False,
                "sprinkler_system": {
                    "installed": False,
                    "standard": "None",
                    "coverage_pct": 0,
                    "annual_cert_status": "N/A"
                },
                "fire_alarm": {
                    "installed": True,
                    "type": "Local battery smoke detectors",
                    "monitoring_service": "Self-monitored"
                },
                "fire_hydrant_distance_feet": 2400,
                "nearest_fire_station_miles": 8.5,
                "iso_ppc_rating": 8,
                "secondary_heating": "Wood-burning stove and propane wall heater",
                "wui_vegetation_clearance_feet": 15
            },
            "website_scrape_text": "Residential property — no commercial business operational footprint.",
            "expected_discrepancy": False
        }

    @staticmethod
    def _get_fallback_archetype_3() -> Dict[str, Any]:
        return {
            "property_id": "PROP_ARCHETYPE_3_FAULT",
            "lob": "COMMERCIAL",
            "acord_payload": {
                "policy_type": "COMMERCIAL",
                "form_type": "ACORD 125/140",
                "named_insured": "Apex Storage & Supply Inc",
                "property_address": "400 Industry Way, Ukiah, CA 95482",
                "year_built": 1994,
                "square_footage": 60000,
                "iso_construction_class": "Class 2 - Joisted Masonry",
                "roof_type": "Metal Deck over Wood Truss",
                "roof_age_years": 18,
                "electrical_panel_type": "Federal Pacific Electric Stab-Lok Subpanels (Un-updated)",
                "occupancy_description": "Standard storage of non-hazardous retail goods and packaging materials.",
                "fuel_load_category": "MODERATE_RETAIL",
                "hazmat_storage": False,
                "sprinkler_system": {
                    "installed": True,
                    "standard": "NFPA 13 Wet System (Impaired / Partial)",
                    "coverage_pct": 60,
                    "annual_cert_status": "EXPIRED_DEFICIENT"
                },
                "fire_alarm": {
                    "installed": False,
                    "type": "None",
                    "monitoring_service": "Unmonitored"
                },
                "fire_hydrant_distance_feet": 800,
                "nearest_fire_station_miles": 4.1,
                "iso_ppc_rating": 6,
                "secondary_heating": None,
                "wui_vegetation_clearance_feet": None
            },
            "website_scrape_text": (
                "Apex Energy Systems & Custom Fabrication: We are Northern California's premier custom "
                "battery pack engineering facility. Our 60,000 sq ft facility houses automated laser welding cells, "
                "high-density lithium-ion cell sorting, battery module test bays, and large-scale flammable chemical "
                "electrolyte storage. We provide turnkey manufacturing for industrial electric vehicle conversions."
            ),
            "expected_discrepancy": True
        }

    @staticmethod
    def _get_fallback_archetype_4() -> Dict[str, Any]:
        return {
            "property_id": "PROP_ARCHETYPE_4_MIDTERM",
            "lob": "COMMERCIAL",
            "acord_payload": {
                "policy_type": "COMMERCIAL",
                "form_type": "ACORD 125/140",
                "named_insured": "Valley Oak Craft Roasters",
                "property_address": "150 Mendocino Ave, Ukiah, CA 95482",
                "year_built": 2015,
                "square_footage": 18000,
                "iso_construction_class": "Class 3 - Non-Combustible",
                "roof_type": "Metal Standing Seam Class A",
                "roof_age_years": 9,
                "electrical_panel_type": "Eaton Modern 400A Three-Phase",
                "occupancy_description": "Commercial wholesale coffee bean roasting and distribution.",
                "fuel_load_category": "MODERATE_RETAIL",
                "hazmat_storage": False,
                "sprinkler_system": {
                    "installed": True,
                    "standard": "NFPA 13 Wet System + UL 300 Roaster Hood Extinguishment",
                    "coverage_pct": 100,
                    "annual_cert_status": "CURRENT_VERIFIED"
                },
                "fire_alarm": {
                    "installed": True,
                    "type": "Central Station Monitored Smoke and Thermal Sensors",
                    "monitoring_service": "Bay Alarm 24/7"
                },
                "fire_hydrant_distance_feet": 120,
                "nearest_fire_station_miles": 1.1,
                "iso_ppc_rating": 3,
                "secondary_heating": None,
                "wui_vegetation_clearance_feet": None
            },
            "website_scrape_text": (
                "Valley Oak Craft Roasters operates an artisanal roasting facility producing single-origin coffees. "
                "Equipped with modern Loring low-emission roasting machinery with integral thermal afterburners "
                "and automated chaff extraction systems."
            ),
            "expected_discrepancy": False
        }
