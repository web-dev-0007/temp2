import logging
from typing import Dict, Any, Optional
import pandas as pd
import numpy as np
from pydantic import BaseModel, Field

from data_factory.llm_client import GeminiModelRouter

logger = logging.getLogger("SyntheticIoTGen")


class IoTOperationalParameters(BaseModel):
    panel_base_temp_c: float = Field(default=24.0, description="Subpanel base temperature (typically 20-26 C)")
    panel_ambient_coupling_gamma: float = Field(default=0.45, description="Thermal coupling to outdoor NOAA temp (0.35 to 0.55)")
    sprinkler_initial_psi: float = Field(default=65.0, description="Initial sprinkler main hydrostatic pressure (60-70 PSI)")
    sprinkler_decay_rate_psi_per_step: float = Field(default=0.0, description="Rate of hydraulic loss if leaking (0.0 for healthy, 0.5-0.9 for leaking)")
    panel_drift_rate_c_per_step: float = Field(default=0.0, description="Rate of thermal degradation if fault present (0.0 for healthy, 0.15-0.30 for fault)")
    arc_fault_elevated: bool = Field(default=False, description="True if internal arcing is occurring due to degraded insulation")
    base_load_kw: float = Field(default=45.0, description="Facility baseline electrical power demand (kW)")
    engineering_notes: str = Field(default="Mechanical and electrical systems operating within normal parameters.", description="Authentic engineering assessment summary. Must strictly obey realism guardrails (never use 'synthetic').")


class SyntheticIoTGenerator:
    """
    Hybrid Building Telemetry Generator:
    Gemini specifies realistic operational regimes and engineering parameters via LangChain,
    while NumPy and SciPy synthesize continuous, synchronized mechanical/electrical series.
    """

    def __init__(self, use_llm: bool = True, seed: int = 42):
        self.use_llm = use_llm
        self.rng = np.random.default_rng(seed)
        self.router = GeminiModelRouter()

    def get_operational_params(self, fault_type: Optional[str] = None) -> IoTOperationalParameters:
        """
        Uses Gemini lite model to specify physics parameters for the building regime.
        """
        fallback = self._get_fallback_params(fault_type)
        if not self.use_llm or not self.router.api_key:
            return fallback

        prompt = (
            f"Specify realistic building mechanical/electrical engineering parameters for a commercial facility under condition '{fault_type or 'NOMINAL'}'. "
            f"Define realistic panel base temp, thermal drift, sprinkler initial PSI, decay rate, arcing state, and base load kW. "
            f"Enforce strict realism guardrails: never use the word 'synthetic' or placeholder codes in the engineering notes."
        )

        try:
            params: IoTOperationalParameters = self.router.generate_structured(
                schema=IoTOperationalParameters,
                prompt=prompt,
                is_complex_task=False,  # Lite model for parameter framing
                fallback_data=fallback
            )
            return params
        except Exception as e:
            logger.warning(f"IoT Gen LLM parameter framing failed, using fallback: {e}")
            return fallback

    def generate_building_telemetry(
        self,
        noaa_series: pd.DataFrame,
        fault_type: Optional[str] = None, # None, 'divergent_panel_fault', 'sprinkler_leak', 'combined'
    ) -> pd.DataFrame:
        """
        Synthesizes building micro series synchronized with given NOAA timestamps and outdoor temperatures.
        """
        params = self.get_operational_params(fault_type)

        n = len(noaa_series)
        df = pd.DataFrame()
        df["timestamp"] = noaa_series["timestamp"].values
        df["noaa_temp_c"] = noaa_series["temp_c"].values

        # Healthy panel baseline tracking outdoor temp
        noise = self.rng.normal(0.0, 0.4, size=n)
        panel_temp = params.panel_base_temp_c + params.panel_ambient_coupling_gamma * df["noaa_temp_c"] + noise

        # Healthy sprinkler pressure
        sprinkler_psi = self.rng.normal(params.sprinkler_initial_psi, 1.0, size=n)
        
        # Arc faults
        if params.arc_fault_elevated or fault_type in ["divergent_panel_fault", "combined"]:
            arc_faults = self.rng.choice([0, 1], size=n, p=[0.92, 0.08])
        else:
            arc_faults = self.rng.choice([0, 1], size=n, p=[0.95, 0.05])

        # Power load (kW)
        load_kw = params.base_load_kw + 1.2 * df["noaa_temp_c"] + self.rng.normal(0, 2.5, size=n)

        # Apply fault dynamics if specified
        if fault_type in ["divergent_panel_fault", "combined"]:
            fault_start = int(n * 0.4)
            drift_steps = np.arange(n - fault_start)
            # Scales drift to multi-week degradation window
            drift = drift_steps * (10.0 / len(drift_steps))
            panel_temp[fault_start:] += drift
            arc_faults[fault_start:] = self.rng.choice([4, 6, 8, 9], size=n - fault_start, p=[0.2, 0.4, 0.3, 0.1])

        if fault_type in ["sprinkler_leak", "combined"]:
            fault_start = int(n * 0.3)
            decay_steps = np.arange(n - fault_start)
            decay = decay_steps * (36.0 / len(decay_steps))
            sprinkler_psi[fault_start:] = np.maximum(28.0, sprinkler_psi[fault_start:] - decay)

        df["panel_temp_c"] = np.round(panel_temp, 2)
        df["sprinkler_psi"] = np.round(sprinkler_psi, 1)
        df["arc_fault_count"] = arc_faults
        df["load_kw"] = np.round(load_kw, 1)

        return df

    @staticmethod
    def _get_fallback_params(fault_type: Optional[str]) -> IoTOperationalParameters:
        if fault_type in ["divergent_panel_fault", "combined"]:
            return IoTOperationalParameters(
                panel_base_temp_c=24.5,
                panel_ambient_coupling_gamma=0.45,
                sprinkler_initial_psi=65.0,
                sprinkler_decay_rate_psi_per_step=0.7 if fault_type == "combined" else 0.0,
                panel_drift_rate_c_per_step=0.25,
                arc_fault_elevated=True,
                base_load_kw=55.0,
                engineering_notes="Thermal imaging shows localized junction overheating on sub-panel B. Immediate load shedding and breaker servicing required."
            )
        elif fault_type == "sprinkler_leak":
            return IoTOperationalParameters(
                panel_base_temp_c=23.0,
                panel_ambient_coupling_gamma=0.40,
                sprinkler_initial_psi=64.0,
                sprinkler_decay_rate_psi_per_step=0.7,
                panel_drift_rate_c_per_step=0.0,
                arc_fault_elevated=False,
                base_load_kw=42.0,
                engineering_notes="Sprinkler riser gauge indicates slow hydraulic pressure decay below 40 PSI. Standpipe maintenance required."
            )
        else:
            return IoTOperationalParameters(
                panel_base_temp_c=24.0,
                panel_ambient_coupling_gamma=0.42,
                sprinkler_initial_psi=65.0,
                sprinkler_decay_rate_psi_per_step=0.0,
                panel_drift_rate_c_per_step=0.0,
                arc_fault_elevated=False,
                base_load_kw=45.0,
                engineering_notes="Routine quarterly diagnostics: sub-panels, risers, and primary switchgear operating under nominal electrical load."
            )
