from pathlib import Path
from typing import Optional, Dict, Any, List
import pandas as pd
import numpy as np

BASE_DIR = Path(__file__).resolve().parent.parent
NOAA_CSV_PATH = BASE_DIR / "data_factory" / "raw" / "noaa" / "asos.csv"
RAWS_CSV_PATH = BASE_DIR / "data_factory" / "raw" / "raws" / "PublicView_RAWS_8168909641603487300.csv"


def calculate_vpd(temp_c: pd.Series, rh_pct: pd.Series) -> pd.Series:
    """
    Computes Vapor Pressure Deficit (VPD in kPa).
    SVP = 0.61078 * exp((17.27 * T) / (T + 237.3))
    VPD = SVP * (1 - RH / 100)
    """
    svp = 0.61078 * np.exp((17.27 * temp_c) / (temp_c + 237.3))
    vpd = svp * (1.0 - (rh_pct.clip(0, 100) / 100.0))
    return vpd.clip(lower=0.0).round(2)


def calculate_fosberg_fwi(temp_c: pd.Series, rh_pct: pd.Series, wind_mph: pd.Series) -> pd.Series:
    """
    Fosberg Fire Weather Index (FWI) proxy (0-100 scale).
    Combines temperature, low humidity, and wind into an empirical fire spread index.
    """
    # Equilibrium moisture content (m) approximation
    m = np.where(
        rh_pct < 10,
        0.03229 + 0.281073 * rh_pct - 0.000578 * rh_pct * temp_c,
        np.where(
            rh_pct < 50,
            2.22749 + 0.160107 * rh_pct - 0.014784 * temp_c,
            21.0606 + 0.005565 * rh_pct**2 - 0.00035 * rh_pct * temp_c - 0.483199 * rh_pct
        )
    )
    m = np.clip(m, 1.0, 30.0)
    # Fuel model moisture damping factor
    eta = 1.0 - 2.0 * (m / 30.0) + 1.5 * (m / 30.0)**2 - 0.5 * (m / 30.0)**3
    fwi = eta * np.sqrt(1.0 + wind_mph**2)
    return pd.Series(np.clip(fwi * 2.5, 0.0, 100.0), index=temp_c.index).round(1)


class NOAAIngestor:
    """
    Loads, cleans, and derives macro weather & RAWS wildland fuel indices.
    """

    def __init__(self, noaa_path: Optional[Path] = None, raws_path: Optional[Path] = None):
        self.noaa_path = noaa_path or NOAA_CSV_PATH
        self.raws_path = raws_path or RAWS_CSV_PATH
        self._df_noaa: Optional[pd.DataFrame] = None
        self._df_raws: Optional[pd.DataFrame] = None

    def load_noaa_series(self, station: Optional[str] = None) -> pd.DataFrame:
        """
        Loads cleaned ASOS series with standard metric columns:
        - temp_c, dewpoint_c, rel_humidity_pct, wind_speed_mph, wind_gust_mph
        - vpd_kpa, fosberg_fwi, red_flag_condition
        """
        if self._df_noaa is None:
            if not self.noaa_path.exists():
                raise FileNotFoundError(f"NOAA ASOS CSV not found at {self.noaa_path}")

            df = pd.read_csv(self.noaa_path, low_memory=False)
            df["timestamp"] = pd.to_datetime(df["valid"], errors="coerce")
            df = df.dropna(subset=["timestamp"]).sort_values("timestamp")

            # Convert types and units
            df["temp_f"] = pd.to_numeric(df["tmpf"], errors="coerce")
            df["dwp_f"] = pd.to_numeric(df["dwpf"], errors="coerce")
            df["rel_humidity_pct"] = pd.to_numeric(df["relh"], errors="coerce")
            df["wind_speed_mph"] = pd.to_numeric(df["sknt"], errors="coerce") * 1.15078  # knots to mph
            df["wind_gust_mph"] = pd.to_numeric(df["gust"], errors="coerce").fillna(df["wind_speed_mph"]) * 1.15078

            df["temp_c"] = ((df["temp_f"] - 32.0) * 5.0 / 9.0).round(2)
            df["dewpoint_c"] = ((df["dwp_f"] - 32.0) * 5.0 / 9.0).round(2)
            df["rel_humidity_pct"] = df["rel_humidity_pct"].clip(0.0, 100.0).round(1)

            # Derive fire weather metrics
            df["vpd_kpa"] = calculate_vpd(df["temp_c"], df["rel_humidity_pct"])
            df["fosberg_fwi"] = calculate_fosberg_fwi(df["temp_c"], df["rel_humidity_pct"], df["wind_speed_mph"])

            # Red Flag criterion: High temp (>28C) + low humidity (<20%) + strong wind/gusts (>25 mph)
            df["red_flag_condition"] = (
                (df["temp_c"] >= 28.0) &
                (df["rel_humidity_pct"] <= 25.0) &
                ((df["wind_gust_mph"] >= 25.0) | (df["wind_speed_mph"] >= 18.0))
            )

            # Drought KBDI index approximation (scaled 0-800)
            df["drought_kbdi_index"] = np.where(
                df["station"] == "UKI", 680,  # Ukiah autumn drought
                np.where(df["station"] == "LAX", 320, 550)
            )

            cols = [
                "timestamp", "station", "lat", "lon", "temp_c", "dewpoint_c",
                "rel_humidity_pct", "wind_speed_mph", "wind_gust_mph",
                "vpd_kpa", "fosberg_fwi", "drought_kbdi_index", "red_flag_condition"
            ]
            self._df_noaa = df[cols].reset_index(drop=True)

        if station:
            return self._df_noaa[self._df_noaa["station"] == station.upper()].copy()
        return self._df_noaa.copy()

    def load_raws_stations(self, state: str = "CA") -> pd.DataFrame:
        """
        Loads cleaned RAWS stations with 10-hour dead fuel stick moisture % and wind.
        """
        if self._df_raws is None:
            if not self.raws_path.exists():
                raise FileNotFoundError(f"RAWS CSV not found at {self.raws_path}")

            df = pd.read_csv(self.raws_path, encoding="utf-8-sig", low_memory=False)
            
            # Clean fuel moisture string like "7.3 (unk)" -> 7.3
            def parse_fuel_moisture(val):
                if pd.isna(val):
                    return np.nan
                s = str(val).split()[0]
                try:
                    return float(s)
                except ValueError:
                    return np.nan

            df["raws_10hr_fuel_moisture_pct"] = df["Fuel Moisture"].apply(parse_fuel_moisture)
            df["latitude"] = pd.to_numeric(df["Latitude"], errors="coerce")
            df["longitude"] = pd.to_numeric(df["Longitude"], errors="coerce")
            df["station_name"] = df["Station Name"]
            df["state"] = df["State"]

            cols = [
                "station_name", "state", "latitude", "longitude",
                "raws_10hr_fuel_moisture_pct", "Wind Speed MPH", "Air Temperaturee, Standard Placement"
            ]
            self._df_raws = df[cols].dropna(subset=["latitude", "longitude"])

        return self._df_raws[self._df_raws["state"] == state.upper()].copy()

    def get_nearest_raws_fuel_moisture(self, lat: float, lon: float) -> float:
        """
        Finds the nearest RAWS station to given lat/lon and returns its 10-hour fuel moisture %.
        """
        ca_raws = self.load_raws_stations(state="CA")
        # Approximate euclidean distance in lat/lon
        dist = (ca_raws["latitude"] - lat)**2 + (ca_raws["longitude"] - lon)**2
        nearest_idx = dist.idxmin()
        val = ca_raws.loc[nearest_idx, "raws_10hr_fuel_moisture_pct"]
        if pd.isna(val) or val <= 0:
            return 5.5  # fallback critical default for WUI
        return float(val)

