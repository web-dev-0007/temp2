import os
import sys
import time
import logging
from pathlib import Path

# Ensure project root is in sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from typing import Type, TypeVar, Optional, List, Any
from pydantic import BaseModel
from langchain_google_genai import ChatGoogleGenerativeAI
from config.loader import load_settings

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("LLMClient")

# Auto-load .env
env_path = Path(__file__).resolve().parent.parent / ".env"
if env_path.exists():
    with open(env_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                k = k.strip()
                v = v.strip().strip("'").strip('"')
                os.environ[k] = v
                if k == "GEMINI_API_KEY":
                    os.environ["GOOGLE_API_KEY"] = v

T = TypeVar("T", bound=BaseModel)

REALISM_GUARDRAIL_SYSTEM_PROMPT = (
    "STRICT COMPLIANCE MANDATE: You are a professional commercial property and casualty underwriting systems engine. "
    "You must NEVER use the word 'synthetic', 'mock', 'placeholder', or automated denial codes in any generated text, "
    "descriptions, or documents. All company descriptions, property histories, and news articles must read as authentic, "
    "natural, highly realistic commercial records."
)


class GeminiModelRouter:
    """
    Manages LangChain invocation across the 3 user-specified Gemini models:
    - Primary Complex: gemini-3.8-flash (5 RPM, 250k TPM, 20 RPD)
    - Secondary Complex: gemini-3.6-flash (5 RPM, 250k TPM, 20 RPD) -> 40 RPD total for complex
    - Fallback & Simple: gemini-3.5-flash-lite (15 RPM, 250k TPM, 500 RPD)
    
    Includes automatic retry with exponential backoff on 429 rate limits
    and graceful switching to the next available model in the quota pool.
    """

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
        self.settings = load_settings().get("gemini_config", {})
        
        self.primary_complex = self.settings.get("primary_complex_model", "gemini-3.8-flash")
        self.secondary_complex = self.settings.get("secondary_complex_model", "gemini-3.6-flash")
        self.lite_model = self.settings.get("lite_model", "gemini-3.5-flash-lite")
        self.temperature = self.settings.get("temperature", 0.2)
        self.timeout = self.settings.get("timeout_seconds", 30)
        self.max_retries = self.settings.get("retry_max_attempts", 3)
        self.initial_wait = self.settings.get("retry_initial_wait_seconds", 5.0)

    def get_llm(self, model_name: str) -> ChatGoogleGenerativeAI:
        return ChatGoogleGenerativeAI(
            model=model_name,
            google_api_key=self.api_key,
            temperature=self.temperature,
            timeout=self.timeout
        )

    def generate_structured(
        self,
        schema: Type[T],
        prompt: str,
        is_complex_task: bool = False,
        fallback_data: Optional[T] = None
    ) -> T:
        """
        Executes structured output via LangChain with fallback routing:
        - If is_complex_task is True: tries primary_complex -> secondary_complex -> lite_model
        - If is_complex_task is False: directly uses lite_model to conserve 40 RPD complex quota
        """
        if not self.api_key:
            logger.warning("No GEMINI_API_KEY detected. Returning deterministic fallback data.")
            if fallback_data is not None:
                return fallback_data
            raise ValueError("GEMINI_API_KEY is not set and no fallback_data was provided.")

        model_queue: List[str]
        if is_complex_task:
            model_queue = [self.primary_complex, self.secondary_complex, self.lite_model]
        else:
            model_queue = [self.lite_model]

        last_error = None

        for model_name in model_queue:
            logger.info(f"Attempting structured generation with model '{model_name}'...")
            llm = self.get_llm(model_name)
            structured_llm = llm.with_structured_output(schema)

            full_prompt = f"{REALISM_GUARDRAIL_SYSTEM_PROMPT}\n\nTask:\n{prompt}"

            wait_time = self.initial_wait
            for attempt in range(1, self.max_retries + 1):
                try:
                    result = structured_llm.invoke(full_prompt)
                    logger.info(f"Successfully generated structured response via '{model_name}'.")
                    return result
                except Exception as e:
                    err_msg = str(e)
                    last_error = e
                    # Check for rate limit / 429
                    if "429" in err_msg or "ResourceExhausted" in err_msg or "quota" in err_msg.lower():
                        logger.warning(
                            f"Rate limit / 429 encountered on model '{model_name}' (Attempt {attempt}/{self.max_retries}). "
                            f"Waiting {wait_time:.1f}s before retry..."
                        )
                        time.sleep(wait_time)
                        wait_time *= 2.0  # exponential backoff
                    else:
                        logger.error(f"Error on model '{model_name}': {err_msg}")
                        break  # Switch to next model in queue for non-transient errors

            logger.warning(f"Exhausted retries or quota on model '{model_name}'. Switching to next model in queue...")

        logger.error(f"All models in queue {model_queue} failed or exhausted. Last error: {last_error}")
        if fallback_data is not None:
            logger.info("Engaging pre-configured deterministic fallback data.")
            return fallback_data
        raise last_error or RuntimeError("Structured LLM generation failed across all configured models.")

