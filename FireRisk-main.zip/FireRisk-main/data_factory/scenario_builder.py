from typing import Dict, Any
import pandas as pd
from data_factory.noaa_ingestor import NOAAIngestor
from data_factory.micro_benchmark_loader import MicroBenchmarkLoader
from data_factory.synthetic_iot_gen import SyntheticIoTGenerator
from data_factory.synthetic_occupancy_gen import SyntheticOccupancyGenerator
from data_factory.synthetic_news_gen import SyntheticNewsGenerator


class ScenarioBuilder:
    """
    Bundles the 4 Canonical Archetypes combining verified real-world datasets
    (NOAA ASOS, RAWS, EN54, BME688) with NOAA-anchored synthetic layers.
    """

    def __init__(self, use_llm: bool = False):
        self.use_llm = use_llm
        self.noaa_ingestor = NOAAIngestor()
        self.benchmark_loader = MicroBenchmarkLoader()
        self.iot_gen = SyntheticIoTGenerator(use_llm=use_llm)
        self.occupancy_gen = SyntheticOccupancyGenerator(use_llm=use_llm)
        self.news_gen = SyntheticNewsGenerator(use_llm=use_llm)

    def build_archetype_1(self) -> Dict[str, Any]:
        """
        Archetype 1 — Benign Baseline (True Low Risk)
        Tests:
        - Mild coastal weather (LAX)
        - EN54 nuisance aerosol false-alarm filter (rejects deodorant PM spike)
        - Healthy panel temp tracking outdoor weather (Z-score < 1.0)
        - Healthy sprinkler pressure (65 PSI)
        - Modern non-combustible building with full NFPA 13 sprinkler coverage
        """
        noaa_series = self.noaa_ingestor.load_noaa_series("LAX").head(72).copy()
        iot_telemetry = self.iot_gen.generate_building_telemetry(noaa_series, fault_type=None)
        
        # Inject real EN54 deodorant aerosol nuisance run to verify false-alarm rejection
        en54_nuisance = self.benchmark_loader.get_en54_slice(scenario="Deodorant", limit=len(iot_telemetry))
        iot_telemetry["en54_h2_ppm"] = en54_nuisance["en54_h2_ppm"].values
        iot_telemetry["en54_co_ppm"] = en54_nuisance["en54_co_ppm"].values
        iot_telemetry["smoke_ppm"] = en54_nuisance["smoke_ppm"].values
        iot_telemetry["bme_outdoor_smoke_index"] = 0.08  # clean air

        occupancy_data = self.occupancy_gen.generate_archetype_1_benign()
        news_data = self.news_gen.get_articles_for_archetype_1()

        return {
            "archetype_id": "ARCHETYPE_1_BENIGN_BASELINE",
            "name": "Pacific Harbor Logistics — Modern Coastal Distribution",
            "property_id": "PROP_ARCHETYPE_1_BENIGN",
            "lob": "COMMERCIAL",
            "noaa_series": noaa_series,
            "iot_telemetry": iot_telemetry,
            "occupancy_data": occupancy_data,
            "news_articles": news_data,
            "raws_10hr_fuel_moisture_pct": 14.5,
            "wui_exposure_tier": "LOW_URBAN",
            "expected_risk_tier": "LOW",
            "expected_auto_bind": True
        }

    def build_archetype_2(self) -> Dict[str, Any]:
        """
        Archetype 2 — Macro Environmental WUI Surge (External High Risk)
        Tests:
        - Severe heatwave & Red Flag fire weather (Ukiah WUI)
        - Critical RAWS 10-hour dead fuel stick moisture < 6%
        - BME688 perimeter smoke plume arrival (smoke index > 0.70)
        - Combustible wood-shake roof in dense WUI canyon corridor
        - Utility transformer blowout news
        """
        noaa_series = self.noaa_ingestor.load_noaa_series("UKI").head(72).copy()
        iot_telemetry = self.iot_gen.generate_building_telemetry(noaa_series, fault_type=None)
        
        # Inject real BME688 downwind vegetation smoke plume arrival
        bme_plume = self.benchmark_loader.get_bme688_slice(smoke_event=True, limit=len(iot_telemetry))
        iot_telemetry["bme_outdoor_smoke_index"] = bme_plume["bme_outdoor_smoke_index"].values
        iot_telemetry["en54_h2_ppm"] = 0.05
        iot_telemetry["en54_co_ppm"] = 0.10
        iot_telemetry["smoke_ppm"] = 0.15

        occupancy_data = self.occupancy_gen.generate_archetype_2_wui_macro_surge()
        news_data = self.news_gen.get_articles_for_archetype_2()

        return {
            "archetype_id": "ARCHETYPE_2_WUI_MACRO_SURGE",
            "name": "Pine Ridge Canyon Residence — WUI Wildfire Aridity Surge",
            "property_id": "PROP_ARCHETYPE_2_WUI",
            "lob": "RESIDENTIAL",
            "noaa_series": noaa_series,
            "iot_telemetry": iot_telemetry,
            "occupancy_data": occupancy_data,
            "news_articles": news_data,
            "raws_10hr_fuel_moisture_pct": 4.8,  # Critical < 6%
            "wui_exposure_tier": "EXTREME_WUI_CANYON",
            "expected_risk_tier": "HIGH",
            "expected_auto_bind": False
        }

    def build_archetype_3(self) -> Dict[str, Any]:
        """
        Archetype 3 — Micro Internal Fault & Operational Discrepancy (Internal High Risk)
        Tests:
        - Cool outdoor weather (Ukiah late October)
        - Divergent electrical subpanel thermal drift (Z-score > 3.0)
        - EN54 real NHXMH cable overload H2/CO outgassing signature
        - Sprinkler pressure dropped to 28 PSI (critical suppression impairment < 40 PSI)
        - Declared vs Actual Discrepancy: Declared general storage, website reveals Li-ion battery manufacturing
        - OSHA electrical citation
        - Tests Hard Veto override (floors score at 75.0)
        """
        noaa_series = self.noaa_ingestor.load_noaa_series("UKI").tail(72).copy()
        # Inject combined electrical fault and sprinkler leak
        iot_telemetry = self.iot_gen.generate_building_telemetry(noaa_series, fault_type="combined")
        
        # Inject real EN54 NHXMH cable overload trace
        en54_cable = self.benchmark_loader.get_en54_slice(scenario="Cable", limit=len(iot_telemetry))
        iot_telemetry["en54_h2_ppm"] = en54_cable["en54_h2_ppm"].values
        iot_telemetry["en54_co_ppm"] = en54_cable["en54_co_ppm"].values
        iot_telemetry["smoke_ppm"] = en54_cable["smoke_ppm"].values
        iot_telemetry["bme_outdoor_smoke_index"] = 0.05

        occupancy_data = self.occupancy_gen.generate_archetype_3_internal_fault()
        news_data = self.news_gen.get_articles_for_archetype_3()

        return {
            "archetype_id": "ARCHETYPE_3_INTERNAL_DIVERGENT_FAULT",
            "name": "Apex Storage & Supply — Undeclared Battery Assembly & Cable Overload",
            "property_id": "PROP_ARCHETYPE_3_FAULT",
            "lob": "COMMERCIAL",
            "noaa_series": noaa_series,
            "iot_telemetry": iot_telemetry,
            "occupancy_data": occupancy_data,
            "news_articles": news_data,
            "raws_10hr_fuel_moisture_pct": 11.2,
            "wui_exposure_tier": "MODERATE_URBAN_INTERFACE",
            "expected_risk_tier": "HIGH",
            "expected_hard_veto_triggered": True
        }

    def build_archetype_4(self) -> Dict[str, Any]:
        """
        Archetype 4 — Mid-Term Degradation (Active Monitoring Trigger)
        Tests:
        - Baseline Day 0 bound at LOW risk (Score = 22.0)
        - Active Monitoring scan at Day 45 showing:
          1) Roaster machinery thermal drift
          2) Municipal water main break causing hydrant pressure collapse
          3) Regional drought surge
        - Tests Delta calculation (Delta S >= +15.0) and Actuarial Reserving Step-Up (2.0x base reserve)
        """
        noaa_series = self.noaa_ingestor.load_noaa_series("UKI").head(72).copy()
        iot_telemetry = self.iot_gen.generate_building_telemetry(noaa_series, fault_type="sprinkler_leak")
        
        # Moderate gas readings
        iot_telemetry["en54_h2_ppm"] = 0.12
        iot_telemetry["en54_co_ppm"] = 0.25
        iot_telemetry["smoke_ppm"] = 0.30
        iot_telemetry["bme_outdoor_smoke_index"] = 0.25

        occupancy_data = self.occupancy_gen.generate_archetype_4_midterm()
        news_data = self.news_gen.get_articles_for_archetype_4()

        return {
            "archetype_id": "ARCHETYPE_4_MIDTERM_DEGRADATION",
            "name": "Valley Oak Craft Roasters — Active Monitoring Degradation",
            "property_id": "PROP_ARCHETYPE_4_MIDTERM",
            "lob": "COMMERCIAL",
            "baseline_score": 22.0,  # Bound baseline
            "baseline_risk_tier": "LOW",
            "noaa_series": noaa_series,
            "iot_telemetry": iot_telemetry,
            "occupancy_data": occupancy_data,
            "news_articles": news_data,
            "raws_10hr_fuel_moisture_pct": 6.8,
            "wui_exposure_tier": "MODERATE_VALLEY",
            "expected_active_monitoring_alert": True
        }

    def get_bundle(self, archetype_id: str) -> Dict[str, Any]:
        lookup = {
            "ARCHETYPE_1_BENIGN_BASELINE": self.build_archetype_1,
            "ARCHETYPE_2_WUI_MACRO_SURGE": self.build_archetype_2,
            "ARCHETYPE_3_INTERNAL_DIVERGENT_FAULT": self.build_archetype_3,
            "ARCHETYPE_4_MIDTERM_DEGRADATION": self.build_archetype_4
        }
        if archetype_id not in lookup:
            raise ValueError(f"Unknown archetype '{archetype_id}'. Available: {list(lookup.keys())}")
        return lookup[archetype_id]()

