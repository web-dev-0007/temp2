import logging
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field

from data_factory.llm_client import GeminiModelRouter

logger = logging.getLogger("SyntheticNewsGen")


class NewsArticleItem(BaseModel):
    article_id: str = Field(description="Unique article identifier, e.g. 'NEWS_LOCAL_001'")
    published_date: str = Field(description="ISO 8601 timestamp")
    days_ago: float = Field(description="Days elapsed since publication")
    headline: str = Field(description="Realistic journalistic headline")
    source: str = Field(description="Realistic news or regulatory agency publication name")
    distance_miles: float = Field(description="Distance from property (0.0 to 5.0 miles)")
    is_entity_match: bool = Field(description="True if article specifically names the insured entity")
    entity_name: Optional[str] = Field(default=None, description="Name of cited entity if applicable")
    category: str = Field(
        description="One of: 'OSHA_ELECTRICAL_VIOLATION', 'SUPPRESSION_IMPAIRMENT', 'INFRASTRUCTURE_WATER_FAILURE', 'INFRASTRUCTURE_PERIL', 'WILDFIRE_WEATHER_ALERT', 'GRID_INSTABILITY', 'BUSINESS_COMMENDATION', 'INFRASTRUCTURE_ROUTINE'"
    )
    body_text: str = Field(
        description="Authentic article text citing specific technical details or citations. Must strictly obey realism guardrails (never use the word 'synthetic' or placeholder codes)."
    )


class NewsArticleCollection(BaseModel):
    articles: List[NewsArticleItem]


class SyntheticNewsGenerator:
    """
    Generates localized adverse media, regulatory citations, and infrastructure
    incident logs within a 5-mile radius via LangChain structured outputs with Gemini.
    """

    def __init__(self, use_llm: bool = True):
        self.use_llm = use_llm
        self.router = GeminiModelRouter()

    def get_articles_for_archetype_1(self) -> List[Dict[str, Any]]:
        """
        Archetype 1 (Benign): Routine favorable community news, zero fire infractions.
        Uses lite model for simple task.
        """
        fallback = self._get_fallback_1()
        if not self.use_llm or not self.router.api_key:
            return fallback

        prompt = (
            "Generate 2 realistic local news articles for an area around 'Coastal Blvd, Los Angeles, CA' "
            "near 'Pacific Harbor Logistics LLC'. Article 1 should be a business commendation for sustainable logistics, "
            "and Article 2 should be a municipal public works report verifying normal water pressure. "
            "No fire hazards or citations. Enforce realism guardrails: never use the word 'synthetic'."
        )

        try:
            res: NewsArticleCollection = self.router.generate_structured(
                schema=NewsArticleCollection,
                prompt=prompt,
                is_complex_task=False,  # Lite model
                fallback_data=NewsArticleCollection(articles=[NewsArticleItem(**a) for a in fallback])
            )
            return [a.model_dump() for a in res.articles]
        except Exception as e:
            logger.warning(f"News Gen Archetype 1 LLM failed, using fallback: {e}")
            return fallback

    def get_articles_for_archetype_2(self) -> List[Dict[str, Any]]:
        """
        Archetype 2 (WUI Surge): Red flag warnings, utility sparks in canyon corridor.
        Uses lite model for simple task.
        """
        fallback = self._get_fallback_2()
        if not self.use_llm or not self.router.api_key:
            return fallback

        prompt = (
            "Generate 2 realistic local news reports for Ukiah, CA during an October Red Flag fire weather event. "
            "Article 1: NWS Red Flag warning for Pine Ridge Canyon with single-digit fuel moisture and 45mph gusts. "
            "Article 2: A distribution transformer blowout igniting a 2-acre scrub fire on Pine Ridge Rd, CAL FIRE dispatch. "
            "Enforce realism guardrails: never use the word 'synthetic'."
        )

        try:
            res: NewsArticleCollection = self.router.generate_structured(
                schema=NewsArticleCollection,
                prompt=prompt,
                is_complex_task=False,
                fallback_data=NewsArticleCollection(articles=[NewsArticleItem(**a) for a in fallback])
            )
            return [a.model_dump() for a in res.articles]
        except Exception as e:
            logger.warning(f"News Gen Archetype 2 LLM failed, using fallback: {e}")
            return fallback

    def get_articles_for_archetype_3(self) -> List[Dict[str, Any]]:
        """
        Archetype 3 (Internal Fault): OSHA electrical citations, hazardous materials violation.
        Uses complex model (gemini-3.8-flash -> gemini-3.6-flash fallback) for realistic regulatory citation text.
        """
        fallback = self._get_fallback_3()
        if not self.use_llm or not self.router.api_key:
            return fallback

        prompt = (
            "Generate 2 realistic regulatory news records in Ukiah, CA on Industry Way. "
            "Article 1: Cal/OSHA official enforcement citation issued directly to 'Apex Storage & Supply Inc' for overloaded "
            "subpanels, unrated welding bays, and failure to maintain 480V clearance. "
            "Article 2: Fire Marshal inspection notice regarding deficient riser valves and impaired hydrostatic pressure on Industry Way. "
            "Enforce realism guardrails: never use the word 'synthetic'."
        )

        try:
            res: NewsArticleCollection = self.router.generate_structured(
                schema=NewsArticleCollection,
                prompt=prompt,
                is_complex_task=True,  # Complex regulatory citation drafting
                fallback_data=NewsArticleCollection(articles=[NewsArticleItem(**a) for a in fallback])
            )
            return [a.model_dump() for a in res.articles]
        except Exception as e:
            logger.warning(f"News Gen Archetype 3 LLM failed, using fallback: {e}")
            return fallback

    def get_articles_for_archetype_4(self) -> List[Dict[str, Any]]:
        """
        Archetype 4 (Mid-Term Degradation): Municipal water main break causing hydrant failure.
        Uses lite model for simple task.
        """
        fallback = self._get_fallback_4()
        if not self.use_llm or not self.router.api_key:
            return fallback

        prompt = (
            "Generate 2 realistic municipal incident reports in Ukiah, CA. "
            "Article 1: Major municipal water transmission main rupture beneath Mendocino Ave, dropping neighborhood hydrant pressure. "
            "Article 2: Electric utility regional substation voltage surges triggering industrial panel trips. "
            "Enforce realism guardrails: never use the word 'synthetic'."
        )

        try:
            res: NewsArticleCollection = self.router.generate_structured(
                schema=NewsArticleCollection,
                prompt=prompt,
                is_complex_task=False,
                fallback_data=NewsArticleCollection(articles=[NewsArticleItem(**a) for a in fallback])
            )
            return [a.model_dump() for a in res.articles]
        except Exception as e:
            logger.warning(f"News Gen Archetype 4 LLM failed, using fallback: {e}")
            return fallback

    # --- Pre-configured High-Fidelity Fallbacks ---

    @staticmethod
    def _get_fallback_1() -> List[Dict[str, Any]]:
        return [
            {
                "article_id": "NEWS_LAX_001",
                "published_date": "2026-10-15T09:00:00Z",
                "days_ago": 10.0,
                "headline": "Coastal Business Chamber Welcomes Sustainable Logistics Hub",
                "source": "Los Angeles Business Journal",
                "distance_miles": 0.8,
                "is_entity_match": True,
                "entity_name": "Pacific Harbor Logistics LLC",
                "category": "BUSINESS_COMMENDATION",
                "body_text": "Pacific Harbor Logistics completed its annual green energy facility audit, receiving commendations for clean electrical infrastructure and zero safety infractions."
            },
            {
                "article_id": "NEWS_LAX_002",
                "published_date": "2026-10-20T14:30:00Z",
                "days_ago": 5.0,
                "headline": "City of El Segundo Completes Routine Water Main Inspection",
                "source": "South Bay Daily",
                "distance_miles": 1.5,
                "is_entity_match": False,
                "entity_name": None,
                "category": "INFRASTRUCTURE_ROUTINE",
                "body_text": "Municipal public works verified all hydrants along Coastal Blvd operate at maximum static pressure above 80 PSI."
            }
        ]

    @staticmethod
    def _get_fallback_2() -> List[Dict[str, Any]]:
        return [
            {
                "article_id": "NEWS_WUI_001",
                "published_date": "2026-10-06T11:00:00Z",
                "days_ago": 2.0,
                "headline": "Red Flag Warning Declared for Mendocino Ridge and Canyon Slopes",
                "source": "Ukiah Daily Journal",
                "distance_miles": 1.2,
                "is_entity_match": False,
                "entity_name": None,
                "category": "WILDFIRE_WEATHER_ALERT",
                "body_text": "National Weather Service issued Red Flag Warning due to single-digit fuel moisture and wind gusts up to 45 mph across Pine Ridge Canyon."
            },
            {
                "article_id": "NEWS_WUI_002",
                "published_date": "2026-10-07T16:15:00Z",
                "days_ago": 1.0,
                "headline": "Utility Transformer Spark Ignites 2-Acre Brush Fire on Pine Ridge Rd",
                "source": "Northern CA Fire Watch",
                "distance_miles": 2.4,
                "is_entity_match": False,
                "entity_name": None,
                "category": "INFRASTRUCTURE_PERIL",
                "body_text": "High winds triggered a distribution transformer blowout, igniting dry oak scrub. CAL FIRE responded with air tankers; residents advised of extreme ember casting."
            }
        ]

    @staticmethod
    def _get_fallback_3() -> List[Dict[str, Any]]:
        return [
            {
                "article_id": "NEWS_FAULT_001",
                "published_date": "2026-10-22T08:30:00Z",
                "days_ago": 4.0,
                "headline": "Cal/OSHA Issues Willful Citation to Apex Storage for Overloaded Subpanels",
                "source": "Industrial Safety Digest",
                "distance_miles": 0.0,
                "is_entity_match": True,
                "entity_name": "Apex Storage & Supply Inc",
                "category": "OSHA_ELECTRICAL_VIOLATION",
                "body_text": "Cal/OSHA inspectors cited Apex Storage for multiple unaddressed electrical panel hotspots, unrated welding bays, and failure to maintain clearance around 480V breakers."
            },
            {
                "article_id": "NEWS_FAULT_002",
                "published_date": "2026-10-18T15:00:00Z",
                "days_ago": 8.0,
                "headline": "Fire Marshal Notice: Impaired Sprinkler Valves Discovered in Industry Way Complex",
                "source": "Mendocino County Public Records",
                "distance_miles": 0.3,
                "is_entity_match": False,
                "entity_name": None,
                "category": "SUPPRESSION_IMPAIRMENT",
                "body_text": "Routine fire marshal inspection revealed several industrial riser valves on Industry Way were partially closed, resulting in deficient hydrostatic pressure."
            }
        ]

    @staticmethod
    def _get_fallback_4() -> List[Dict[str, Any]]:
        return [
            {
                "article_id": "NEWS_MID_001",
                "published_date": "2026-10-24T18:00:00Z",
                "days_ago": 1.0,
                "headline": "Major Water Main Break Shuts Down Mendocino Ave; Hydrant Pressure Compromised",
                "source": "Ukiah Valley News",
                "distance_miles": 0.4,
                "is_entity_match": False,
                "entity_name": None,
                "category": "INFRASTRUCTURE_WATER_FAILURE",
                "body_text": "A 16-inch municipal water transmission main ruptured beneath Mendocino Ave. Fire department warns that commercial hydrants in the area are experiencing severe pressure drops."
            },
            {
                "article_id": "NEWS_MID_002",
                "published_date": "2026-10-23T10:00:00Z",
                "days_ago": 2.0,
                "headline": "Substation Power Surge Triggers Multiple Industrial False Alarms & Panel Trips",
                "source": "PG&E Regional Notice",
                "distance_miles": 1.8,
                "is_entity_match": False,
                "entity_name": None,
                "category": "GRID_INSTABILITY",
                "body_text": "Repeated transmission grid fluctuations have caused electrical equipment thermal cycling and circuit breaker trips across Ukiah commercial parks."
            }
        ]
