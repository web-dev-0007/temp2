# Fire Risk AI — Project Context, Checkpoints & Progress Tracker

> **Last Updated:** 2026-11-11  
> **Master Architecture:** [architecture_final.md](architecture_final.md)  
> **Execution Roadmap:** [implementation_plan.md](implementation_plan.md)  
> **Target GitHub Repository:** https://github.com/Divs2930/FireRisk.git  
> **Python Environment:** `.venv` (Python 3.10.22 with Pydantic v2, Pandas, NumPy, SciPy, Scikit-learn 1.6.1, XGBoost 2.1.4, LightGBM 4.6.0, SHAP 0.49.1, Joblib 1.5.3, LangChain, LangChain-Google-GenAI, LangGraph, Google-GenAI, Jupyter, FastAPI, Streamlit, Plotly, Pytest 9.2.0)  
> **Status:** **ALL 7 STAGES 100% COMPLETED, VERIFIED & COMMITTED TO GIT.** End-to-end Pytest suite passed (6/6 tests in 1.30s).

---

## 1. Project Overview & Ultimate Goal

**Fire Risk AI** is an intelligent, multi-agent Property & Casualty (P&C) insurance fire underwriting and active portfolio monitoring platform for commercial and residential properties.

The platform bridges the gap between **classical, interpretable physics/ML models** (Scikit-Learn `HuberRegressor`, `IsolationForest`, `XGBoost`/`LightGBM`, `TreeSHAP`) and **generative AI agents** (`gemini-3.8-flash`, `gemini-3.6-flash`, `gemini-3.5-flash-lite`), capped by a **100% deterministic actuarial decision engine** with a safety-critical **Hard Veto** override and an **AI Senior Underwriter Executive Memo**.

### Core Execution Modes:
1. **Submission / Renewal (`SUBMISSION_RENEWAL`):**
   - Synchronous underwriting at the time of quote or annual policy renewal.
   - Evaluates COPE building attributes, satellite/NOAA weather baselines, RAWS wildland fuel moisture, nearby OSHA/utility incidents, and multi-sensor IoT telemetry.
   - Outputs: Instant Auto-Bind eligibility, technical rate credits/debits (-15% to +50%), deductible adjustments, and remediation safeguards.
2. **Active Portfolio Monitoring (`ACTIVE_MONITORING`):**
   - Periodic or scheduled batch scans (weekly/monthly) on in-force policy portfolios.
   - Tracks risk score velocity ($\Delta S = S_{\text{current}} - S_{\text{baseline}}$).
   - If $\Delta S \ge +15.0$, immediately triggers loss-control engineering dispatch and steps up actuarial IBNR loss reserves from $0.85\times$ to $2.0\times$ base reserve factor.

---

## 2. Insurance Domain Guide & Terminology (For Engineers & Data Scientists)

To ensure any developer or data scientist understands the underwriting logic without insurance confusion:

| Term | Insurance Domain Definition | System Implementation / Impact |
| :--- | :--- | :--- |
| **Bind / Binding** | The legally binding act of putting insurance coverage into effect. Once "bound", the insurer is legally liable for claims even before formal paper contracts are printed. | A submission reaching the end of the pipeline transitions to `AUTO_BIND_ELIGIBLE` or `DECLINE_OR_HOLD`. |
| **Auto-Bind (STP)** | Straight-Through Processing: Instant policy approval and binding in seconds without requiring manual review by a human underwriter. | Archetype 1 qualifies for Auto-Bind because Hazard Score $< 36.0$, telemetry is nominal, and sprinklers are 100% certified. |
| **Binder** | A temporary legal certificate proving active coverage, required by mortgage lenders, banks, and commercial property leases. | Emitted via the executive memo and final business verdict payload. |
| **COPE** | The 4 pillars of commercial property underwriting: **C**onstruction (materials), **O**ccupancy (operations & contents), **P**rotection (sprinklers/alarms/hydrants), and **E**xposure (surrounding hazards/wildland). | Handled by `occupancy_risk_agent.py` parsing ACORD 125/140 & 80 forms and auditing company websites. |
| **Hard Veto** | A mandatory underwriting rule that overrides any weighted average. Even if 9 out of 10 signals look good, a critical red-flag (e.g. failing sprinklers + lithium battery outgassing) forces a minimum score floor $\ge 75.0$ and immediate Decline/Hold. | Configured in `decision_layer/business_impact_mapper.py` and toggleable in the UI/API. Triggered when Huber residual $Z > 3.0$ and Isolation Forest confirm acute internal equipment fault. |
| **IBNR Reserving** | "Incurred But Not Reported" loss reserves: capital an insurer must legally hold in reserve to pay for anticipated fire claims. | Favorable risks reduce reserve to $0.85\times$; active monitoring surges step up reserve to $1.5\times$ - $2.0\times$. |
| **Rate Credit / Debit** | Pricing adjustment applied to the base policy premium. A -10% credit rewards smart IoT sensor adoption; a +30% debit surcharges elevated fuel or wiring risks. | Generated dynamically by `business_impact_mapper.py`. |

---

## 3. The 4 Canonical Underwriting Archetypes (Tested & Validated)

All four archetypes are fully generated, verified, and preserved as reproducible test fixtures in `data_factory/generated_samples/`:

| Archetype | Property Name & LOB | Risk Profile & Peril Drivers | Final Score & Tier | Underwriting Verdict & Action |
| :--- | :--- | :--- | :--- | :--- |
| **Archetype 1 (Benign)** | Pacific Harbor Logistics (`COMMERCIAL`) | Class 4 Non-combustible masonry, 100% NFPA 13 sprinklers, dry goods retail. EN54 deodorant aerosol nuisance burst injected and successfully filtered. | **11.4 / 100** (`LOW`) | **AUTO_BIND_ELIGIBLE**: -10.0% rate credit, standard deductible, favorable IBNR reserve ($0.85\times$). |
| **Archetype 2 (WUI Surge)** | Pinecrest Ridge Home (`RESIDENTIAL`) | 1988 Frame home, untreated wood shake roof, 15 ft brush clearance. RAWS 10-hr fuel moisture at critical 4.8% (<6% extreme flag), Santa Ana winds, transformer spark. | **81.6 / 100** (`HIGH`) | **NON_BIND_SURGE**: Hold binding, mandatory 100 ft vegetation clearance & Class A ember-resistant roof retrofit required. |
| **Archetype 3 (Hard Veto)** | ChemVance Solutions (`COMMERCIAL`) | ACORD form claims benign dry goods storage with obsolete Federal Pacific Stab-Lok panels. Website reveals undisclosed lithium-ion battery assembly. Huber regression catches thermal runaway ($Z = 17.57 \gg 3.0$), 285 arc faults, and sprinkler pressure collapse. | **95.5 / 100** (`HIGH`) | **HARD VETO TRIGGERED**: Score floored at 75.0 $\rightarrow$ 95.5. Immediate Decline/Hold, zero bind authority, loss-control inspection. |
| **Archetype 4 (Active Mid-term)** | Valley Oak Roasters (`COMMERCIAL`) | In-force policy initially bound at benign baseline ($S = 22.0$). Mid-term scan detects 16-inch municipal water main rupture (sprinkler pressure drop to 28 PSI) and PG&E grid power surges. $\Delta S = +53.0 \ge +15.0$. | **75.0 / 100** (`HIGH`) | **ACTIVE MONITORING DELTA SURGE**: Urgent 48-hr loss-control inspection, emergency generator dispatch, IBNR reserve stepped up to $2.0\times$. |

---

## 4. Master Dataset Catalog & Ground Truth

All real-world training and benchmark datasets are downloaded, verified, and mapped:

| Dataset | Type | Location | Status | Verified Metrics |
| :--- | :--- | :--- | :--- | :--- |
| **EN54 Indoor Multi-Sensor Fire** | Real | `data_factory/raw/en54/` | ✅ **VERIFIED** | **305,304 rows** × 16 channels. Covers NHXMH electrical cable overload (10,658 rows) vs. aerosol nuisance runs (ethanol, deodorant, hairspray). |
| **BME688/BME690 Smoke Detection** | Real | `data_factory/raw/bme688/Dataset Smoke Detection/` | ✅ **VERIFIED** | **131,370 rows** across 20 CSVs (5 nodes × 4 heater profiles). Extracted from RAR. Downwind vegetation smoke plumes vs. clean air. |
| **NOAA ASOS CA Weather Baseline** | Real | `data_factory/raw/noaa/asos.csv` | ✅ **VERIFIED** | **10,814 hourly observations** (Aug 1 – Oct 31, 2026). Stations: `LAX`, `STS`, `SMF`, `CMA`, `UKI`. Captures CA heatwaves, drought, and Santa Ana winds. |
| **Interagency RAWS Telemetry** | Real | `data_factory/raw/raws/PublicView_RAWS_8168909641603487300.csv` | ✅ **VERIFIED** | **3,223 wildland stations** nationwide with **638 California stations**. Captures 10-hour dead fuel stick moisture (%) & canyon winds. |

---

## 5. Completed Implementation Stages (100% Complete)

### ✅ Stage 1: Environment & Actuarial Foundations
- Virtual environment created with Python 3.10.22 and Apple Silicon `libomp`.
- Dependencies installed: Pydantic v2, YAML, Pandas, NumPy, SciPy, Scikit-learn, XGBoost, LightGBM, SHAP, LangChain, LangGraph, FastAPI, Streamlit, Plotly, Pytest.
- Actuarial scoring weights and tier thresholds configured in `config/settings.yaml`.

### ✅ Stage 2: Classical ML Robust Regression Engine
- Built `agents/poc_fire_risk_detector.py` implementing Scikit-Learn `HuberRegressor` for both temporal thermal drift and NOAA weather baseline divergence.
- Replaced standard deviation with Median Absolute Deviation (MAD) for scale-invariant $Z$-scores ($Z_{\text{Huber}}$).
- Verified mathematical outlier resistance against $+30^\circ\text{C}$ transient hardware spikes.

### ✅ Stage 3: Gemini Structured Data Factory & Realism Guardrail
- Implemented `data_factory/llm_client.py` managing a 3-tier Gemini model pool (`gemini-3.8-flash` / `3.6-flash` for complex reasoning at 40 RPD; `gemini-3.5-flash-lite` for high-volume tasks at 500 RPD) with exponential 429 backoff retry.
- Realism Guardrail: System prompt strictly bans the words "synthetic", "placeholder", or raw denial codes from all generated documents.
- Generated and serialized the 4 canonical underwriting archetype payloads and telemetry CSVs in `data_factory/generated_samples/`.

### ✅ Stage 4: LangGraph Multi-Agent Orchestrator & AI Synthesis
- Built `agents/iot_sensor_agent.py` with multi-layer ML pipeline and heuristic fallbacks.
- Built `orchestrator/graph.py` with LangGraph `StateGraph`:
  ```
  entity_lob_router ──> [Parallel Fan-Out: IoT Agent, Occupancy Agent, News Agent] ──> verdict_engine ──> ai_synthesis ──> END
  ```
- Implemented `node_ai_synthesis` utilizing `gemini-3.5-flash-lite` to compose an actuarially grounded, plain-English `UnderwritingExecutiveMemo` on top of deterministic math.
- Verified in `scripts/test_stage4_langgraph.py`.

### ✅ Stage 5: Underwriter Cockpit & FastAPI Service
- Built `orchestrator/submission_api.py` with OpenAPI endpoints (`/v1/health`, `/v1/archetypes`, `/v1/hotspots/california`, `/v1/evaluate`).
- Redesigned `ui/dashboard.py` into an intuitive underwriter cockpit:
  - **View 1 (Submission Review):** Decision banner, Chief Underwriter Executive Memo, 3 plain-English evidence cards, and interactive Hard Veto override toggle.
  - **View 2 (Risk Engineering):** Sub-panel vs. outdoor temperature drift, sprinkler hydraulic pressure gauge, and aerosol false-alarm filter.
  - **View 3 (Portfolio Monitor):** In-force watchlist with $\Delta S \ge +15.0$ surge alerting and actuarial reserving triggers.
- Verified in `scripts/test_stage5_services.py`.

### ✅ Stage 6: Interactive ML Training Notebook & Baseline Models
- Created `notebooks/01_train_sensor_classifier.ipynb`: Stratified 5-Fold Cross Validation comparing XGBoost, LightGBM, and Random Forest on 305k EN54 and 131k BME688 rows, fitting Isolation Forest, and computing TreeSHAP attributions.
- Serialized baseline models in `models/`:
  - `models/sensor_classifier_xgb.json` (306 KB)
  - `models/sensor_classifier_rf.joblib` (Random Forest champion for SHAP TreeExplainer)
  - `models/iso_forest.joblib` (1.07 MB, Isolation Forest 5D anomaly detector)
- Standalone headless training script in `scripts/train_baseline_models.py`.

### ✅ Stage 7: Automated Pytest Verification Suite
- Built `tests/test_poc_archetypes.py` covering:
  - Archetype 1 Benign Auto-Bind & preferred pricing credit
  - Archetype 2 WUI Wildfire macro surge & Non-Bind status
  - Archetype 3 Undeclared battery fault & Hard Veto trigger
  - Archetype 4 Active portfolio monitoring mid-term degradation alert
  - Hard Veto toggle logic (verifying score difference when veto is disabled vs enabled)
  - HuberRegressor outlier resistance to transient sensor spikes
- **Result: 6/6 tests passing (100% pass rate in 1.30s).**

---

## 6. Git Commit Log & History

All changes are committed cleanly to the `main` branch:

```text
245b1bd (HEAD -> main) feat(stage-6-7): Add interactive ML training notebook, serialized baseline models, and full Pytest verification suite
5c370e0 feat(stage-5): Implement underwriter-centric Streamlit dashboard and FastAPI service
e571f38 feat(stage-4): Implement LangGraph StateGraph orchestrator with AI executive synthesis and validate 4 archetypes
df0906d feat: Initial commit with core architecture, agents, config, and documentation
```

Working tree status: **Clean**.

---

## 7. What's Done vs. What's Left (Next Steps & Future Roadmap)

### What Is 100% Done & Ready Right Now:
- Full end-to-end multi-agent underwriting & active monitoring platform.
- All 4 archetype scenarios, synthetic generators, and micro-benchmark loaders.
- Serialized ML baseline models (`XGBoost`, `RandomForest`, `IsolationForest`) in `models/`.
- Working LangGraph workflow with deterministic actuarial math + AI Executive Memo.
- Fast, intuitive Streamlit dashboard and FastAPI microservice.
- 100% passing automated test suite (`pytest tests/test_poc_archetypes.py`).

### Optional Next Steps (For Future Sessions or Collaborators):
1. **Push to Remote GitHub:**
   - Remote URL: `https://github.com/Divs2930/FireRisk.git`
   - Command: `git push -u origin main` (or `--force` if the remote branch history needs alignment).
2. **Interactive Jupyter Notebook Execution:**
   - If a collaborator wants to execute the full model retraining on the raw Mendeley EN54 and BME688 datasets under step-by-step supervision, run:
     ```bash
     ./.venv/bin/jupyter lab notebooks/01_train_sensor_classifier.ipynb
     ```
3. **Live Hardware Telemetry Ingestion (Production Deployment):**
   - Connect real-time MQTT / WebSocket streams from building BMS systems (Johnson Controls, Honeywell, Siemens Desigo) directly into `IoTSensorAgent`.
4. **Multi-State Geographic Expansion:**
   - Ingest RAWS and ASOS stations for Oregon, Washington, Colorado, and Texas using the existing `data_factory/noaa_ingestor.py` parser.

---

## 8. Quick-Start Command Cheat-Sheet

```bash
# 1. Run Automated Pytest Suite (6/6 tests)
./.venv/bin/pytest tests/test_poc_archetypes.py -v

# 2. Launch Interactive Underwriter Streamlit Dashboard
./.venv/bin/streamlit run ui/dashboard.py

# 3. Launch FastAPI Microservice
./.venv/bin/uvicorn orchestrator.submission_api:app --reload --port 8000
# Docs: http://127.0.0.1:8000/docs

# 4. Run LangGraph Multi-Agent Evaluation Script
./.venv/bin/python scripts/test_stage4_langgraph.py

# 5. Open ML Training Notebook
./.venv/bin/jupyter lab notebooks/01_train_sensor_classifier.ipynb
```
