import sys
import warnings
from pathlib import Path
from fastapi.testclient import TestClient

warnings.filterwarnings("ignore")

# Ensure project root in sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from orchestrator.submission_api import app

print("===================================================================")
print("🚀 STAGE 5 VERIFICATION: FASTAPI SERVICE & STREAMLIT DASHBOARD")
print("===================================================================\n")

client = TestClient(app)

# 1. Health check
print("🔹 [1/5] Testing GET /v1/health...")
r = client.get("/v1/health")
assert r.status_code == 200, f"Health check failed: {r.text}"
data = r.json()
print(f"   Status: {data['status']} | Python: {data['python_version']}")
print(f"   Huber Regressor: {data['ml_engine']['huber_regressor']}")
print("   ✅ Health check passed.\n")

# 2. Archetypes List
print("🔹 [2/5] Testing GET /v1/archetypes...")
r = client.get("/v1/archetypes")
assert r.status_code == 200
archs = r.json()["archetypes"]
assert len(archs) == 4, f"Expected 4 archetypes, got {len(archs)}"
print(f"   Available Archetypes: {[a['id'] + ': ' + a['code'] for a in archs]}")
print("   ✅ Archetype catalog verified.\n")

# 3. California Hotspots
print("🔹 [3/5] Testing GET /v1/hotspots/california...")
r = client.get("/v1/hotspots/california?snapshot_date=2026-10-06")
assert r.status_code == 200
hotspots = r.json()
print(f"   Ranked stations ({hotspots['station_count']}): Top station '{hotspots['rankings'][0]['station']}' with Fire Hazard Index {hotspots['rankings'][0]['fire_hazard_index']}")
print("   ✅ California hotspots ranking verified.\n")

# 4. Underwriting Evaluation (Archetype 1 vs 3 vs 4)
print("🔹 [4/5] Testing POST /v1/evaluate across archetypes...")
# Archetype 1
r1 = client.post("/v1/evaluate", json={"archetype_id": "1", "enable_hard_veto": True})
assert r1.status_code == 200
res1 = r1.json()
print(f"   Archetype 1 Score: {res1['final_hazard_score']:.1f} ({res1['final_risk_tier']}) | Avoidance: {res1['risk_avoidance_action'].split(':')[0]}")
assert res1["final_risk_tier"] == "LOW"
assert not res1["veto_triggered"]

# Archetype 3 (Hard Veto)
r3 = client.post("/v1/evaluate", json={"archetype_id": "3", "enable_hard_veto": True})
assert r3.status_code == 200
res3 = r3.json()
print(f"   Archetype 3 Score: {res3['final_hazard_score']:.1f} ({res3['final_risk_tier']}) | Veto: {res3['veto_triggered']} | Reserving: {res3['reserving_trigger'].split(':')[0]}")
assert res3["final_risk_tier"] == "HIGH"
assert res3["veto_triggered"]
assert res3["final_hazard_score"] >= 75.0

# Archetype 4 (Active Monitoring Delta)
r4 = client.post("/v1/evaluate", json={"archetype_id": "4", "execution_mode": "ACTIVE_MONITORING", "baseline_score": 22.0})
assert r4.status_code == 200
res4 = r4.json()
print(f"   Archetype 4 Score: {res4['final_hazard_score']:.1f} | Delta ΔS: +{res4['score_delta_from_baseline']:.1f} | Action: {res4['risk_avoidance_action'].split(':')[0]}")
assert res4["score_delta_from_baseline"] >= 15.0
print("   ✅ End-to-end API evaluation verified.\n")

# 5. Streamlit Dashboard Syntax and Import Check
print("🔹 [5/5] Testing Streamlit Dashboard compilation...")
import py_compile
py_compile.compile(str(ROOT_DIR / "ui" / "dashboard.py"), doraise=True)
print("   ✅ ui/dashboard.py bytecode compilation verified.\n")

print("===================================================================")
print("🎉 STAGE 5 COMPLETE: FASTAPI SERVICE & STREAMLIT COCKPIT VERIFIED!")
print("===================================================================")

