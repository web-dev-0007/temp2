import os
import sys
import json
from pathlib import Path
import pandas as pd

# Ensure project root is in sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from data_factory.scenario_builder import ScenarioBuilder

def export_samples():
    output_dir = ROOT_DIR / "data_factory" / "generated_samples"
    output_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"Exporting synthetic samples to: {output_dir}")
    sb = ScenarioBuilder(use_llm=False)
    
    archetypes = [
        ("archetype_1_benign", sb.build_archetype_1()),
        ("archetype_2_wui_surge", sb.build_archetype_2()),
        ("archetype_3_internal_fault", sb.build_archetype_3()),
        ("archetype_4_midterm", sb.build_archetype_4()),
    ]
    
    for filename_prefix, bundle in archetypes:
        # Separate DataFrames for CSV export
        telemetry_df = bundle.pop("iot_telemetry", None)
        noaa_df = bundle.pop("noaa_series", None)
        
        # Save JSON metadata, ACORD payload, website scrape, news articles
        json_path = output_dir / f"{filename_prefix}.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(bundle, f, indent=2, default=str)
        print(f"Saved JSON: {json_path.name}")
        
        # Save CSV telemetry
        if telemetry_df is not None:
            csv_path = output_dir / f"{filename_prefix}_telemetry.csv"
            telemetry_df.to_csv(csv_path, index=False)
            print(f"Saved CSV:  {csv_path.name} ({len(telemetry_df)} rows)")
            
        # Save NOAA series
        if noaa_df is not None:
            noaa_csv_path = output_dir / f"{filename_prefix}_noaa.csv"
            noaa_df.to_csv(noaa_csv_path, index=False)
            print(f"Saved CSV:  {noaa_csv_path.name} ({len(noaa_df)} rows)")

if __name__ == "__main__":
    export_samples()
