import os
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from data_factory.scenario_builder import ScenarioBuilder
from data_factory.synthetic_occupancy_gen import SyntheticOccupancyGenerator
from data_factory.synthetic_news_gen import SyntheticNewsGenerator
from data_factory.synthetic_iot_gen import SyntheticIoTGenerator

print("=== STAGE 3 DATA FACTORY VERIFICATION ===")

# Test generators (using offline high-fidelity fallbacks to conserve daily RPD quota, but verifying schema validation)
occ_gen = SyntheticOccupancyGenerator(use_llm=False)
news_gen = SyntheticNewsGenerator(use_llm=False)
iot_gen = SyntheticIoTGenerator(use_llm=False)

# 1. Test Occupancy Generator
occ1 = occ_gen.generate_archetype_1_benign()
occ3 = occ_gen.generate_archetype_3_internal_fault()

print("\n1. Occupancy Generator Verification:")
print(f" - Archetype 1 Insured: {occ1['acord_payload']['named_insured']}")
print(f" - Archetype 1 ISO Class: {occ1['acord_payload']['iso_construction_class']}")
print(f" - Archetype 3 Insured: {occ3['acord_payload']['named_insured']}")
print(f" - Archetype 3 Undeclared Discrepancy Expected: {occ3['expected_discrepancy']}")

# Realism Guardrail Check
text_to_check = [
    occ1["website_scrape_text"],
    occ3["website_scrape_text"],
    occ1["acord_payload"]["occupancy_description"],
    occ3["acord_payload"]["occupancy_description"]
]
for text in text_to_check:
    assert "synthetic" not in text.lower(), f"Violation: 'synthetic' found in text: {text}"
    assert "placeholder" not in text.lower(), f"Violation: 'placeholder' found in text: {text}"
print("   ✅ Realism Guardrail Verified: No 'synthetic' or placeholder tags found.")

# 2. Test News Generator
news1 = news_gen.get_articles_for_archetype_1()
news3 = news_gen.get_articles_for_archetype_3()
print("\n2. News Generator Verification:")
print(f" - Archetype 1 News count: {len(news1)} (Category: {news1[0]['category']})")
print(f" - Archetype 3 News count: {len(news3)} (Category: {news3[0]['category']})")
print(f" - Archetype 3 OSHA citation headline: '{news3[0]['headline']}'")

# 3. Test Hybrid IoT Generator
params_nominal = iot_gen.get_operational_params(None)
params_fault = iot_gen.get_operational_params("combined")
print("\n3. Hybrid IoT Telemetry Framing:")
print(f" - Nominal Panel Base: {params_nominal.panel_base_temp_c}°C, Sprinkler: {params_nominal.sprinkler_initial_psi} PSI")
print(f" - Fault Arcing State: {params_fault.arc_fault_elevated}, Notes: '{params_fault.engineering_notes[:60]}...'")

# 4. Test Scenario Builder
sb = ScenarioBuilder(use_llm=False)
bundles = [
    sb.build_archetype_1(),
    sb.build_archetype_2(),
    sb.build_archetype_3(),
    sb.build_archetype_4()
]
print("\n4. Scenario Builder Bundles:")
for b in bundles:
    print(f" - {b['archetype_id']}: {b['name']} ({len(b['iot_telemetry'])} telemetry rows, {len(b['news_articles'])} news articles)")

print("\n=== STAGE 3 DATA FACTORY FULLY FUNCTIONAL & VERIFIED ===")

