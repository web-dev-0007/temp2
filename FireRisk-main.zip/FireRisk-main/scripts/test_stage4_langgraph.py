import os
import sys
import json
import warnings
from pathlib import Path
import pandas as pd

warnings.filterwarnings("ignore")

# Ensure project root in sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from orchestrator.graph import run_underwriting_workflow
from schemas.contracts import RiskTier

print("===================================================================")
print("🚀 STAGE 4 VERIFICATION: LANGGRAPH ORCHESTRATOR & STATIC BASELINE")
print("===================================================================\n")

samples_dir = ROOT_DIR / "data_factory" / "generated_samples"


def load_sample(archetype_prefix: str) -> dict:
    json_path = samples_dir / f"{archetype_prefix}.json"
    telemetry_path = samples_dir / f"{archetype_prefix}_telemetry.csv"
    noaa_path = samples_dir / f"{archetype_prefix}_noaa.csv"

    with open(json_path, "r", encoding="utf-8") as f:
        payload = json.load(f)

    payload["iot_telemetry"] = pd.read_csv(telemetry_path)
    payload["noaa_series"] = pd.read_csv(noaa_path)
    return payload


# -------------------------------------------------------------------------
# Test 1: Archetype 1 (Benign Commercial Warehouse Baseline)
# -------------------------------------------------------------------------
print("🔹 [Test 1/4] Running Archetype 1: Benign Commercial Logistics Baseline...")
p1 = load_sample("archetype_1_benign")
res1 = run_underwriting_workflow(p1, enable_hard_veto=True)
v1 = res1["final_business_verdict"]

print(f"   Final Hazard Score: {v1.final_hazard_score:.1f}")
print(f"   Final Risk Tier:    {v1.final_risk_tier.value}")
print(f"   Veto Triggered:     {v1.veto_triggered}")
print(f"   Avoidance Action:   {v1.risk_avoidance_action}")
print(f"   Pricing Signal:     {v1.risk_pricing_signal}")
if v1.executive_memo:
    print(f"   🤖 AI Underwriter Summary: {v1.executive_memo.executive_summary[:120]}...")

assert v1.final_risk_tier == RiskTier.LOW, f"Expected LOW risk tier, got {v1.final_risk_tier.value}"
assert v1.final_hazard_score < 36.0, f"Expected score < 36.0, got {v1.final_hazard_score}"
assert not v1.veto_triggered, "Expected veto_triggered == False"
assert "AUTO_BIND_ELIGIBLE" in v1.risk_avoidance_action, "Expected Auto-Bind eligibility"
assert v1.executive_memo is not None, "Expected AI executive memo to be generated"
print("   ✅ Archetype 1 Verified: Low risk, zero veto, auto-bind approved.\n")


# -------------------------------------------------------------------------
# Test 2: Archetype 2 (WUI Residential Home Wildfire Surge)
# -------------------------------------------------------------------------
print("🔹 [Test 2/4] Running Archetype 2: WUI Wildfire Aridity Surge...")
p2 = load_sample("archetype_2_wui_surge")
res2 = run_underwriting_workflow(p2, enable_hard_veto=True)
v2 = res2["final_business_verdict"]

print(f"   Final Hazard Score: {v2.final_hazard_score:.1f}")
print(f"   Final Risk Tier:    {v2.final_risk_tier.value}")
print(f"   Veto Triggered:     {v2.veto_triggered}")
print(f"   Avoidance Action:   {v2.risk_avoidance_action}")
print(f"   Pricing Signal:     {v2.risk_pricing_signal}")

assert v2.final_risk_tier == RiskTier.HIGH, f"Expected HIGH risk tier, got {v2.final_risk_tier.value}"
assert v2.final_hazard_score >= 70.0, f"Expected score >= 70.0, got {v2.final_hazard_score}"
assert not v2.veto_triggered, "Expected veto_triggered == False (External Macro Surge, not internal fault)"
assert "PRE_BIND_DECLINE_HOLD" in v2.risk_avoidance_action, "Expected Decline/Hold on WUI risk"
print("   ✅ Archetype 2 Verified: High macro wildfire risk correctly identified without false internal veto.\n")


# -------------------------------------------------------------------------
# Test 3: Archetype 3 (Internal Fault / Underwriting Deception Hard Veto)
# -------------------------------------------------------------------------
print("🔹 [Test 3/4] Running Archetype 3: Commercial Internal Divergent Fault & Deception...")
p3 = load_sample("archetype_3_internal_fault")
res3 = run_underwriting_workflow(p3, enable_hard_veto=True)
v3 = res3["final_business_verdict"]

print(f"   Final Hazard Score: {v3.final_hazard_score:.1f}")
print(f"   Final Risk Tier:    {v3.final_risk_tier.value}")
print(f"   Veto Triggered:     {v3.veto_triggered}")
print(f"   Avoidance Action:   {v3.risk_avoidance_action}")
print(f"   Pricing Signal:     {v3.risk_pricing_signal}")
print(f"   Reserving Trigger:  {v3.reserving_trigger}")
if v3.executive_memo:
    print(f"   🤖 AI Underwriter Memo: {v3.executive_memo.executive_summary[:120]}...")
    print(f"   🤖 Synthesis: {v3.executive_memo.key_risk_synthesis[:140]}...")

assert v3.final_risk_tier == RiskTier.HIGH, f"Expected HIGH risk tier, got {v3.final_risk_tier.value}"
assert v3.final_hazard_score >= 75.0, f"Expected Hard Veto score >= 75.0, got {v3.final_hazard_score}"
assert v3.veto_triggered, "Expected veto_triggered == True"
assert "PRE_BIND_DECLINE_HOLD" in v3.risk_avoidance_action, "Expected Pre-Bind Decline/Hold"
assert "ACUTE_STEP_UP" in v3.reserving_trigger, "Expected 2.0x reserve step up"
assert v3.executive_memo is not None, "Expected AI executive memo to be generated"
print("   ✅ Archetype 3 Verified: Hard Veto override triggered (Score >= 75.0), immediate decline hold.\n")


# -------------------------------------------------------------------------
# Test 4: Archetype 4 (Active Monitoring Mid-Term Operational Surge)
# -------------------------------------------------------------------------
print("🔹 [Test 4/4] Running Archetype 4: Active Monitoring Mid-Term Degradation...")
p4 = load_sample("archetype_4_midterm")
p4["execution_mode"] = "ACTIVE_MONITORING"
p4["baseline_score"] = 22.0
res4 = run_underwriting_workflow(p4, enable_hard_veto=True)
v4 = res4["final_business_verdict"]

print(f"   Baseline Score:     22.0")
print(f"   Final Hazard Score: {v4.final_hazard_score:.1f}")
print(f"   Score Delta (ΔS):   +{v4.score_delta_from_baseline:.1f}")
print(f"   Avoidance Action:   {v4.risk_avoidance_action}")
print(f"   Reserving Trigger:  {v4.reserving_trigger}")

assert v4.score_delta_from_baseline is not None, "Expected score_delta_from_baseline to be calculated"
assert v4.score_delta_from_baseline >= 15.0, f"Expected ΔS >= 15.0, got {v4.score_delta_from_baseline}"
assert "EMERGENCY_LOSS_CONTROL_DISPATCH" in v4.risk_avoidance_action, "Expected Emergency Loss-Control Dispatch"
assert "ACUTE_STEP_UP" in v4.reserving_trigger, "Expected 2.0x reserve step up on active monitoring spike"
print("   ✅ Archetype 4 Verified: Active monitoring delta alert triggered (ΔS >= +15.0), emergency dispatch & IBNR surge.\n")

print("===================================================================")
print("🎉 STAGE 4 COMPLETE: ALL 4 CANONICAL ARCHETYPES FULLY VALIDATED!")
print("===================================================================")

