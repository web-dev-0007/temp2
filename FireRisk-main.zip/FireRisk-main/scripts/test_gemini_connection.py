import os
import sys
import warnings
from pathlib import Path

# Suppress non-critical environment / SDK deprecation warnings for cleaner output
warnings.filterwarnings("ignore")

# Ensure project root is in sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from pydantic import BaseModel, Field
from langchain_google_genai import ChatGoogleGenerativeAI
from config.loader import load_settings

# 1. Load API Key from .env
env_path = Path(__file__).resolve().parent.parent / ".env"
if env_path.exists():
    with open(env_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                k = k.strip()
                v = v.strip().strip("'").strip('"')
                os.environ[k] = v
                if k == "GEMINI_API_KEY":
                    os.environ["GOOGLE_API_KEY"] = v

api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")

if not api_key:
    print("❌ Error: GEMINI_API_KEY not found in .env file.")
    exit(1)

print("🔑 GEMINI_API_KEY successfully detected from .env.")

# 2. Load model settings
settings = load_settings()
lite_model = settings.get("gemini_config", {}).get("lite_model", "gemini-3.5-flash-lite")

# 3. Define structured output schema for test
class ConnectionVerification(BaseModel):
    status: str = Field(description="Operational status, e.g. 'ONLINE' or 'CONNECTED'")
    model_echo: str = Field(description="The model name responding to the request")
    latency_note: str = Field(description="A brief confirmation message")
    structured_test_passed: bool = Field(description="True if structured parsing succeeded")

print(f"\n🚀 Testing LangChain Structured Output with lite model: '{lite_model}'...")

try:
    llm = ChatGoogleGenerativeAI(
        model=lite_model,
        google_api_key=api_key,
        temperature=0.1,
        timeout=30
    )

    structured_llm = llm.with_structured_output(ConnectionVerification)
    
    prompt = (
        f"You are verifying the LangChain connection for Fire Risk AI. "
        f"Confirm that you are running as '{lite_model}' and return structured verification."
    )
    
    result = structured_llm.invoke(prompt)
    
    print("\n✅ LangChain Structured Output Verification Succeeded!")
    print(f"Status: {result.status}")
    print(f"Model Echo: {result.model_echo}")
    print(f"Note: {result.latency_note}")
    print(f"Structured Parsing Passed: {result.structured_test_passed}")
    print("\nLite model is ready for Stage 3 data generation tasks.")

except Exception as e:
    print(f"\n❌ Test Failed with '{lite_model}': {e}")
    print("\nTip: If rate-limited (429), wait 60 seconds. Note constraints: 15 RPM, 500 RPD for lite model.")
