import os
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.ensemble import RandomForestClassifier, IsolationForest
import lightgbm as lgb
import joblib

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

models_dir = ROOT_DIR / "models"
models_dir.mkdir(parents=True, exist_ok=True)

print("=== FITTING BASELINE ML MODELS ===")

# -------------------------------------------------------------------------
# 1. Fit Multi-Class Sensor Classifier
# -------------------------------------------------------------------------
# Features: [en54_h2_ppm, en54_co_ppm, smoke_ppm, bme_outdoor_smoke_index]
# Classes:
# 0: Clean / Nominal Air
# 1: Cable Overload (Electrical Precursor)
# 2: Nuisance Aerosol (False Alarm)
# 3: Outdoor Smoke Plume (Wildfire)

np.random.seed(42)
n_samples = 3000

# Class 0: Clean
c0_h2 = np.random.uniform(0.0, 0.05, n_samples)
c0_co = np.random.uniform(0.0, 0.05, n_samples)
c0_smoke = np.random.uniform(0.0, 0.01, n_samples)
c0_bme = np.random.uniform(0.0, 0.15, n_samples)
X0 = np.column_stack([c0_h2, c0_co, c0_smoke, c0_bme])
y0 = np.zeros(n_samples, dtype=int)

# Class 1: Cable Overload (NHXMH pyrolytic outgassing)
c1_h2 = np.random.uniform(0.50, 2.50, n_samples)
c1_co = np.random.uniform(0.40, 2.00, n_samples)
c1_smoke = np.random.uniform(0.10, 0.80, n_samples)
c1_bme = np.random.uniform(0.05, 0.30, n_samples)
X1 = np.column_stack([c1_h2, c1_co, c1_smoke, c1_bme])
y1 = np.ones(n_samples, dtype=int)

# Class 2: Nuisance Aerosol (Deodorant, hairspray - high particulate, zero H2/CO)
c2_h2 = np.random.uniform(0.0, 0.08, n_samples)
c2_co = np.random.uniform(0.0, 0.08, n_samples)
c2_smoke = np.random.uniform(0.02, 0.25, n_samples)
c2_bme = np.random.uniform(0.02, 0.20, n_samples)
X2 = np.column_stack([c2_h2, c2_co, c2_smoke, c2_bme])
y2 = np.full(n_samples, 2, dtype=int)

# Class 3: Wildfire Perimeter Plume
c3_h2 = np.random.uniform(0.0, 0.10, n_samples)
c3_co = np.random.uniform(0.05, 0.25, n_samples)
c3_smoke = np.random.uniform(0.08, 0.50, n_samples)
c3_bme = np.random.uniform(0.70, 0.99, n_samples)
X3 = np.column_stack([c3_h2, c3_co, c3_smoke, c3_bme])
y3 = np.full(n_samples, 3, dtype=int)

X = np.vstack([X0, X1, X2, X3])
y = np.concatenate([y0, y1, y2, y3])

# Fit XGBoost
xgb_clf = xgb.XGBClassifier(
    n_estimators=50,
    max_depth=3,
    learning_rate=0.1,
    random_state=42,
    eval_metric="mlogloss"
)
xgb_clf.fit(X, y)
xgb_out = models_dir / "sensor_classifier_xgb.json"
xgb_clf.save_model(str(xgb_out))
print(f"✅ Saved XGBoost Classifier to: {xgb_out}")

# Fit Random Forest (Fully compatible with SHAP TreeExplainer)
rf_clf = RandomForestClassifier(n_estimators=50, max_depth=5, random_state=42)
rf_clf.fit(X, y)
rf_out = models_dir / "sensor_classifier_rf.joblib"
joblib.dump(rf_clf, str(rf_out))
print(f"✅ Saved Random Forest Classifier to: {rf_out}")

# -------------------------------------------------------------------------
# 2. Fit Isolation Forest for Multivariate Anomaly Detection
# -------------------------------------------------------------------------
n_norm = 5000
noaa_temp = np.random.uniform(15.0, 35.0, n_norm)
panel_temp = noaa_temp + np.random.normal(5.0, 1.5, n_norm)
sprinkler_psi = np.random.normal(65.0, 2.0, n_norm)
arc_faults = np.random.poisson(0.1, n_norm)
load_kw = np.random.normal(45.0, 5.0, n_norm)
X_nominal = np.column_stack([panel_temp, sprinkler_psi, arc_faults, load_kw, noaa_temp])

n_fault = 300
f_noaa = np.random.uniform(15.0, 25.0, n_fault)
f_panel = f_noaa + np.random.uniform(15.0, 30.0, n_fault)
f_sprinkler = np.random.uniform(15.0, 38.0, n_fault)
f_arc = np.random.randint(5, 50, n_fault)
f_load = np.random.uniform(70.0, 120.0, n_fault)
X_fault = np.column_stack([f_panel, f_sprinkler, f_arc, f_load, f_noaa])

X_iso = np.vstack([X_nominal, X_fault])

iso_forest = IsolationForest(
    n_estimators=50,
    contamination=0.05,
    random_state=42
)
iso_forest.fit(X_iso)
iso_out = models_dir / "iso_forest.joblib"
joblib.dump(iso_forest, str(iso_out))
print(f"✅ Saved Isolation Forest to: {iso_out}")

print("\n=== BASELINE ML MODELS SUCCESSFULLY FITTED & SERIALIZED ===")
