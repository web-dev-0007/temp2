from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, Field


class LOBType(str, Enum):
    COMMERCIAL = "COMMERCIAL"
    RESIDENTIAL = "RESIDENTIAL"


class RiskTier(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class ExecutionMode(str, Enum):
    SUBMISSION_RENEWAL = "SUBMISSION_RENEWAL"
    ACTIVE_MONITORING = "ACTIVE_MONITORING"


class RiskDriver(BaseModel):
    driver_code: str = Field(..., description="Standardized code, e.g., IOT_THERMAL_ANOMALY")
    severity: RiskTier
    is_critical_veto_candidate: bool = Field(
        default=False,
        description="True if this single finding warrants a HIGH verdict when hard_veto is enabled"
    )
    description: str = Field(..., description="Audit explanation citing exact metrics or text evidence")


class AgentVerdict(BaseModel):
    agent_id: str
    property_id: str
    lob: LOBType
    risk_tier: RiskTier
    hazard_score: float = Field(..., ge=0.0, le=100.0, description="0-35.9 LOW, 36-69.9 MEDIUM, 70-100 HIGH")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Data completeness and certainty score")
    risk_drivers: List[RiskDriver]


class UnderwritingExecutiveMemo(BaseModel):
    executive_summary: str = Field(..., description="High-level 2-sentence summary of the underwriting recommendation")
    key_risk_synthesis: str = Field(..., description="Synthesized narrative connecting building COPE, operational reality, sensor trends, and regulatory citations")
    underwriting_directive: str = Field(..., description="Actionable directives for the underwriter or loss control engineer")
    conditions_or_remediation: List[str] = Field(default_factory=list, description="Mandatory binding conditions, warranty endorsements, or engineering remediations")


class BusinessImpactVerdict(BaseModel):
    property_id: str
    lob: LOBType
    execution_mode: ExecutionMode
    final_hazard_score: float
    final_risk_tier: RiskTier
    aggregate_confidence: float
    veto_triggered: bool
    score_delta_from_baseline: Optional[float] = None
    risk_avoidance_action: str
    risk_pricing_signal: str
    reserving_trigger: str
    audit_trail: List[str]
    executive_memo: Optional[UnderwritingExecutiveMemo] = None
