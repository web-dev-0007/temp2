from pathlib import Path
import yaml
from typing import Any, Dict

CONFIG_PATH = Path(__file__).parent / "settings.yaml"

def load_settings() -> Dict[str, Any]:
    if not CONFIG_PATH.exists():
        raise FileNotFoundError(f"Configuration file not found at {CONFIG_PATH}")
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

