import os
import sys
import json
from pathlib import Path
from typing import Dict, Any, List, Optional
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

# Ensure project root in sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from schemas.contracts import LOBType, ExecutionMode, RiskTier, UnderwritingExecutiveMemo
from orchestrator.graph import run_underwriting_workflow
from agents.poc_fire_risk_detector import fit_and_detect_residual_anomalies

st.set_page_config(
    page_title="Fire Risk AI — Commercial & Residential Underwriter Cockpit",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

SAMPLES_DIR = ROOT_DIR / "data_factory" / "generated_samples"


# -------------------------------------------------------------------------
# Helper Functions
# -------------------------------------------------------------------------
@st.cache_data
def load_archetype_data(prefix: str):
    json_path = SAMPLES_DIR / f"{prefix}.json"
    telemetry_path = SAMPLES_DIR / f"{prefix}_telemetry.csv"
    noaa_path = SAMPLES_DIR / f"{prefix}_noaa.csv"

    payload = {}
    if json_path.exists():
        with open(json_path, "r", encoding="utf-8") as f:
            payload = json.load(f)

    telemetry_df = pd.read_csv(telemetry_path) if telemetry_path.exists() else pd.DataFrame()
    noaa_df = pd.read_csv(noaa_path) if noaa_path.exists() else pd.DataFrame()

    payload["iot_telemetry"] = telemetry_df
    payload["noaa_series"] = noaa_df
    return payload


# -------------------------------------------------------------------------
# Sidebar Navigation & Context
# -------------------------------------------------------------------------
st.sidebar.image("https://img.icons8.com/fluency/96/shield.png", width=64)
st.sidebar.title("Underwriter Cockpit")
st.sidebar.caption("Fire Risk AI — P&C Insurance Decision System")

view_selection = st.sidebar.radio(
    "Workflow Navigation",
    [
        "1. 📋 Underwriting Submission Review",
        "2. 🔍 Risk Engineering & Sensor Proof",
        "3. 🔔 Active Portfolio Risk Monitor"
    ]
)

st.sidebar.markdown("---")
st.sidebar.markdown("### 💡 Underwriter Quick Guide")
st.sidebar.markdown(
    """
    **Three Decision Questions:**
    1. **Can I bind?** *(Auto-Bind, Hold, or Decline)*
    2. **What terms?** *(-10% credit vs +100% debit)*
    3. **What is the smoking gun?** *(Undeclared battery welding, electrical arcing, or dry WUI brush)*
    
    **Deterministic Safety:**
    - Scores and veto rules are 100% mathematical (Scikit-Learn + actuarial rules).
    - Executive briefings are synthesized by **AI Chief Underwriter** on top of verified facts.
    """
)


# =========================================================================
# VIEW 1: 📋 Underwriting Submission Review (The Core Cockpit)
# =========================================================================
if view_selection == "1. 📋 Underwriting Submission Review":
    st.title("📋 Underwriting Submission Review & AI Executive Briefing")
    st.markdown(
        "Evaluate commercial and residential property applications using **fused multi-source intelligence**: "
        "ACORD disclosures, real-world operational web footprint, building IoT sensors, and local regulatory records."
    )

    # Submission Selector & Controls
    col_sel1, col_sel2, col_sel3 = st.columns([2, 1, 1])

    with col_sel1:
        eval_choice = st.selectbox(
            "Select Property Submission to Underwrite:",
            [
                "Case 1: Pacific Harbor Logistics (Clean Modern Distribution Warehouse)",
                "Case 2: Pine Ridge Canyon Residence (High WUI Wildfire Zone Home)",
                "Case 3: Apex Storage & Supply (Undeclared Lithium-Ion Battery Assembly)",
                "Case 4: Valley Oak Craft Roasters (Commercial Facility Mid-Term Review)"
            ]
        )

    with col_sel2:
        exec_mode = st.selectbox(
            "Review Mode:",
            ["SUBMISSION_RENEWAL (New Business/Quote)", "ACTIVE_MONITORING (In-Force Policy Scan)"]
        )

    with col_sel3:
        hard_veto_active = st.toggle(
            "Regulatory Hard Veto Protection",
            value=True,
            help=(
                "When enabled, an acute internal electrical fault or fraudulent operational disclosure "
                "triggers an automatic regulatory floor (Score >= 75.0), preventing high-risk policies from being bound. "
                "Toggle OFF to compare against standard weighted averaging."
            )
        )

    # Map choice to payload
    prefix_map = {
        "Case 1: Pacific Harbor Logistics (Clean Modern Distribution Warehouse)": "archetype_1_benign",
        "Case 2: Pine Ridge Canyon Residence (High WUI Wildfire Zone Home)": "archetype_2_wui_surge",
        "Case 3: Apex Storage & Supply (Undeclared Lithium-Ion Battery Assembly)": "archetype_3_internal_fault",
        "Case 4: Valley Oak Craft Roasters (Commercial Facility Mid-Term Review)": "archetype_4_midterm"
    }
    selected_prefix = prefix_map[eval_choice]
    payload = load_archetype_data(selected_prefix)

    # Execution mode handling
    if "ACTIVE_MONITORING" in exec_mode:
        payload["execution_mode"] = "ACTIVE_MONITORING"
        payload["baseline_score"] = payload.get("baseline_score", 22.0)
    else:
        payload["execution_mode"] = "SUBMISSION_RENEWAL"
        payload["baseline_score"] = None

    # Property Dossier Banner
    acord = payload.get("occupancy_data", {}).get("acord_payload", payload.get("acord_payload", {}))
    st.markdown("---")
    st.subheader(f"🏢 Property Dossier: {acord.get('named_insured', payload.get('name', 'Insured Facility'))}")

    info_c1, info_c2, info_c3, info_c4 = st.columns(4)
    with info_c1:
        st.caption("Address & Line of Business")
        st.write(f"📍 **{acord.get('property_address', 'California')}**")
        st.write(f"📂 **{payload.get('lob', 'COMMERCIAL')}** ({acord.get('form_type', 'ACORD')})")
    with info_c2:
        st.caption("Construction & Vintage")
        st.write(f"🏗️ **{acord.get('iso_construction_class', 'Unknown')}**")
        st.write(f"📅 Built: **{acord.get('year_built', 'N/A')}** | Roof: **{acord.get('roof_type', 'Standard')}**")
    with info_c3:
        st.caption("Protection & Suppression")
        sprinkler = acord.get("sprinkler_system", {})
        sprinkler_str = "✅ NFPA 13 (100% Coverage)" if sprinkler.get("installed") and sprinkler.get("coverage_pct", 0) >= 90 else "⚠️ Partial / Deficient"
        st.write(f"💧 **{sprinkler_str}**")
        st.write(f"🧯 Hydrant: **{acord.get('fire_hydrant_distance_feet', 500)} ft** | PPC: **Class {acord.get('iso_ppc_rating', 4)}**")
    with info_c4:
        st.caption("Declared Operation")
        st.write(f"📝 *\"{acord.get('occupancy_description', 'Standard retail storage')}\"*")

    # Run Underwriting Engine Button
    if st.button("⚡ Evaluate Submission & Synthesize Underwriting Decision", type="primary", use_container_width=True):
        with st.spinner("Executing Multi-Agent Evaluation & Senior Underwriter AI Synthesis..."):
            result_state = run_underwriting_workflow(payload, enable_hard_veto=hard_veto_active)
            final_v = result_state["final_business_verdict"]
            memo: Optional[UnderwritingExecutiveMemo] = final_v.executive_memo

        # -------------------------------------------------------------
        # Decision Banner
        # -------------------------------------------------------------
        st.markdown("---")
        tier = final_v.final_risk_tier
        score = final_v.final_hazard_score
        veto = final_v.veto_triggered

        if tier == RiskTier.LOW:
            st.success(f"### 🟢 VERDICT: AUTO-BIND APPROVED (Hazard Score: {score:.1f} / 100 — LOW RISK)", icon="✅")
        elif tier == RiskTier.MEDIUM:
            st.warning(f"### 🟠 VERDICT: CONDITIONAL BIND ON WARRANTY (Hazard Score: {score:.1f} / 100 — MEDIUM RISK)", icon="⚠️")
        else:
            if veto:
                st.error(f"### 🔴 VERDICT: PRE-BIND DECLINE / HOLD — REGULATORY HARD VETO TRIGGERED (Score: {score:.1f} / 100)", icon="🚨")
            else:
                st.error(f"### 🔴 VERDICT: PRE-BIND DECLINE / HOLD — CRITICAL WILDFIRE PERIL (Score: {score:.1f} / 100 — HIGH RISK)", icon="🚨")

        with st.container(border=True):
            col_b1, col_b2, col_b3 = st.columns(3)
            with col_b1:
                st.markdown(f"**Underwriting Action:**\n\n`{final_v.risk_avoidance_action.split(':')[0]}`")
                st.caption(final_v.risk_avoidance_action)
            with col_b2:
                st.markdown(f"**Technical Pricing Signal:**\n\n`{final_v.risk_pricing_signal.split(':')[0]}`")
                st.caption(final_v.risk_pricing_signal)
            with col_b3:
                st.markdown(f"**Actuarial Reserving Trigger:**\n\n`{final_v.reserving_trigger.split(':')[0]}`")
                st.caption(final_v.reserving_trigger)

        # -------------------------------------------------------------
        # 🤖 AI Senior Underwriting Executive Briefing (The Centerpiece)
        # -------------------------------------------------------------
        st.markdown("### 🤖 Senior Underwriter AI Executive Briefing")
        if memo:
            with st.container():
                st.markdown(f"> **Executive Bottom Line:** {memo.executive_summary}")
                st.markdown(f"**Detailed Risk Synthesis:**\n\n{memo.key_risk_synthesis}")
                
                col_m_left, col_m_right = st.columns([1, 1])
                with col_m_left:
                    st.markdown("**Actionable Underwriting Directive:**")
                    st.info(memo.underwriting_directive)
                with col_m_right:
                    st.markdown("**Mandatory Binding Conditions / Remediation List:**")
                    for cond in memo.conditions_or_remediation:
                        st.markdown(f"• {cond}")
        else:
            st.info("Executive synthesis memo ready.")

        st.markdown("---")

        # -------------------------------------------------------------
        # The Three Plain-English Evidence Cards
        # -------------------------------------------------------------
        st.subheader("🔍 Fused Evidence Breakdown: Why Was This Decision Reached?")
        card_c1, card_c2, card_c3 = st.columns(3)

        # Card 1: Operational Footprint & Deception Check
        with card_c1:
            st.markdown("#### 1. 🏢 Occupancy & Deception Check")
            occ_v = result_state.get("occupancy_verdict")
            if occ_v:
                st.metric("Occupancy Hazard Score", f"{occ_v.hazard_score:.1f} / 100", occ_v.risk_tier.value)
                web_text = payload.get("occupancy_data", {}).get("website_scrape_text", payload.get("website_scrape_text", ""))
                
                with st.expander("Compare Declared vs Discovered Operations", expanded=True):
                    st.markdown("**Declared on ACORD Form:**")
                    st.code(acord.get("occupancy_description", "Dry retail goods"), language="text")
                    st.markdown("**Discovered on Official Website:**")
                    st.code(web_text[:280] + ("..." if len(web_text) > 280 else ""), language="text")

                for d in occ_v.risk_drivers:
                    badge = "🚨" if d.is_critical_veto_candidate else "ℹ️"
                    st.caption(f"{badge} **{d.driver_code}**: {d.description}")

        # Card 2: Physical Sensor & Maintenance Health
        with card_c2:
            st.markdown("#### 2. ⚡ Equipment & Sensor Health")
            iot_v = result_state.get("iot_verdict")
            if iot_v:
                st.metric("IoT Sensor Hazard Score", f"{iot_v.hazard_score:.1f} / 100", iot_v.risk_tier.value)
                
                # Highlight key metrics in plain English
                telemetry = payload.get("iot_telemetry")
                if isinstance(telemetry, pd.DataFrame) and not telemetry.empty:
                    latest = telemetry.iloc[-1]
                    psi = latest.get("sprinkler_psi", 65.0)
                    arcs = telemetry["arc_fault_count"].sum()
                    max_temp = telemetry["panel_temp_c"].max()
                    
                    st.markdown(f"• **Sprinkler Pressure:** `{psi:.1f} PSI` " + ("⚠️ Loss of Pressure" if psi < 40 else "✅ Normal Pressure"))
                    st.markdown(f"• **24-Hour Arc Faults:** `{arcs}` electrical arcing events")
                    st.markdown(f"• **Peak Panel Temp:** `{max_temp:.1f}°C`")

                for d in iot_v.risk_drivers:
                    badge = "🚨" if d.is_critical_veto_candidate else "ℹ️"
                    st.caption(f"{badge} **{d.driver_code}**: {d.description}")

        # Card 3: Location, Weather & Regulatory Intel
        with card_c3:
            st.markdown("#### 3. 🌲 Location, Weather & Citations")
            news_v = result_state.get("news_verdict")
            if news_v:
                st.metric("External Peril Hazard Score", f"{news_v.hazard_score:.1f} / 100", news_v.risk_tier.value)
                
                raws_fuel = payload.get("raws_10hr_fuel_moisture_pct", 12.0)
                st.markdown(f"• **Dead Fuel Moisture:** `{raws_fuel:.1f}%` " + ("🔥 Extreme Aridity (<6%)" if raws_fuel < 6.0 else "✅ Normal"))
                
                articles = payload.get("news_articles", [])
                st.markdown(f"• **5-Mile Local Adverse News:** {len(articles)} events detected")
                for a in articles:
                    cat_emoji = "⚠️" if "OSHA" in a.get("category", "") or "WATER" in a.get("category", "") else "ℹ️"
                    st.caption(f"{cat_emoji} **{a.get('category')}**: {a.get('headline')} ({a.get('days_ago', 0):.0f}d ago)")

        # Expandable Actuarial Audit Trail
        with st.expander("🔍 View Actuarial Calculation Math & Confidence Weights", expanded=False):
            st.markdown("##### Actuarial Confidence-Weighted Calculation:")
            for line in final_v.audit_trail:
                st.code(line, language="text")

            st.markdown("##### Orchestrator Node Execution Logs:")
            for l in result_state.get("execution_logs", []):
                st.text(l)


# =========================================================================
# VIEW 2: 🔍 Risk Engineering & Sensor Proof
# =========================================================================
elif view_selection == "2. 🔍 Risk Engineering & Sensor Proof":
    st.title("🔍 Risk Engineering & Sensor Diagnostics")
    st.markdown(
        "Inspect the physical sensor telemetry proving equipment failure or verifying false-alarm suppression. "
        "Designed for underwriters needing concrete physical proof before issuing declination notices."
    )

    case_diag = st.selectbox(
        "Select Case for Physical Diagnostic Inspection:",
        [
            "Case 3: Apex Storage (Undeclared Battery Assembly — Internal Divergent Thermal Runaway)",
            "Case 1: Pacific Harbor (Clean Warehouse — Aerosol Nuisance False Alarm Rejection)",
            "Case 2: Pine Ridge Residence (Canyon Wildfire Weather & Perimeter Smoke Plume)",
            "Case 4: Valley Oak Roasters (Active Monitoring Municipal Water Main Collapse)"
        ]
    )

    prefix_map = {
        "Case 3: Apex Storage (Undeclared Battery Assembly — Internal Divergent Thermal Runaway)": "archetype_3_internal_fault",
        "Case 1: Pacific Harbor (Clean Warehouse — Aerosol Nuisance False Alarm Rejection)": "archetype_1_benign",
        "Case 2: Pine Ridge Residence (Canyon Wildfire Weather & Perimeter Smoke Plume)": "archetype_2_wui_surge",
        "Case 4: Valley Oak Roasters (Active Monitoring Municipal Water Main Collapse)": "archetype_4_midterm"
    }

    selected_prefix = prefix_map[case_diag]
    data_bundle = load_archetype_data(selected_prefix)
    telemetry_df: pd.DataFrame = data_bundle["iot_telemetry"]

    if telemetry_df.empty:
        st.warning("Telemetry series not available.")
    else:
        # Run Huber anomaly detector
        huber_res = fit_and_detect_residual_anomalies(
            noaa_temp=telemetry_df["noaa_temp_c"],
            panel_temp=telemetry_df["panel_temp_c"],
            z_threshold=3.0
        )

        st.markdown("---")
        st.subheader("1. Is the Electrical Equipment Overheating on Its Own?")
        st.caption("Underwriters look for thermal divergence: when sub-panels climb while outdoor weather is cold or steady.")

        col_d1, col_d2, col_d3 = st.columns(3)
        with col_d1:
            st.metric("Max Thermal Divergence (Z-Score)", f"{huber_res['max_z_score']:.2f}", "Threshold: > 3.0 Anomaly")
        with col_d2:
            st.metric("Equipment vs Weather Tracking Slope (β)", f"{huber_res['beta']:.4f} °C/°C")
        with col_d3:
            if huber_res["is_divergent_fault"]:
                st.error("🚨 CRITICAL INTERNAL ANOMALY CONFIRMED")
            else:
                st.success("✅ NOMINAL THERMAL TRACKING CONFIRMED")

        # Plotly chart: Panel vs Ambient
        fig_temp = go.Figure()
        fig_temp.add_trace(go.Scatter(
            y=telemetry_df["panel_temp_c"],
            name="Electrical Sub-Panel Temp (°C)",
            line=dict(color="red", width=2.5)
        ))
        fig_temp.add_trace(go.Scatter(
            y=telemetry_df["noaa_temp_c"],
            name="Outdoor NOAA Ambient Temp (°C)",
            line=dict(color="blue", dash="dash", width=2)
        ))
        fig_temp.update_layout(
            title="Electrical Sub-Panel Temperature vs Outdoor Weather (°C) Over 72 Hours",
            xaxis_title="Hours Elapsed",
            yaxis_title="Temperature (°C)",
            height=350
        )
        st.plotly_chart(fig_temp, use_container_width=True)

        st.markdown("---")
        st.subheader("2. Fire Sprinkler Water Suppression System Status")
        st.caption("Commercial fire sprinkler systems must maintain static hydrostatic pressure above 40 PSI.")

        fig_sprinkler = go.Figure()
        fig_sprinkler.add_trace(go.Scatter(
            y=telemetry_df["sprinkler_psi"],
            name="Sprinkler Pressure (PSI)",
            line=dict(color="teal", width=2.5)
        ))
        fig_sprinkler.add_hline(
            y=40.0,
            line_dash="dot",
            line_color="crimson",
            annotation_text="Critical Failure Threshold (<40 PSI)"
        )
        fig_sprinkler.update_layout(
            title="Fire Sprinkler Main Riser Static Pressure (PSI)",
            xaxis_title="Hours Elapsed",
            yaxis_title="Hydrostatic Pressure (PSI)",
            height=300
        )
        st.plotly_chart(fig_sprinkler, use_container_width=True)

        st.markdown("---")
        st.subheader("3. False Alarm Suppression (EN54 Gas & Particulate Filter)")
        st.info(
            "**How the AI avoids false alarms:** When indoor particulate sensors detect an aerosol cloud (cooking, cleaning spray, or deodorant), "
            "standard dumb detectors alarm. Our AI cross-checks hydrogen ($H_2$) and carbon monoxide ($CO$) insulation outgassing. "
            "If $H_2$ and $CO$ remain flat (0.0 ppm), the system classifies it as a **BENIGN NUISANCE AEROSOL** and suppresses false alerts."
        )


# =========================================================================
# VIEW 3: 🔔 Active Portfolio Risk Monitor (Mid-Term In-Force Watch)
# =========================================================================
elif view_selection == "3. 🔔 Active Portfolio Risk Monitor":
    st.title("🔔 Active Portfolio Risk Monitor")
    st.markdown(
        "Continuous underwriting monitor scanning in-force policies for **mid-term risk degradation ($\Delta S \ge +15.0$)**. "
        "Automatically dispatches loss-control engineers and steps up actuarial catastrophe loss reserves before claims occur."
    )

    st.markdown("### ⚠️ Active In-Force Portfolio Surge Alerts")

    # In-Force Policy Table
    portfolio_data = [
        {
            "Policy Number": "POL-CA-2026-9041",
            "Named Insured": "Valley Oak Craft Roasters",
            "Location": "150 Mendocino Ave, Ukiah, CA",
            "Bound Baseline Score": 22.0,
            "Current Active Score": 75.0,
            "Score Delta (ΔS)": "+53.0",
            "Status": "🚨 EMERGENCY DISPATCH",
            "Primary Driver": "Municipal water main break collapsed hydrant & sprinkler pressure to 28 PSI"
        },
        {
            "Policy Number": "POL-CA-2026-1082",
            "Named Insured": "Pacific Harbor Logistics LLC",
            "Location": "1200 Coastal Blvd, Los Angeles, CA",
            "Bound Baseline Score": 11.4,
            "Current Active Score": 12.0,
            "Score Delta (ΔS)": "+0.6",
            "Status": "✅ STABLE / PREFERRED",
            "Primary Driver": "Nominal operations verified"
        }
    ]
    st.dataframe(pd.DataFrame(portfolio_data), use_container_width=True, hide_index=True)

    st.markdown("---")
    st.subheader("Mid-Term Degradation Case Study: Valley Oak Craft Roasters")

    col_cs1, col_cs2 = st.columns([1, 1])
    with col_cs1:
        st.markdown("#### What Happened Mid-Term?")
        st.markdown(
            """
            - **Initial Binding:** Bound at low risk (Score: `22.0`) with Class 3 Non-Combustible construction and 100% sprinkler coverage.
            - **External Incident:** 16-inch municipal water transmission main ruptured beneath Mendocino Ave.
            - **Physical Impact:** Fire sprinkler riser pressure plummeted from 65 PSI down to `28.0 PSI` (loss of suppression capacity).
            - **Electrical Impact:** Repeated PG&E substation voltage surges triggered industrial equipment thermal cycling.
            """
        )
    with col_cs2:
        st.markdown("#### Actuarial & Underwriting Action Taken")
        st.error(
            """
            **1. Emergency Loss-Control Dispatch:**
            Automated work order issued to local risk engineer to inspect building riser valves and verify secondary water booster pump.

            **2. Actuarial IBNR Step-Up:**
            Loss reserve stepped up to **2.0x base factor** immediately, allocating a catastrophe buffer on this account.
            """
        )
