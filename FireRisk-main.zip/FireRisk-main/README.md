# 🔥 Fire Risk AI — Multi-Agent Underwriting & Active Portfolio Monitoring Platform

An intelligent, multi-agent Property & Casualty (P&C) insurance fire peril underwriting and active portfolio monitoring platform for Commercial and Residential properties.

The platform fuses **classical, interpretable machine learning** (Scikit-Learn `HuberRegressor`, `IsolationForest`, `XGBoost`/`LightGBM`, `TreeSHAP`) with **LangChain Gemini structured output agents** (`gemini-3.8-flash`, `gemini-3.6-flash`, `gemini-3.5-flash-lite`), capped by a **100% deterministic actuarial decision engine** with a safety-critical **Hard Veto** override and an **AI Senior Underwriter Executive Memo**.

---

## 🏛️ System Architecture

```mermaid
flowchart TD
    subgraph S1["Phase 1: Input & LOB Context Router"]
        A["Submission Payload (ACORD / IoT / NOAA / News)"] --> B["Entity & LOB Router"]
        B -->|Commercial / Residential Rules| C["Context Package"]
    end

    subgraph S2["Phase 2: Parallel Specialist Agents"]
        C --> D["IoT Sensor Agent (Huber + IsoForest + XGBoost)"]
        C --> E["Occupancy & COPE Agent (LangChain ACORD Audit)"]
        C --> F["News Intelligence Agent (5-Mile Spatial Decay)"]
    end

    subgraph S3["Phase 3: Deterministic Decision Engine (Zero LLM Hallucinations)"]
        D --> G["Confidence-Weighted Aggregator"]
        E --> G
        F --> G
        G --> H{"Hard Veto Triggered?"}
        H -->|Yes: Z_Huber > 3.0 & Internal Fault| I["Floor Hazard Score >= 75.0 (HOLD / DECLINE)"]
        H -->|No| J["Weighted Hazard Score (0 - 100)"]
        I --> K["Actuarial Business Impact Verdict"]
        J --> K
    end

    subgraph S4["Phase 4: AI Executive Synthesis"]
        K --> M["AI Senior Underwriter Synthesis (gemini-3.5-flash-lite)"]
        M --> N["Underwriting Executive Memo\n(Summary, Directive, Conditions)"]
    end

    subgraph S5["Phase 5: Consumption Layer"]
        N --> O["FastAPI Underwriting Microservice (/v1/evaluate)"]
        N --> P["Streamlit Underwriter Cockpit (ui/dashboard.py)"]
    end
```

---

## 📚 Insurance Domain Guide (For Engineers & Data Scientists)

To understand the business reasoning powering this codebase:

* **What does "Bind" mean?**  
  To **bind** insurance coverage means to **legally put the policy into effect**. Prior to binding, quotes are merely estimates; once bound, the insurer is legally liable for property losses even before the formal contract is issued.
* **What is "Auto-Bind" (Straight-Through Processing / STP)?**  
  When an applicant presents an exemplary low-risk profile (Score $< 36.0$, fully compliant sprinklers, stable telemetry, no safety violations), the platform authorizes immediate binding in milliseconds without requiring manual human review.
* **What is a "Hard Veto"?**  
  A non-negotiable safety guardrail. Regardless of how favorable other indicators are, if a catastrophic red-line hazard is detected (e.g. thermal runaway with failing sprinkler pressure, or undeclared lithium-ion assembly), the system overrides the weighted average, floors the score at $\ge 75.0$, and issues an immediate **Decline / Hold**.
* **What is "COPE"?**  
  The four underwriting pillars: **C**onstruction, **O**ccupancy, **P**rotection, and **E**xposure. Handled by `occupancy_risk_agent.py`.
* **What is "IBNR Reserving"?**  
  "Incurred But Not Reported" loss reserves. Actuarial funds set aside to pay anticipated claims. Favorable policies reduce reserves ($0.85\times$ base factor); mid-term hazard surges step up reserves ($1.5\times$ to $2.0\times$).

---

## 📁 Project Directory Structure

```text
fire-risk-ai/
├── README.md                           # Master project guide & documentation
├── architecture_final.md               # End-to-end technical architecture specification
├── implementation_plan.md              # Stage-by-stage implementation milestones
├── context.md                          # Active checkpoints & progress tracker
├── requirements.txt                    # Python dependencies
├── .gitignore                          # Excludes .venv, .env, and large raw datasets
│
├── config/
│   ├── settings.yaml                   # Model weights, thresholds, and actuarial constants
│   └── loader.py                       # Configuration loader
│
├── schemas/
│   └── contracts.py                    # Inter-agent Pydantic contracts & UnderwritingExecutiveMemo
│
├── agents/
│   ├── poc_fire_risk_detector.py       # Scikit-learn HuberRegressor baseline anomaly engine
│   ├── iot_sensor_agent.py             # 5-stage sensor pipeline (Huber, IsoForest, XGBoost)
│   ├── occupancy_risk_agent.py         # COPE scoring & deceptive operation detection
│   └── news_intel_agent.py             # 5-mile radius spatial/temporal news filter
│
├── decision_layer/
│   ├── verdict_calculator.py           # Deterministic confidence-weighted score calculator
│   └── business_impact_mapper.py       # Underwriting actions, pricing credits, IBNR triggers
│
├── data_factory/
│   ├── llm_client.py                   # Multi-model LangChain Gemini router with backoff
│   ├── synthetic_occupancy_gen.py      # ACORD 125/140 & 80 + website generator
│   ├── synthetic_news_gen.py           # 5-mile OSHA citation and utility incident generator
│   ├── synthetic_iot_gen.py            # Hybrid parameter framing + NumPy/SciPy telemetry
│   ├── scenario_builder.py             # Bundler for the 4 Canonical Archetypes
│   ├── micro_benchmark_loader.py       # EN54 cable overload & BME688 plume loader
│   ├── noaa_ingestor.py                # ASOS weather & RAWS fuel moisture parser
│   └── generated_samples/              # Serialized sample JSONs and telemetry CSVs
│
├── models/                             # Pre-trained baseline ML model artifacts
│   ├── sensor_classifier_xgb.json      # XGBoost multi-class classifier
│   ├── sensor_classifier_rf.joblib     # Random Forest champion (for SHAP TreeExplainer)
│   └── iso_forest.joblib               # 5D Isolation Forest anomaly detector
│
├── orchestrator/
│   ├── graph.py                        # LangGraph StateGraph workflow & AI synthesis node
│   └── submission_api.py               # FastAPI microservice endpoints
│
├── ui/
│   └── dashboard.py                    # Underwriter-centric Streamlit cockpit (3 views)
│
├── notebooks/
│   └── 01_train_sensor_classifier.ipynb # Interactive supervised ML training notebook
│
├── scripts/
│   ├── train_baseline_models.py        # Headless model training script
│   ├── test_stage4_langgraph.py        # LangGraph workflow test script
│   └── test_stage5_services.py         # FastAPI & Streamlit services verification
│
└── tests/
    └── test_poc_archetypes.py          # Automated Pytest suite (6/6 tests passing)
```

---

## ⚡ Prerequisites & Setup

### 1. System Requirements
- **macOS** (Apple Silicon supported) or **Linux**
- **Python 3.10** (Recommended: Python 3.10.22)
- **Homebrew OpenMP** (Required for XGBoost / LightGBM on Apple Silicon):
  ```bash
  brew install libomp
  ```

### 2. Virtual Environment Setup
```bash
# Create and activate virtual environment
python3.10 -m venv .venv
source .venv/bin/activate

# Install dependencies
pip install --upgrade pip
pip install -r requirements.txt
```

### 3. API Key Configuration
Create a `.env` file in the root directory:
```bash
GEMINI_API_KEY="your-gemini-api-key-here"
```

---

## 🤖 Gemini Multi-Model Routing & Rate Limits

The platform manages three Gemini models through `GeminiModelRouter` in `data_factory/llm_client.py`:

| Role | Model | RPM | TPM | RPD |
| :--- | :--- | :--- | :--- | :--- |
| **Primary Complex** | `gemini-3.8-flash` | 5 | 250k | 20 |
| **Secondary Complex** | `gemini-3.6-flash` | 5 | 250k | 20 |
| **Simple / Testing / Synthesis** | `gemini-3.5-flash-lite` | 15 | 250k | 500 |

- **40 RPD Complex Budget**: Automatically switches from `gemini-3.8-flash` to `gemini-3.6-flash` on rate limit exhaustion.
- **500 RPD Synthesis Pool**: `gemini-3.5-flash-lite` powers the fast AI Executive Memo generation without eating into the complex reasoning quota.
- **Realism Guardrail**: System prompt strictly mandates: *never use the word "synthetic", "mock", "placeholder", or automated denial codes in generated documents*.

---

## 🚀 How to Run & Verify

### 1. Run the Full Automated Pytest Verification Suite (Stage 7)
```bash
./.venv/bin/pytest tests/test_poc_archetypes.py -v
```
*Result: 6 passed in ~1.30s.*

### 2. Launch the Interactive Streamlit Underwriter Cockpit (Stage 5)
```bash
./.venv/bin/streamlit run ui/dashboard.py
```
*Open http://localhost:8501 in your browser.*
- **View 1:** Underwriting Submission Review (Executive Memo, 3 plain-English cards, Hard Veto override toggle).
- **View 2:** Risk Engineering & Sensor Diagnostics (Panel vs. ambient drift, sprinkler hydraulic pressure gauge, aerosol filter).
- **View 3:** Active Portfolio Risk Monitor (In-force portfolio watchlist, $\Delta S \ge +15.0$ surge alerts, Valley Oak Roasters case study).

### 3. Launch the FastAPI Microservice Live
```bash
./.venv/bin/uvicorn orchestrator.submission_api:app --reload --port 8000
```
*Open http://127.0.0.1:8000/docs for the interactive Swagger API documentation.*

### 4. Run the LangGraph Workflow Evaluation Directly (Stage 4)
```bash
./.venv/bin/python scripts/test_stage4_langgraph.py
```

### 5. Inspect or Retrain ML Models (Stage 6)
```bash
# Launch interactive Jupyter notebook:
./.venv/bin/jupyter lab notebooks/01_train_sensor_classifier.ipynb

# Or train headlessly:
./.venv/bin/python scripts/train_baseline_models.py
```

---

## 📊 The 4 Canonical Underwriting Archetypes

1. **Archetype 1 — Benign Logistics Baseline (Low Risk)**:
   - Modern Class 4 Masonry, 100% NFPA 13 sprinkler, dry goods storage.
   - Real EN54 deodorant aerosol nuisance run injected and filtered.
   - Outcome: **Hazard Score 11.4 / 100 — Auto-Bind Approved with -10.0% rate credit**.

2. **Archetype 2 — WUI Residential Home (External Macro Surge)**:
   - 1988 Frame home, untreated Wood Shake roof, 15 ft brush clearance.
   - RAWS 10-hour dead fuel stick moisture at 4.8% (<6% extreme red flag) + transformer blowout spark.
   - Outcome: **Hazard Score 81.6 / 100 — Non-Bind / Hold**.

3. **Archetype 3 — Commercial Undeclared Battery Assembly (Internal Fault / Hard Veto)**:
   - ACORD application deceptively declares dry goods retail storage with obsolete Federal Pacific Stab-Lok panels.
   - Company website advertises undisclosed lithium-ion battery assembly & laser welding.
   - Telemetry shows thermal runaway divergence ($Z_{\text{Huber}} = 17.57 \gg 3.0$), 285 arc faults, and sprinkler pressure collapse.
   - Outcome: **Hazard Score 95.5 / 100 — Deterministic Hard Veto Triggered, Immediate Decline / Hold**.

4. **Archetype 4 — Active Monitoring Operational Degradation**:
   - Clean initial baseline ($S = 22.0$) degrading midterm due to 16-inch municipal water main rupture and PG&E grid power surges.
   - Outcome: **Hazard Score 75.0 / 100 — $\Delta S = +53.0 \ge +15.0$ Active Monitoring Alert, Loss Control Dispatch, IBNR Reserving step-up ($2.0\times$)**.
