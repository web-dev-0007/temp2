from typing import Dict, Any, List, Optional
from schemas.contracts import BusinessImpactVerdict, RiskTier, LOBType, ExecutionMode


class BusinessImpactMapper:
    """
    Translates deterministic mathematical scores and risk tiers into
    actuarial and underwriting actions:
    1. Risk Avoidance Action (Auto-Bind / Conditional / Decline / Emergency Dispatch)
    2. Risk Pricing Signal (Preferred Credit / Technical Debit / Distressed Surcharge)
    3. Reserving Trigger (IBNR Multipliers 0.85x to 2.0x)
    """

    @staticmethod
    def map_to_business_verdict(
        property_id: str,
        lob: LOBType,
        execution_mode: ExecutionMode,
        calc_result: Dict[str, Any]
    ) -> BusinessImpactVerdict:
        lob_obj = lob if isinstance(lob, LOBType) else LOBType(str(lob))
        final_score = calc_result["final_hazard_score"]
        final_tier: RiskTier = calc_result["final_risk_tier"]
        agg_conf = calc_result["aggregate_confidence"]
        veto_triggered = calc_result["veto_triggered"]
        score_delta = calc_result.get("score_delta_from_baseline")
        is_active_spike = calc_result.get("is_active_spike", False)
        audit_trail: List[str] = list(calc_result.get("audit_trail", []))

        # ---------------------------------------------------------
        # 1. Risk Avoidance Action
        # ---------------------------------------------------------
        if is_active_spike:
            avoidance = "EMERGENCY_LOSS_CONTROL_DISPATCH: Mid-term score surge (ΔS >= +15.0). Issue immediate policyholder mitigation notice and dispatch loss-control engineering."
        elif final_tier == RiskTier.LOW:
            if agg_conf >= 0.70:
                avoidance = "AUTO_BIND_ELIGIBLE: Approved for straight-through binding. Favorable COPE profile and nominal telemetry verified."
            else:
                avoidance = "INFORMATION_HOLD: Insufficient telemetry completeness (<70%). Require supplemental ACORD disclosures prior to binding."
        elif final_tier == RiskTier.MEDIUM:
            avoidance = "CONDITIONAL_BIND_HOLD: Subject to 30-day warranty endorsement. Policyholder must remediate identified maintenance/clearance drivers."
        else:  # HIGH
            avoidance = "PRE_BIND_DECLINE_HOLD: Critical fire peril or hard veto triggered. Exceeds carrier risk appetite. Immediate decline or senior committee review."

        # ---------------------------------------------------------
        # 2. Risk Pricing Signal
        # ---------------------------------------------------------
        if final_tier == RiskTier.LOW:
            pricing = "PREFERRED_TIER_CREDIT: Apply -10.0% smart-sensor & loss-control rate credit; standard deductible."
        elif final_tier == RiskTier.MEDIUM:
            pricing = "TECHNICAL_PERIL_DEBIT: Apply +25.0% fire peril load; increase all-peril deductible by $2,500."
        else:  # HIGH
            pricing = "DISTRESSED_SURCHARGE: Apply +100.0% distressed risk load; mandatory $10,000 fire deductible and Protective Safeguard Clause."

        # ---------------------------------------------------------
        # 3. Reserving Trigger (Actuarial IBNR Multipliers)
        # ---------------------------------------------------------
        if is_active_spike or final_tier == RiskTier.HIGH:
            reserving = "ACUTE_STEP_UP: Set IBNR fire reserve to 2.0x base factor. Allocate immediate catastrophe/attritional reserve buffer."
        elif agg_conf < 0.60:
            reserving = "UNCERTAINTY_BUFFER: Set IBNR fire reserve to 1.35x base factor pending telemetry verification."
        elif final_tier == RiskTier.MEDIUM:
            reserving = "WATCHLIST_BUFFER: Set IBNR fire reserve to 1.25x base factor until 30-day remediation verified."
        else:
            reserving = "FAVORABLE_RESERVE: Set IBNR fire reserve to 0.85x standard base factor (preferred risk release)."

        audit_trail.append(f"Business Impact Verdict: Tier={final_tier.value}, Avoidance='{avoidance[:40]}...', Reserve='{reserving[:30]}...'")

        return BusinessImpactVerdict(
            property_id=property_id,
            lob=lob_obj,
            execution_mode=execution_mode,
            final_hazard_score=final_score,
            final_risk_tier=final_tier,
            aggregate_confidence=agg_conf,
            veto_triggered=veto_triggered,
            score_delta_from_baseline=score_delta,
            risk_avoidance_action=avoidance,
            risk_pricing_signal=pricing,
            reserving_trigger=reserving,
            audit_trail=audit_trail
        )
