from typing import Dict, Any, List, Optional
from schemas.contracts import AgentVerdict, RiskTier, LOBType, ExecutionMode
from config.loader import load_settings


class VerdictCalculator:
    """
    100% Deterministic Mathematical Verdict Engine (Zero LLM calls).
    Computes confidence-weighted scores, configurable hard veto overrides,
    and active monitoring delta calculations.
    """

    def __init__(self, settings: Optional[Dict[str, Any]] = None):
        self.settings = settings or load_settings().get("decision_engine_config", {})
        self.enable_hard_veto = self.settings.get("enable_hard_veto", True)
        self.hard_veto_conf_threshold = self.settings.get("hard_veto_confidence_threshold", 0.80)
        self.hard_veto_floor = self.settings.get("hard_veto_floor_score", 75.0)
        self.delta_alert_threshold = self.settings.get("monitoring_delta_alert_threshold", 15.0)
        self.lob_weights = self.settings.get("lob_weights", {
            "COMMERCIAL": {"iot_sensor_agent": 0.40, "occupancy_risk_agent": 0.45, "news_intel_agent": 0.15},
            "RESIDENTIAL": {"iot_sensor_agent": 0.45, "occupancy_risk_agent": 0.40, "news_intel_agent": 0.15}
        })

    def calculate_verdict(
        self,
        verdicts: List[AgentVerdict],
        lob: LOBType,
        execution_mode: ExecutionMode = ExecutionMode.SUBMISSION_RENEWAL,
        baseline_score: Optional[float] = None
    ) -> Dict[str, Any]:
        lob_key = lob.value if hasattr(lob, "value") else str(lob)
        weights_map = self.lob_weights.get(lob_key, self.lob_weights["COMMERCIAL"])
        
        sum_weighted_confidence = 0.0
        sum_weighted_score = 0.0
        audit_trail: List[str] = []

        veto_triggered = False
        veto_reasons: List[str] = []

        for v in verdicts:
            w = weights_map.get(v.agent_id, 0.333)
            sum_weighted_confidence += w * v.confidence
            sum_weighted_score += w * v.confidence * v.hazard_score
            audit_trail.append(
                f"Agent '{v.agent_id}': score={v.hazard_score:.1f}, conf={v.confidence:.2f}, weight={w:.2f}, tier={v.risk_tier.value}"
            )

            # Check Hard Veto Criteria
            if self.enable_hard_veto and v.risk_tier == RiskTier.HIGH and v.confidence >= self.hard_veto_conf_threshold:
                critical_drivers = [d for d in v.risk_drivers if d.is_critical_veto_candidate]
                if critical_drivers:
                    veto_triggered = True
                    for cd in critical_drivers:
                        veto_reasons.append(f"[{v.agent_id}] {cd.driver_code}: {cd.description}")

        # Confidence-weighted base score
        if sum_weighted_confidence > 0:
            s_weighted = sum_weighted_score / sum_weighted_confidence
        else:
            s_weighted = 50.0  # safe neutral fallback

        audit_trail.append(f"Confidence-Weighted Base Score: S_weighted = {s_weighted:.2f} (Aggregate Confidence = {sum_weighted_confidence:.2f})")

        # Apply Hard Veto Floor if triggered
        if veto_triggered:
            s_final = max(s_weighted, self.hard_veto_floor)
            audit_trail.append(
                f"HARD VETO TRIGGERED: Overriding base score {s_weighted:.1f} with regulatory floor {self.hard_veto_floor:.1f}. "
                f"Reasons: {'; '.join(veto_reasons)}"
            )
        else:
            s_final = s_weighted

        # Deterministic Tier Assignment
        if s_final < 36.0:
            final_tier = RiskTier.LOW
        elif s_final < 70.0:
            final_tier = RiskTier.MEDIUM
        else:
            final_tier = RiskTier.HIGH

        # Active Monitoring Delta Check
        score_delta = None
        is_active_spike = False
        if execution_mode == ExecutionMode.ACTIVE_MONITORING and baseline_score is not None:
            score_delta = round(s_final - baseline_score, 1)
            audit_trail.append(f"Active Monitoring Scan: Delta ΔS = {score_delta:+.1f} points (Current {s_final:.1f} vs Baseline {baseline_score:.1f})")
            if score_delta >= self.delta_alert_threshold:
                is_active_spike = True
                audit_trail.append(f"ACTIVE MONITORING ALERT: Delta ΔS = +{score_delta:.1f} exceeds threshold ({self.delta_alert_threshold:.1f}). Acute mid-term degradation!")

        return {
            "final_hazard_score": round(s_final, 1),
            "final_risk_tier": final_tier,
            "aggregate_confidence": round(sum_weighted_confidence, 2),
            "veto_triggered": veto_triggered,
            "score_delta_from_baseline": score_delta,
            "is_active_spike": is_active_spike,
            "audit_trail": audit_trail
        }
