from typing import Dict, Any, List, Optional
import pandas as pd
import numpy as np
from sklearn.linear_model import HuberRegressor
from sklearn.metrics import r2_score


def rank_fire_prone_areas(df_snapshot: pd.DataFrame) -> pd.DataFrame:
    """
    Ranks California weather stations based on empirical fire weather severity:
    - High air temperature (temp_c)
    - Low relative humidity (rel_humidity_pct)
    - High wind speed and gusts (wind_gust_mph)
    - Fosberg Fire Weather Index (fosberg_fwi) & Vapor Pressure Deficit (vpd_kpa)
    """
    df = df_snapshot.copy()
    
    # Standardize normalization for ranking
    temp_score = (df["temp_c"] - 15.0).clip(lower=0.0) / 25.0  # 15C to 40C
    rh_score = (100.0 - df["rel_humidity_pct"]).clip(lower=0.0) / 90.0  # 10% to 100%
    wind_score = df["wind_gust_mph"].clip(lower=0.0) / 45.0  # 0 to 45 mph
    fwi_score = df["fosberg_fwi"].clip(lower=0.0) / 60.0
    
    # Composite statewide fire danger score (0 - 100)
    composite = (
        0.30 * temp_score +
        0.30 * rh_score +
        0.20 * wind_score +
        0.20 * fwi_score
    ) * 100.0

    df["fire_hazard_index"] = np.round(np.clip(composite, 0.0, 100.0), 1)
    df["rank"] = df["fire_hazard_index"].rank(ascending=False, method="min").astype(int)
    
    return df.sort_values("rank").reset_index(drop=True)


def detect_temporal_anomalies(
    series: pd.Series,
    window_steps: int = 24,
    epsilon: float = 1.35,
    alpha: float = 0.0001
) -> Dict[str, Any]:
    """
    Computes linear slope (beta) via Scikit-Learn's HuberRegressor (M-estimator).
    Outlier-resistant to transient sensor glitches, dropouts, or isolated spikes.
    Returns:
    - slope_per_day: daily slope (scaled from hourly step)
    - r_squared: robust coefficient of determination
    - is_statistically_significant: R2 > 0.40 and slope magnitude > 0.1
    """
    clean = series.dropna()
    if len(clean) < 4:
        return {
            "slope_per_day": 0.0,
            "r_squared": 0.0,
            "is_statistically_significant": False,
            "method": "huber_regressor"
        }

    y = clean.tail(window_steps).values
    x = np.arange(len(y)).reshape(-1, 1)  # hourly steps

    try:
        huber = HuberRegressor(epsilon=epsilon, alpha=alpha, max_iter=300)
        huber.fit(x, y)
        y_pred = huber.predict(x)

        slope_hourly = float(huber.coef_[0])
        slope_per_day = slope_hourly * 24.0
        r2 = float(max(0.0, r2_score(y, y_pred)))

        is_significant = bool(r2 >= 0.35 and abs(slope_per_day) >= 0.25)

        return {
            "slope_per_day": round(slope_per_day, 3),
            "r_squared": round(r2, 3),
            "is_statistically_significant": is_significant,
            "intercept": round(float(huber.intercept_), 3),
            "method": "huber_regressor"
        }
    except Exception:
        # Fallback to simple difference if optimization fails
        diff = float(y[-1] - y[0])
        return {
            "slope_per_day": round(diff * (24.0 / len(y)), 3),
            "r_squared": 0.0,
            "is_statistically_significant": False,
            "method": "fallback_difference"
        }


def fit_and_detect_residual_anomalies(
    noaa_temp: pd.Series,
    panel_temp: pd.Series,
    baseline_window_steps: int = 36,
    z_threshold: float = 3.0,
    epsilon: float = 1.35,
    alpha: float = 0.0001
) -> Dict[str, Any]:
    """
    Distinguishes external ambient heatwaves from internal divergent electrical faults
    using a robust Scikit-Learn HuberRegressor baseline:
      Panel_Temp = alpha + beta * NOAA_Temp
    
    Residuals are scaled using Median Absolute Deviation (MAD) for robust outlier detection:
      sigma_robust = MAD * 1.4826
      Z_anomaly = (e_t - median(e)) / sigma_robust

    Flags Z_anomaly > z_threshold (default 3.0) as critical internal divergent anomaly.
    """
    n = min(len(noaa_temp), len(panel_temp))
    if n < baseline_window_steps:
        baseline_window_steps = max(10, int(n * 0.5))

    x_base = noaa_temp.iloc[:baseline_window_steps].values.reshape(-1, 1)
    y_base = panel_temp.iloc[:baseline_window_steps].values

    # Fit robust Huber Regressor on healthy baseline window
    huber = HuberRegressor(epsilon=epsilon, alpha=alpha, max_iter=300)
    huber.fit(x_base, y_base)

    alpha_hat = float(huber.intercept_)
    beta_hat = float(huber.coef_[0])

    # Predict across entire evaluation series
    x_all = noaa_temp.iloc[:n].values.reshape(-1, 1)
    y_all = panel_temp.iloc[:n].values
    y_pred = huber.predict(x_all)

    # Calculate baseline residuals & Median Absolute Deviation (MAD)
    y_base_pred = huber.predict(x_base)
    residuals_base = y_base - y_base_pred
    median_res = float(np.median(residuals_base))
    mad = float(np.median(np.abs(residuals_base - median_res)))

    # Consistent estimator of standard deviation for normal distribution: MAD * 1.4826
    sigma_robust = max(mad * 1.4826, 0.40)  # noise floor floor at 0.4 C

    # Robust standardized residuals across the full series
    residuals_all = y_all - y_pred
    z_scores = (residuals_all - median_res) / sigma_robust

    max_z = float(np.max(z_scores))
    latest_z = float(z_scores[-1])
    is_divergent = bool(max_z >= z_threshold or latest_z >= z_threshold)

    r2_base = max(0.0, r2_score(y_base, y_base_pred))

    return {
        "alpha": round(alpha_hat, 3),
        "beta": round(beta_hat, 3),
        "r_squared_baseline": round(float(r2_base), 3),
        "residual_std": round(sigma_robust, 3),
        "max_z_score": round(max_z, 2),
        "latest_z_score": round(latest_z, 2),
        "is_divergent_fault": is_divergent,
        "predicted_panel_temp": np.round(y_pred, 2).tolist(),
        "z_score_series": np.round(z_scores, 2).tolist(),
        "method": "huber_robust_m_estimator"
    }
