from typing import Dict, Any, List, Optional
import math
import numpy as np
from schemas.contracts import AgentVerdict, RiskDriver, RiskTier, LOBType
from config.loader import load_settings


class NewsIntelAgent:
    """
    News & External Intelligence Agent:
    Performs 5-mile radial spatial filtering, peril taxonomy classification,
    and exponential temporal decay weighting on local adverse news and citations.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        cfg = config or load_settings().get("news_engine_config", {})
        self.half_life_days = cfg.get("half_life_days", 14.0)
        self.max_radial_miles = cfg.get("radial_distance_miles", 5.0)
        self.decay_lambda = math.log(2.0) / self.half_life_days

    def evaluate(
        self,
        property_id: str,
        lob: LOBType,
        news_articles: List[Dict[str, Any]]
    ) -> AgentVerdict:
        risk_drivers: List[RiskDriver] = []
        is_veto = False
        hazard_points = 15.0  # nominal base

        # Category severity multipliers
        category_weights = {
            "OSHA_ELECTRICAL_VIOLATION": 45.0,
            "SUPPRESSION_IMPAIRMENT": 40.0,
            "INFRASTRUCTURE_WATER_FAILURE": 35.0,
            "INFRASTRUCTURE_PERIL": 30.0,
            "WILDFIRE_WEATHER_ALERT": 25.0,
            "GRID_INSTABILITY": 25.0,
            "BUSINESS_COMMENDATION": -10.0,
            "INFRASTRUCTURE_ROUTINE": -5.0
        }

        for article in news_articles:
            dist = float(article.get("distance_miles", 0.0))
            if dist > self.max_radial_miles:
                continue  # outside 5-mile buffer

            days_ago = float(article.get("days_ago", 0.0))
            # Exponential decay weight: w(t) = exp(-lambda * dt)
            time_weight = math.exp(-self.decay_lambda * max(0.0, days_ago))
            
            # Spatial distance weighting: closer carries more weight
            spatial_weight = 1.0 if article.get("is_entity_match", False) else max(0.4, 1.0 - (dist / self.max_radial_miles) * 0.6)

            category = article.get("category", "GENERAL")
            base_impact = category_weights.get(category, 10.0)
            net_impact = base_impact * time_weight * spatial_weight
            hazard_points += net_impact

            # Check if this article warrants a RiskDriver
            if net_impact >= 15.0 or category in ["OSHA_ELECTRICAL_VIOLATION", "INFRASTRUCTURE_WATER_FAILURE"]:
                sev = RiskTier.HIGH if net_impact >= 25.0 else RiskTier.MEDIUM
                is_veto_candidate = (category == "OSHA_ELECTRICAL_VIOLATION" and article.get("is_entity_match", False))
                if is_veto_candidate:
                    is_veto = True

                risk_drivers.append(RiskDriver(
                    driver_code=f"NEWS_{category}",
                    severity=sev,
                    is_critical_veto_candidate=is_veto_candidate,
                    description=(
                        f"[{article.get('source', 'Media')}] {article.get('headline')}. "
                        f"Category: {category}, published {days_ago:.0f}d ago ({dist:.1f} mi). Impact score: +{net_impact:.1f}."
                    )
                ))

        final_score = float(np.clip(hazard_points, 5.0, 95.0))
        if is_veto:
            final_score = max(final_score, 75.0)

        if final_score < 36.0:
            tier = RiskTier.LOW
        elif final_score < 70.0:
            tier = RiskTier.MEDIUM
        else:
            tier = RiskTier.HIGH

        if not risk_drivers:
            risk_drivers.append(RiskDriver(
                driver_code="NEWS_CLEAN_RADIAL",
                severity=RiskTier.LOW,
                is_critical_veto_candidate=False,
                description="Zero adverse fire, regulatory, or infrastructure events detected within a 5-mile radius."
            ))

        return AgentVerdict(
            agent_id="news_intel_agent",
            property_id=property_id,
            lob=lob,
            risk_tier=tier,
            hazard_score=round(final_score, 1),
            confidence=0.88,
            risk_drivers=risk_drivers
        )

