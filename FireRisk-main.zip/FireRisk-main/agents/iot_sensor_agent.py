import os
import sys
import logging
from pathlib import Path
from typing import Dict, Any, List, Optional
import pandas as pd
import numpy as np

# Ensure project root in sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from schemas.contracts import AgentVerdict, RiskDriver, RiskTier, LOBType
from agents.poc_fire_risk_detector import detect_temporal_anomalies, fit_and_detect_residual_anomalies
from config.loader import load_settings

logger = logging.getLogger("IoTSensorAgent")


class IoTSensorAgent:
    """
    IoT & Environmental Sensor Agent:
    Fuses macro weather (NOAA ASOS, RAWS fuel moisture) with micro building telemetry
    (sprinkler PSI, electrical panel temperature, arc faults, load kW) and sensor benchmarks
    (EN54 cable overload vs aerosol nuisance, BME688 perimeter smoke plumes).

    Features a multi-layer ML architecture:
    - Scikit-learn HuberRegressor for robust thermal divergence
    - Scikit-learn IsolationForest for multivariate anomaly detection
    - XGBoost / LightGBM for EN54 / BME688 sensor classification
    - SHAP TreeExplainer for feature attribution
    - Graceful fallback to calibrated heuristic rules when serialized model artifacts are absent.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        settings = load_settings()
        self.config = config or settings.get("iot_engine_config", {})
        self.ml_config = settings.get("ml_models_config", {})

        # Critical physical thresholds
        self.sprinkler_critical_psi = self.config.get("sprinkler_critical_psi", 40.0)
        self.arc_fault_critical = self.config.get("arc_fault_24h_critical", 5)
        self.panel_slope_critical = self.config.get("panel_temp_slope_critical_c_per_day", 0.5)
        self.sprinkler_slope_critical = self.config.get("sprinkler_slope_critical_psi_per_day", -0.3)
        self.z_score_critical = self.config.get("z_score_anomaly_critical", 3.0)
        self.raws_fuel_critical = self.config.get("raws_fuel_moisture_critical_pct", 6.0)
        self.bme_smoke_critical = self.config.get("bme_smoke_index_critical", 0.70)

        # ML artifact paths
        self.xgb_path = ROOT_DIR / self.ml_config.get("sensor_classifier_xgb_path", "models/sensor_classifier_xgb.json")
        self.iso_path = ROOT_DIR / self.ml_config.get("isolation_forest_path", "models/iso_forest.joblib")

        self.xgb_model = None
        self.iso_forest = None
        self.shap_explainer = None
        self._load_ml_artifacts()

    def _load_ml_artifacts(self):
        """
        Loads serialized ML models if available on disk.
        Gracefully falls back to heuristic rules if models have not yet been trained in Stage 6.
        """
        # 1. Load Isolation Forest
        if self.iso_path.exists():
            try:
                import joblib
                self.iso_forest = joblib.load(str(self.iso_path))
                logger.info(f"Loaded Isolation Forest model from {self.iso_path}")
            except Exception as e:
                logger.warning(f"Could not load Isolation Forest from {self.iso_path}: {e}")
                self.iso_forest = None
        else:
            logger.info("Isolation Forest artifact not found on disk. Operating in Huber/heuristic fallback mode.")

        # 2. Load XGBoost Classifier & SHAP Explainer
        rf_path = ROOT_DIR / "models/sensor_classifier_rf.joblib"
        if rf_path.exists():
            try:
                import joblib
                import shap
                self.rf_model = joblib.load(str(rf_path))
                self.shap_explainer = shap.TreeExplainer(self.rf_model)
                logger.info(f"Loaded Random Forest model from {rf_path} with SHAP TreeExplainer")
            except Exception as e:
                logger.warning(f"SHAP TreeExplainer initialization skipped: {e}")

        if self.xgb_path.exists():
            try:
                import xgboost as xgb
                self.xgb_model = xgb.XGBClassifier()
                self.xgb_model.load_model(str(self.xgb_path))
                logger.info(f"Loaded XGBoost sensor classifier from {self.xgb_path}")
            except Exception as e:
                logger.warning(f"Could not load XGBoost model from {self.xgb_path}: {e}")
                self.xgb_model = None
        else:
            logger.info("XGBoost sensor classifier artifact not found on disk. Operating in heuristic fallback mode.")

    def _apply_sensor_heuristics(self, en54_h2, en54_co, smoke_ppm, arc_faults, hazard_points, is_veto, risk_drivers):
        has_cable_overload = (en54_h2 >= 0.50 and en54_co >= 0.40)
        if arc_faults >= self.arc_fault_critical or has_cable_overload:
            hazard_points += 45.0
            is_veto = True
            risk_drivers.append(RiskDriver(
                driver_code="ELECTRICAL_PRECURSOR_FAULT",
                severity=RiskTier.HIGH,
                is_critical_veto_candidate=True,
                description=f"Acute electrical ignition precursor: {arc_faults} arc faults/24h with EN54 insulation outgassing signature (H2={en54_h2:.2f} ppm, CO={en54_co:.2f} ppm)."
            ))

        if smoke_ppm > 0.015 and en54_h2 < 0.35 and not has_cable_overload:
            risk_drivers.append(RiskDriver(
                driver_code="EN54_NUISANCE_FILTERED",
                severity=RiskTier.LOW,
                is_critical_veto_candidate=False,
                description=f"Indoor particulate elevation (PM proxy {smoke_ppm:.3f}) verified as BENIGN NUISANCE aerosol (flat H2={en54_h2:.2f} ppm). Suppressing false alert."
            ))
        return hazard_points, is_veto

    def evaluate(
        self,
        property_id: str,
        lob: LOBType,
        noaa_series: pd.DataFrame,
        iot_telemetry: pd.DataFrame,
        raws_10hr_fuel_moisture_pct: float = 12.0
    ) -> AgentVerdict:
        risk_drivers: List[RiskDriver] = []
        is_veto = False
        hazard_points = 15.0  # nominal baseline

        # ---------------------------------------------------------
        # STAGE 1: Hard Thresholds & Multi-Sensor Signatures
        # ---------------------------------------------------------
        latest_iot = iot_telemetry.iloc[-1]
        sprinkler_psi = float(latest_iot.get("sprinkler_psi", 65.0))
        arc_faults = int(latest_iot.get("arc_fault_count", 0))
        en54_h2 = float(latest_iot.get("en54_h2_ppm", 0.0))
        en54_co = float(latest_iot.get("en54_co_ppm", 0.0))
        smoke_ppm = float(latest_iot.get("smoke_ppm", 0.0))
        bme_smoke = float(latest_iot.get("bme_outdoor_smoke_index", 0.0))

        # Check Sprinkler Failure
        if sprinkler_psi < self.sprinkler_critical_psi:
            hazard_points += 50.0
            is_veto = True
            risk_drivers.append(RiskDriver(
                driver_code="SPRINKLER_PRESSURE_COLLAPSE",
                severity=RiskTier.HIGH,
                is_critical_veto_candidate=True,
                description=f"Fire sprinkler main pressure decayed to {sprinkler_psi:.1f} PSI (critical threshold < {self.sprinkler_critical_psi} PSI). Severe suppression deficit."
            ))

        # ---------------------------------------------------------
        # STAGE 2: Sensor Classification (XGBoost ML or Fallback Heuristic)
        # ---------------------------------------------------------
        if self.xgb_model is not None:
            # XGBoost supervised model inference
            try:
                # Features: [en54_h2_ppm, en54_co_ppm, smoke_ppm, bme_outdoor_smoke_index]
                feats = np.array([[en54_h2, en54_co, smoke_ppm, bme_smoke]])
                pred_class = int(self.xgb_model.predict(feats)[0])
                # Class 0: Clean, Class 1: Cable Overload, Class 2: Aerosol Nuisance, Class 3: Outdoor Smoke
                if pred_class == 1:
                    hazard_points += 45.0
                    is_veto = True
                    desc = f"XGBoost Classifier flagged acute CABLE OVERLOAD ignition precursor (H2={en54_h2:.2f} ppm, CO={en54_co:.2f} ppm)."
                    if self.shap_explainer is not None:
                        try:
                            sv = self.shap_explainer.shap_values(feats)
                            if isinstance(sv, list) and len(sv) > 1:
                                val = float(np.ravel(sv[1])[0])
                            else:
                                val = float(np.ravel(sv)[0])
                            desc += f" Top TreeSHAP feature driver: H2_outgassing ({val:.3f})."
                        except Exception:
                            pass
                    risk_drivers.append(RiskDriver(
                        driver_code="ELECTRICAL_PRECURSOR_FAULT",
                        severity=RiskTier.HIGH,
                        is_critical_veto_candidate=True,
                        description=desc
                    ))
                elif pred_class == 2:
                    risk_drivers.append(RiskDriver(
                        driver_code="EN54_NUISANCE_FILTERED",
                        severity=RiskTier.LOW,
                        is_critical_veto_candidate=False,
                        description=f"XGBoost Classifier verified particulate elevation ({smoke_ppm:.3f} ppm) as BENIGN NUISANCE aerosol. False alert suppressed."
                    ))
            except Exception as e:
                logger.warning(f"XGBoost inference error: {e}. Falling back to heuristic.")
                self._apply_sensor_heuristics(en54_h2, en54_co, smoke_ppm, arc_faults, hazard_points, is_veto, risk_drivers)
        else:
            # Calibrated Heuristic Logic
            has_cable_overload = (en54_h2 >= 0.50 and en54_co >= 0.40)
            if arc_faults >= self.arc_fault_critical or has_cable_overload:
                hazard_points += 45.0
                is_veto = True
                risk_drivers.append(RiskDriver(
                    driver_code="ELECTRICAL_PRECURSOR_FAULT",
                    severity=RiskTier.HIGH,
                    is_critical_veto_candidate=True,
                    description=f"Acute electrical ignition precursor: {arc_faults} arc faults/24h with EN54 insulation outgassing signature (H2={en54_h2:.2f} ppm, CO={en54_co:.2f} ppm)."
                ))

            # EN54 Nuisance False-Alarm Filter
            if smoke_ppm > 0.015 and en54_h2 < 0.35 and not has_cable_overload:
                risk_drivers.append(RiskDriver(
                    driver_code="EN54_NUISANCE_FILTERED",
                    severity=RiskTier.LOW,
                    is_critical_veto_candidate=False,
                    description=f"Indoor particulate elevation (PM proxy {smoke_ppm:.3f}) verified as BENIGN NUISANCE aerosol (flat H2={en54_h2:.2f} ppm). Suppressing false alert."
                ))

        # Outdoor Red Flag, Low Fuel Moisture & Perimeter Smoke Plume
        latest_noaa = noaa_series.iloc[-1]
        is_red_flag = bool(latest_noaa.get("red_flag_condition", False))
        wind_gust = float(latest_noaa.get("wind_gust_mph", 0.0))
        max_wind_gust = float(noaa_series["wind_gust_mph"].max()) if "wind_gust_mph" in noaa_series.columns else wind_gust

        is_plume_arrived = (bme_smoke >= self.bme_smoke_critical)
        is_critical_aridity = (raws_10hr_fuel_moisture_pct <= self.raws_fuel_critical) and (wind_gust >= 18.0 or max_wind_gust >= 20.0 or is_red_flag)

        if is_plume_arrived or is_critical_aridity or is_red_flag:
            hazard_points += 60.0
            risk_drivers.append(RiskDriver(
                driver_code="WUI_EXTREME_FIRE_WEATHER",
                severity=RiskTier.HIGH,
                is_critical_veto_candidate=False,
                description=f"Critical WUI brush aridity & perimeter alert: RAWS 10-hour fuel moisture={raws_10hr_fuel_moisture_pct:.1f}% (<{self.raws_fuel_critical}%), BME688 perimeter smoke index={bme_smoke:.2f}, wind gusts={wind_gust:.1f} mph (peak {max_wind_gust:.1f} mph)."
            ))

        # ---------------------------------------------------------
        # STAGE 3: Huber Temporal Trends
        # ---------------------------------------------------------
        panel_slope = detect_temporal_anomalies(iot_telemetry["panel_temp_c"], window_steps=36)
        sprinkler_slope = detect_temporal_anomalies(iot_telemetry["sprinkler_psi"], window_steps=36)

        if panel_slope["slope_per_day"] >= self.panel_slope_critical and panel_slope["is_statistically_significant"]:
            hazard_points += 20.0
            risk_drivers.append(RiskDriver(
                driver_code="PANEL_THERMAL_DRIFT",
                severity=RiskTier.MEDIUM,
                is_critical_veto_candidate=False,
                description=f"Sustained upward sub-panel thermal drift (+{panel_slope['slope_per_day']:.2f}°C/day, R²={panel_slope['r_squared']:.2f})."
            ))

        if sprinkler_slope["slope_per_day"] <= self.sprinkler_slope_critical and sprinkler_slope["is_statistically_significant"]:
            hazard_points += 20.0
            risk_drivers.append(RiskDriver(
                driver_code="SPRINKLER_PRESSURE_DECAY",
                severity=RiskTier.MEDIUM,
                is_critical_veto_candidate=False,
                description=f"Chronic sprinkler main hydraulic decay ({sprinkler_slope['slope_per_day']:.2f} PSI/day, R²={sprinkler_slope['r_squared']:.2f})."
            ))

        # ---------------------------------------------------------
        # STAGE 4: Baseline Regression & NOAA Residual Z-Score (Huber)
        # ---------------------------------------------------------
        anomaly_results = fit_and_detect_residual_anomalies(
            noaa_temp=iot_telemetry["noaa_temp_c"],
            panel_temp=iot_telemetry["panel_temp_c"],
            z_threshold=self.z_score_critical
        )

        if anomaly_results["is_divergent_fault"]:
            hazard_points += 35.0
            is_veto = True
            risk_drivers.append(RiskDriver(
                driver_code="DIVERGENT_INTERNAL_ANOMALY",
                severity=RiskTier.HIGH,
                is_critical_veto_candidate=True,
                description=f"Critical divergent internal thermal anomaly (Z-score = {anomaly_results['max_z_score']:.2f} > {self.z_score_critical}). Internal equipment surging while outdoor ambient temperature is steady."
            ))

        # ---------------------------------------------------------
        # STAGE 5: Multivariate Outlier Detection (Isolation Forest or Fallback)
        # ---------------------------------------------------------
        if self.iso_forest is not None:
            try:
                # 5D feature space: panel_temp_c, sprinkler_psi, arc_fault_count, load_kw, noaa_temp_c
                feat_cols = ["panel_temp_c", "sprinkler_psi", "arc_fault_count", "load_kw", "noaa_temp_c"]
                if all(col in iot_telemetry.columns for col in feat_cols):
                    telemetry_5d = iot_telemetry[feat_cols].values
                    iso_preds = self.iso_forest.predict(telemetry_5d)
                    outlier_count = int(np.sum(iso_preds == -1))
                    if outlier_count > 0:
                        hazard_points += 25.0
                        risk_drivers.append(RiskDriver(
                            driver_code="MULTIVARIATE_ANOMALY_ISOLATION_FOREST",
                            severity=RiskTier.HIGH,
                            is_critical_veto_candidate=True,
                            description=f"Isolation Forest identified {outlier_count} multivariate outlier states across 5D telemetry space."
                        ))
            except Exception as e:
                logger.warning(f"Isolation Forest prediction error: {e}")

        # ---------------------------------------------------------
        # STAGE 6: Final Standardization & Hard Veto Floor
        # ---------------------------------------------------------
        final_score = float(np.clip(hazard_points, 10.0, 98.0))
        if is_veto:
            final_score = max(final_score, 75.0)

        if final_score < 36.0:
            tier = RiskTier.LOW
        elif final_score < 70.0:
            tier = RiskTier.MEDIUM
        else:
            tier = RiskTier.HIGH

        if not risk_drivers:
            risk_drivers.append(RiskDriver(
                driver_code="IOT_NOMINAL",
                severity=RiskTier.LOW,
                is_critical_veto_candidate=False,
                description="All electrical, hydraulic, and environmental sensors operating within nominal safe limits."
            ))

        # High telemetry completeness gives high confidence
        confidence = 0.92 if len(iot_telemetry) >= 48 else 0.75

        return AgentVerdict(
            agent_id="iot_sensor_agent",
            property_id=property_id,
            lob=lob,
            risk_tier=tier,
            hazard_score=round(final_score, 1),
            confidence=confidence,
            risk_drivers=risk_drivers
        )
