from typing import Dict, Any, List, Optional
import re
import numpy as np
from schemas.contracts import AgentVerdict, RiskDriver, RiskTier, LOBType


class OccupancyRiskAgent:
    """
    Occupancy & COPE Risk Agent:
    Evaluates Construction, Occupancy, Protection, and Exposure (COPE)
    and checks for discrepancies between declared ACORD forms and actual web operational footprints.
    """

    def __init__(self):
        # Known high hazard keywords for discrepancy detection
        self.high_hazard_keywords = [
            "battery", "lithium-ion", "welding", "chemical blending",
            "flammable liquid", "solvent", "plasma cutting", "hazardous",
            "refinery", "pyrotechnics", "munitions", "aerosol packaging"
        ]

    def evaluate(
        self,
        property_id: str,
        lob: LOBType,
        acord_payload: Dict[str, Any],
        website_scrape_text: str = ""
    ) -> AgentVerdict:
        risk_drivers: List[RiskDriver] = []
        is_veto = False
        hazard_points = 20.0  # nominal baseline

        # ---------------------------------------------------------
        # 1. COPE - Construction
        # ---------------------------------------------------------
        iso_class = str(acord_payload.get("iso_construction_class", "")).lower()
        roof_type = str(acord_payload.get("roof_type", "")).lower()
        roof_age = int(acord_payload.get("roof_age_years", 0))
        panel_vintage = str(acord_payload.get("electrical_panel_type", "")).lower()

        # Construction combustibility
        if "class 1" in iso_class or "frame" in iso_class:
            hazard_points += 20.0
            risk_drivers.append(RiskDriver(
                driver_code="COPE_FRAME_CONSTRUCTION",
                severity=RiskTier.MEDIUM,
                is_critical_veto_candidate=False,
                description=f"Combustible structural frame ({acord_payload.get('iso_construction_class')}). Elevated flame spread rate."
            ))
        elif "class 2" in iso_class or "joisted masonry" in iso_class:
            hazard_points += 10.0

        # Roof combustibility
        if "wood shake" in roof_type:
            hazard_points += 25.0
            risk_drivers.append(RiskDriver(
                driver_code="COPE_COMBUSTIBLE_ROOF",
                severity=RiskTier.HIGH,
                is_critical_veto_candidate=False,
                description=f"Highly combustible roof covering ({acord_payload.get('roof_type')}, age {roof_age}y). Extreme vulnerability to airborne fire embers."
            ))

        # Obsolete / Hazard Electrical Panels
        if "federal pacific" in panel_vintage or "stab-lok" in panel_vintage or "zinsco" in panel_vintage:
            hazard_points += 30.0
            is_veto = True
            risk_drivers.append(RiskDriver(
                driver_code="OBSOLETE_ELECTRICAL_PANEL",
                severity=RiskTier.HIGH,
                is_critical_veto_candidate=True,
                description=f"Notorious fire-hazard electrical panel detected: {acord_payload.get('electrical_panel_type')}. Known failure rate to trip on thermal overcurrent."
            ))

        # ---------------------------------------------------------
        # 2. COPE - Protection
        # ---------------------------------------------------------
        sprinkler = acord_payload.get("sprinkler_system", {})
        sprinkler_installed = sprinkler.get("installed", False)
        sprinkler_status = str(sprinkler.get("annual_cert_status", "")).upper()
        sprinkler_cov = sprinkler.get("coverage_pct", 0)

        fire_alarm = acord_payload.get("fire_alarm", {})
        alarm_installed = fire_alarm.get("installed", False)
        hydrant_dist = acord_payload.get("fire_hydrant_distance_feet")
        if hydrant_dist is None:
            hydrant_dist = 500
        else:
            hydrant_dist = float(hydrant_dist)

        if not sprinkler_installed or sprinkler_cov < 50 or "EXPIRED" in sprinkler_status or "DEFICIENT" in sprinkler_status:
            hazard_points += 25.0
            risk_drivers.append(RiskDriver(
                driver_code="COPE_PROTECTION_DEFICIT",
                severity=RiskTier.HIGH if not sprinkler_installed else RiskTier.MEDIUM,
                is_critical_veto_candidate=False,
                description=f"Sub-standard automatic fire suppression: installed={sprinkler_installed}, coverage={sprinkler_cov}%, cert_status={sprinkler_status}."
            ))
        else:
            hazard_points -= 10.0  # Credit for verified 100% NFPA 13 sprinkler

        if hydrant_dist > 1000:
            hazard_points += 15.0
            risk_drivers.append(RiskDriver(
                driver_code="HYDRANT_DISTANCE_EXCESS",
                severity=RiskTier.MEDIUM,
                is_critical_veto_candidate=False,
                description=f"Municipal fire hydrant distance exceeds standard response limit ({hydrant_dist} ft > 1000 ft)."
            ))

        # ---------------------------------------------------------
        # 3. COPE - Exposure (WUI clearance for residential)
        # ---------------------------------------------------------
        wui_clearance = acord_payload.get("wui_vegetation_clearance_feet")
        if wui_clearance is not None and float(wui_clearance) < 30 and lob == LOBType.RESIDENTIAL:
            hazard_points += 25.0
            risk_drivers.append(RiskDriver(
                driver_code="DEFENSIBLE_SPACE_DEFICIT",
                severity=RiskTier.HIGH,
                is_critical_veto_candidate=False,
                description=f"Defensible brush clearance is only {wui_clearance} ft (NFPA 1144 requires minimum 100 ft buffer)."
            ))

        # ---------------------------------------------------------
        # 4. Declared vs Actual Operational Discrepancy Check
        # ---------------------------------------------------------
        declared_occ = str(acord_payload.get("occupancy_description", "")).lower()
        web_text_lower = website_scrape_text.lower()

        found_undeclared = []
        for kw in self.high_hazard_keywords:
            if kw in web_text_lower and kw not in declared_occ:
                found_undeclared.append(kw)

        if found_undeclared:
            hazard_points += 45.0
            is_veto = True
            risk_drivers.append(RiskDriver(
                driver_code="UNDECLARED_HIGH_HAZARD_OPERATIONS",
                severity=RiskTier.HIGH,
                is_critical_veto_candidate=True,
                description=(
                    f"Operational Misrepresentation Flag: ACORD declares '{acord_payload.get('occupancy_description')}', "
                    f"but verified company website advertises un-underwritten high-hazard operations: {', '.join(found_undeclared).upper()}."
                )
            ))

        # ---------------------------------------------------------
        # 5. Suppression Deficit Matrix
        # ---------------------------------------------------------
        # If high hazards present without functioning 100% sprinkler -> Critical Veto
        if (found_undeclared or "battery" in declared_occ or "welding" in declared_occ) and not (sprinkler_installed and sprinkler_cov >= 90):
            hazard_points += 30.0
            is_veto = True
            risk_drivers.append(RiskDriver(
                driver_code="SUPPRESSION_GAP_HIGH_HAZARD",
                severity=RiskTier.HIGH,
                is_critical_veto_candidate=True,
                description="Severe suppression gap: High-hazard thermal/chemical operations present without full certified automatic fire sprinkler protection."
            ))

        # ---------------------------------------------------------
        # Final Score Standardization
        # ---------------------------------------------------------
        final_score = float(np.clip(hazard_points, 8.0, 99.0))
        if is_veto:
            final_score = max(final_score, 75.0)

        if final_score < 36.0:
            tier = RiskTier.LOW
        elif final_score < 70.0:
            tier = RiskTier.MEDIUM
        else:
            tier = RiskTier.HIGH

        if not risk_drivers:
            risk_drivers.append(RiskDriver(
                driver_code="COPE_PREFERRED",
                severity=RiskTier.LOW,
                is_critical_veto_candidate=False,
                description="Superior COPE profile: Non-combustible structure, verified 100% NFPA 13 sprinklers, and complete operational disclosure."
            ))

        return AgentVerdict(
            agent_id="occupancy_risk_agent",
            property_id=property_id,
            lob=lob,
            risk_tier=tier,
            hazard_score=round(final_score, 1),
            confidence=0.90,
            risk_drivers=risk_drivers
        )
