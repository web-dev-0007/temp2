# Fire Risk AI — Phased Implementation Plan & Execution Milestones

> **Current Status:** **ALL PHASES (1 THROUGH 5 / STAGES 1 THROUGH 7) 100% COMPLETED & VERIFIED.**  
> **Master Architecture:** [architecture_final.md](architecture_final.md)  
> **Progress Tracker & Context:** [context.md](context.md)  
> **Test Suite:** `tests/test_poc_archetypes.py` (6/6 passing in 1.30s)

---

## Executive Summary

This implementation plan translates the **Fire Risk AI** master architecture into an end-to-end Machine Learning and Agentic pipeline. It fuses **four real-world environmental and fire-sensor datasets** (NOAA ASOS, RAWS, EN54, BME688) with **Gemini-driven structured insurance synthetic generators** and **classical ML models** (HuberRegressor, Isolation Forest, XGBoost/LightGBM, and TreeSHAP). Every capability—finding fire-prone areas, detecting temporal equipment anomalies via robust regression, detecting multivariate outliers, filtering false alarms via supervised ML, synthesizing underwriter executive directives, and computing deterministic underwriting & actuarial reserving verdicts—is demonstrable end to end.

---

## 1. Master Dataset Mapping & Verification Matrix

| PoC Capability | Primary Dataset (Real vs. Synthetic) | Verified Source Link | Target Module | Status |
| :--- | :--- | :--- | :--- | :--- |
| **1. Finding Fire-Prone Areas (Statewide Spatial Ranking)** | **Real:** 30-Station California ASOS Snapshots + NIFC WUI & Perimeters | [IEM CA Summer Peak (`2026-08-02`)](https://mesonet.agron.iastate.edu/sites/hist.phtml?station=JAQ&network=CA_ASOS&mode=daily&year=2026&month=8&day=02), [IEM CA Autumn Heatwave (`2026-10-05`)](https://mesonet.agron.iastate.edu/sites/hist.phtml?station=GOO&network=CA_ASOS&mode=daily&year=2026&month=10&day=05), [IEM CA Winter Baseline (`2025-12-17`)](https://mesonet.agron.iastate.edu/sites/hist.phtml?station=BFL&network=CA_ASOS&mode=daily&year=2025&month=12&day=17), [NIFC Open Data](https://data-nifc.opendata.arcgis.com/datasets/nifc::public-view-interagency-remote-automatic-weather-stations-raws/about) | `agents/poc_fire_risk_detector.py` (`rank_fire_prone_areas`) | ✅ **VERIFIED** |
| **2. WUI Canyon Fuel Moisture & Wind Telemetry** | **Real:** Interagency RAWS (10-Hour Fuel Stick Moisture & 20-ft Wind) | [NIFC Interagency RAWS Portal](https://data-nifc.opendata.arcgis.com/datasets/nifc::public-view-interagency-remote-automatic-weather-stations-raws/about), [NWCG Fire Weather Station Standards](https://raws.nifc.gov/sites/default/files/inline-files/NWCG%20Standards%20for%20Fire%20Weather%20Stations_2019_1.pdf), [NIFC PMS 426-3](https://raws.nifc.gov/sites/default/files/inline-files/pms426-3.pdf) | `data_factory/noaa_ingestor.py` & `agents/iot_sensor_agent.py` | ✅ **VERIFIED** |
| **3. Robust Multi-Week Drift & Baseline Regression** | **Real + ML:** 61-Day Ukiah (`KUKI`) & LAX Series + Scikit-Learn `HuberRegressor` | [IEM Ukiah Sep 2026](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&station=UKI&year=2026&month=09), [IEM Ukiah Oct 2026](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&year=2026&month=10&mode=monthly&station=UKI) | `agents/poc_fire_risk_detector.py` (`fit_and_detect_residual_anomalies`) | ✅ **VERIFIED** |
| **4. Supervised Cable Overload vs. Nuisance Classification** | **Real + ML:** 2025 EN54 Dataset (305k rows) + 2026 BME688 (131k rows) trained via `XGBoost`/`LightGBM`/`RandomForest` + `TreeSHAP` | [Mendeley Data `npk2zcm85h/2`](https://data.mendeley.com/datasets/npk2zcm85h/2), [Mendeley Data `48j7mm8k56`](https://data.mendeley.com/datasets/48j7mm8k56) | `notebooks/01_train_sensor_classifier.ipynb` & `agents/iot_sensor_agent.py` | ✅ **VERIFIED** |
| **5. Multivariate Outlier Detection** | **ML:** Scikit-Learn `IsolationForest` across 5 telemetry channels | 5D feature space (`panel_temp_c`, `sprinkler_psi`, `arc_fault_count`, `load_kw`, `noaa_temp_c`) | `agents/iot_sensor_agent.py` | ✅ **VERIFIED** |
| **6. Hybrid Building Telemetry Synthesis** | **Gemini + NumPy/SciPy:** Physics regimes guided by Gemini, synthesized mathematically | Synchronized to [IEM Ukiah Oct 2026 (`KUKI`)](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&year=2026&month=10&mode=monthly&station=UKI) | `data_factory/synthetic_iot_gen.py` | ✅ **VERIFIED** |
| **7. Structured Underwriting & Deceptive Operations** | **Gemini Structured Output:** ACORD 125/140 & 80 JSONs + authentic company website text | Enforces strict guardrail against the word 'synthetic' or raw denial codes | `data_factory/synthetic_occupancy_gen.py` & `agents/occupancy_risk_agent.py` | ✅ **VERIFIED** |
| **8. 5-Mile Radial Adverse Media Intelligence** | **Gemini Generated:** Weather-synced OSHA citations, water main breaks & utility incidents | Synced to [IEM ASOS Heatwave Timelines](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&station=UKI&year=2026&month=09) | `data_factory/synthetic_news_gen.py` & `agents/news_intel_agent.py` | ✅ **VERIFIED** |

---

## 2. Step-by-Step Phased Implementation Roadmap & Verification

### Phase 1: Hybrid Data Layer & Benchmark Normalization ✅ (COMPLETED)
1. **Macro Weather & Fuel Store (`data_factory/noaa_real_world_iot_poc_dataset.csv`):** Verified 291 real records across 30 CA stations.
2. **Micro Benchmark Adapter (`data_factory/micro_benchmark_loader.py`):**
   - Window A (Benign/Nuisance): Real aerosol burst (ethanol, deodorant, hairspray) to test false-alarm rejection.
   - Window B (Electrical Fault): NHXMH electrical cable overload ($H_2$ and $CO$ outgassing + thermal ramp) for early fire precursor detection.
   - BME688 plume arrival windows collapsed into normalized smoke indices.
3. **The 4 Canonical Archetype Bundles (`data_factory/scenario_builder.py`):**
   - Archetype 1 (Benign Logistics), Archetype 2 (WUI Macro Surge), Archetype 3 (Internal Battery Fault), Archetype 4 (Active Monitoring Mid-Term).
   - Serialized in `data_factory/generated_samples/`.

### Phase 2: Core Detection & Specialist Agents ✅ (COMPLETED)
1. **`iot_sensor_agent.py`:**
   - Stage 1: Critical physical thresholds (sprinkler $< 40$ PSI, arcing, fuel moisture $< 6\%$).
   - Stage 2: Scikit-learn `HuberRegressor` for outlier-resistant slope and weather baseline residual $Z$-scores ($Z_{\text{Huber}}$ via MAD).
   - Stage 3: Scikit-learn `IsolationForest` across 5D telemetry space.
   - Stage 4: Supervised multi-class sensor classifier with graceful heuristic fallback.
   - Stage 5: Local TreeSHAP attribution via `shap.TreeExplainer`.
2. **`occupancy_risk_agent.py`:**
   - ACORD 125/140 & ACORD 80 COPE scoring engine.
   - Gemini discrepancy audit detecting deceptive website operations (e.g. undisclosed lithium-ion battery assembly).
3. **`news_intel_agent.py`:**
   - 5-mile Haversine geospatial radius filter.
   - Peril taxonomy classification with exponential temporal decay $w(\Delta t) = e^{-\lambda \Delta t}$.

### Phase 3: Deterministic Decision Engine & LangGraph Orchestration ✅ (COMPLETED)
1. **Actuarial Decision Layer (`decision_layer/`):**
   - Confidence-weighted score aggregation ($S_{\text{weighted}}$).
   - Hard Veto override: when active, floors score at $\ge 75.0$ if internal fault is confirmed ($Z_{\text{Huber}} > 3.0$ + IsoForest).
   - Active monitoring state delta tracker ($\Delta S = S_{\text{final}} - S_{\text{baseline}}$).
   - Deterministic risk avoidance, rate credits/debits, and IBNR reserving triggers ($0.85\times$ to $2.0\times$).
2. **LangGraph StateGraph Workflow (`orchestrator/graph.py`):**
   - `entity_lob_router` $\rightarrow$ Parallel Fan-Out (`iot_sensor_agent`, `occupancy_risk_agent`, `news_intel_agent`) $\rightarrow$ `verdict_engine` $\rightarrow$ `ai_synthesis` $\rightarrow$ `END`.
   - `node_ai_synthesis`: Generates plain-English `UnderwritingExecutiveMemo` using `gemini-3.5-flash-lite` on top of deterministic math.

### Phase 4: Underwriter Cockpit & FastAPI Microservice ✅ (COMPLETED)
1. **FastAPI Microservice (`orchestrator/submission_api.py`):**
   - `GET /v1/health`: Service health and model status.
   - `GET /v1/archetypes`: Lists available archetypes.
   - `GET /v1/hotspots/california`: Returns ranked fire-prone areas across 30 CA ASOS stations.
   - `POST /v1/evaluate`: Evaluates underwriting submissions or active monitoring batches.
2. **Streamlit Underwriter Cockpit (`ui/dashboard.py`):**
   - **View 1 (Submission Review):** Decision banner (Auto-Bind / Decline / Emergency), AI Executive Memo, 3 plain-English cards, and interactive Hard Veto override toggle.
   - **View 2 (Risk Engineering):** Sub-panel vs. ambient temperature drift chart, sprinkler hydraulic gauge, and aerosol false-alarm filter.
   - **View 3 (Active Portfolio Monitor):** In-force portfolio watchlist, $\Delta S \ge +15.0$ surge alert banner, and Valley Oak Roasters case study.

### Phase 5: Supervised ML Notebook & Pytest Verification ✅ (COMPLETED)
1. **Interactive ML Training Notebook (`notebooks/01_train_sensor_classifier.ipynb`):**
   - Stratified 5-Fold Cross Validation comparing XGBoost, LightGBM, and Random Forest on EN54 (305k rows) and BME688 (131k rows).
   - Fits 5D Isolation Forest and plots TreeSHAP local attributions.
   - Serialized baseline models in `models/` (`sensor_classifier_xgb.json`, `sensor_classifier_rf.joblib`, `iso_forest.joblib`).
2. **Automated Pytest Suite (`tests/test_poc_archetypes.py`):**
   - 6 automated test cases covering Archetypes 1 through 4, Hard Veto override logic, and Huber transient glitch resistance.
   - **Result: 6/6 tests passing (100% pass rate in 1.30s).**

---

## 3. What's Done vs. What's Left (Future Scope)

### What Is 100% Done & Ready:
- [x] All 7 implementation stages complete and committed to git repository (`main` branch).
- [x] Pre-trained models serialized and tracked in git.
- [x] Automated test suite verified (6/6 passed).
- [x] Streamlit dashboard tested and verified.
- [x] FastAPI microservice tested and verified.
- [x] Documentation, architecture specifications, and context tracker fully synchronized.

### Optional Future Scope (For Subsequent Sessions / Collaborators):
1. **Push to GitHub Remote:** Run `git push -u origin main` (requires sandbox network access approval).
2. **Interactive Supervised Training Session:** Run `jupyter lab notebooks/01_train_sensor_classifier.ipynb` if the user wishes to inspect or re-train models on new custom datasets.
3. **Live Hardware Telemetry Ingestion:** Connect real-time MQTT / WebSocket streams from building BMS systems (Johnson Controls, Honeywell, Siemens Desigo).
4. **Geographic Expansion:** Extend statewide ingestion to other wildfire-prone regions (e.g. Oregon, Washington, Colorado, Texas).
