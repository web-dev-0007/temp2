# Fire Risk AI — Master Architecture, Dataset Catalog & Phased Implementation Plan

## 1. Master System Context (Agent-Readable Header)

```yaml
system_name: Fire Risk AI
domain: Property & Casualty (P&C) Insurance — Fire Peril Underwriting & Portfolio Monitoring
supported_lobs:
  - COMMERCIAL_PROPERTY (Offices, Warehouses, Manufacturing, Retail, Hospitality)
  - RESIDENTIAL_PROPERTY (Single-Family, Multi-Family, HOA/Condo)
execution_modes:
  - SUBMISSION_RENEWAL: Synchronous evaluation at policy quote/renewal for risk avoidance, binding, and technical pricing.
  - ACTIVE_MONITORING: Scheduled (weekly/monthly) batch re-evaluation on active policies for mid-term loss control and actuarial reserving triggers.
data_strategy:
  macro_anchor_truth:
    - Real NOAA/ASOS Regional Weather & Heatwave Telemetry (IEM ASOS / NOAA GHCNh)
    - Real Interagency RAWS Wildland & 10-Hour Fuel Stick Moisture Telemetry (NIFC / NWCG)
    - Real NIFC Wildfire Perimeters, Burn Scars & WUI Hazard Exposure Layers
  micro_real_benchmarks:
    - 2025 EN54 Indoor Multi-Sensor Fire & Electrical Cable Overload Dataset (Mendeley Data V2)
    - 2026 BME688/BME690 Outdoor Vegetation Smoke Plume Dispersion Dataset (Mendeley Data)
  noaa_synced_synthetic_layers:
    - Gemini-Driven Building Mechanical/Electrical Telemetry: Fault regimes, parameters, and baseline drift specified via Google GenAI structured prompts; physically synthesized with NumPy/SciPy anchored to NOAA/RAWS timelines.
    - Gemini-Driven ACORD 125/140 & ACORD 80 Payloads: Realistic underwriting forms paired with deceptive company website text (strictly guarded against using the word 'synthetic' or raw denial codes).
    - Gemini-Driven Local Intelligence: Realistically generated 5-mile radius OSHA citations, water main breaks, transformer blowouts, and serial arson reports.
decision_philosophy:
  agents:
    iot_sensor_agent: Robust Scikit-learn HuberRegressor for thermal drift and baseline divergence + Scikit-learn Isolation Forest for multivariate anomaly detection + Supervised XGBoost/LightGBM classifier trained on 305k EN54 rows & 131k BME688 rows + TreeSHAP explainability.
    occupancy_risk_agent: Deterministic COPE rule engine paired with LangChain-driven Gemini structured discrepancy auditing.
    news_intel_agent: 5-mile radial spatial filtering, peril taxonomy classification, and exponential temporal decay weighting.
  orchestration_framework: LangGraph parallel fan-out to specialist agents with deterministic fan-in to the decision layer.
  llm_framework: LangChain (`langchain`, `langchain-google-genai`) with Pydantic structured output contracts.
  model_training_approach: Supervised step-by-step interactive Jupyter notebook (`notebooks/01_train_sensor_classifier.ipynb`) executed under user supervision at project completion.
  verdict_layer: 100% deterministic Python math with zero runtime LLM calls; triggers Hard Veto when Huber residual Z_anomaly > 3.0 and Isolation Forest confirm an internal equipment fault.
```

## 2. End-to-End System Architecture

```text
=============================================================================================
              PHASE 0: HYBRID REAL-WORLD + GEMINI STRUCTURED DATA FACTORY
=============================================================================================
 [Macro Real Truth: NOAA ASOS + RAWS + NIFC] ---> (Temp, RH, Wind, KBDI, 10h Fuel Moisture, WUI)
 [Micro Real Truth: 2025 EN54 + 2026 BME688/690] -> (Cable Overload H2/CO/PM, Outdoor Smoke Plume)
                                        |
        +-------------------------------+-------------------------------+
        |                               |                               |
        v                               v                               v
 [Gemini + NumPy IoT Synthesizer] [Gemini Structured Occupancy]  [Gemini Local News Gen]
 - Gemini sets physics params    - Emits ACORD 125/140 & 80      - Realistically generates
   & drift regimes               - Generates deceptive company     OSHA citations, water main
 - NumPy/SciPy generates panel     website text with realism       breaks, transformer sparks
   temp, sprinkler PSI & arcs      guardrail (no 'synthetic' tag)  within 5-mile radius

=============================================================================================
                    PHASE 1: DUAL-MODE ORCHESTRATOR & LOB ROUTER
=============================================================================================
 Trigger A: Underwriting API (Submission / Renewal)  ---+
 Trigger B: Active Monitoring Cron (Weekly / Monthly) --+--> [Entity & LOB Context Router]
                                                             - Geocodes Lat/Lon, FIPS, WUI
                                                             - Checks NIFC Perimeters & RAWS
                                                             - Sets COMMERCIAL vs RESIDENTIAL
                                                             - Loads Prior Baseline (if Active)
                                                                        |
        +-------------------------------+-------------------------------+
        |                               |                               |
        v                               v                               v
=============================================================================================
                 PHASE 2: PARALLEL SPECIALIST AGENTS (CLASSICAL ML + TOOLS)
=============================================================================================
+-------------------------------+ +-------------------------------+ +-----------------------+
|   1. IoT SENSOR AGENT (ML)    | |   2. OCCUPANCY RISK AGENT     | | 3. NEWS INTEL AGENT   |
+-------------------------------+ +-------------------------------+ +-----------------------+
| - Macro: NOAA ASOS + RAWS     | | - ACORD Form Parser           | | - Area News (5mi rad) |
| - Micro: EN54 + BME688 +      | | - Company URL Operations      | | - Business Violations |
|          Synced Panel/PSI     | | - Engine:                     | | - Engine:             |
| - Engine:                     | |   a) COPE Hazard Scoring      | |   a) Entity & Geo Link|
|   a) Huber Robust Regression  | |   b) Ignition vs Fuel Load    | |   b) Peril Relevance  |
|      (Drift Slope & Z-Score)  | |   c) Suppression Gap Check    | |   c) Temporal Decay   |
|   b) Isolation Forest         | |      (Sprinklers / Alarms)    | |      Weighting        |
|      (Multivariate Outliers)  | |   d) Gemini Discrepancy Check | |                       |
|   c) XGBoost / LightGBM       | |                               | |                       |
|      (EN54/BME688 Classifier) | |                               | |                       |
|   d) TreeSHAP Explainability  | |                               | |                       |
+---------------+---------------+ +---------------+---------------+ +-----------+-----------+
                |                                 |                             |
                | Standardized AgentVerdict JSON  |                             |
                +---------------------------------+-----------------------------+
                                                  |
                                                  v
=============================================================================================
                    PHASE 3: DETERMINISTIC FINAL DECISION LAYER (PYTHON)
=============================================================================================
  1. Configurable Aggregation: Confidence-Weighted Score + Optional Hard-Veto Override
  2. State Delta Tracker: Compares Current Verdict vs. Prior Policy Baseline (Active Mode)
  3. Business Impact Mapper:
     - Deterministic Fire Hazard Score (0.0 to 100.0) & Final Tier (LOW / MEDIUM / HIGH)
     - Risk Avoidance Action (Auto-Bind, Conditional Remediation, Pre-Bind Hold, Mid-Term Alert)
     - Risk Pricing Multiplier (Technical Rate Credit/Debit, Deductible Adjustment)
     - Reserving Trigger (Standard IBNR, Watchlist Buffer, Acute Actuarial Step-Up)

=============================================================================================
                 PHASE 4: AI SENIOR UNDERWRITER SYNTHESIS & CONSUMPTION LAYER
=============================================================================================
  1. AI Orchestrator Synthesis Node (`node_ai_synthesis` via `gemini-3.5-flash-lite`):
     - Translates raw fragmented facts (ACORD disclosures, IoT telemetry, OSHA citations,
       Huber Z-scores, TreeSHAP attributions) into an UnderwritingExecutiveMemo:
       * Executive Summary (Auto-bind approved vs decline/hold rationale)
       * Key Risk Synthesis (COPE, sensor stability, regulatory violations)
       * Underwriting Directive (Clear pricing, bind authorization, reserve setting)
       * Remediation Conditions (Actionable risk engineering requirements)
  2. Consumption Endpoints:
     - FastAPI Microservice (`orchestrator/submission_api.py`): /v1/evaluate, /v1/archetypes, /v1/hotspots/california
     - Streamlit Underwriter Cockpit (`ui/dashboard.py`): 3-tab decision console designed for underwriters
```

## 3. Real-World & Synthetic Dataset Catalog, Verified Links & Project Usage

To ensure the Proof of Concept (PoC) demonstrates verifiable real-world sensor physics while fulfilling every P&C insurance underwriting requirement, the project combines **five real-world public sensor and geospatial datasets** with **three targeted synthetic data layers**.

### 3.1 Real-World Datasets & Direct Project Integration

| Dataset Layer & Role | Verified Source Links | Key Variables & Granularity | How It Helps & Exact Usage in Fire Risk AI |
| :--- | :--- | :--- | :--- |
| **1. NOAA / ASOS Regional Weather & Heatwave Baseline** (`noaa_macro_series` — Urban & Commercial Anchor) | [IEM Ukiah WUI Sep 2026](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&station=UKI&year=2026&month=09), [IEM Ukiah WUI Oct 2026](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&year=2026&month=10&mode=monthly&station=UKI), [IEM Santa Rosa Sep 2026](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&station=STS&year=2026&month=09), [IEM Sacramento Jun 2026](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&station=SMF&year=2026&month=06), [IEM Austin Sep 2026](https://mesonet.agron.iastate.edu/sites/hist.phtml?station=AUS&network=TX_ASOS), [IEM LAX Daily](https://mesonet.agron.iastate.edu/sites/hist.phtml?station=LAX&network=CA_ASOS), [IEM LAX Hourly](https://mesonet.agron.iastate.edu/sites/obhistory.php?station=LAX&network=CA_ASOS), [IEM Greensboro Sep 2026](https://mesonet.agron.iastate.edu/sites/hist.phtml?station=GSO&network=NC_ASOS) | Daily & hourly `temp_c`, `temp_min_c`, `dewpoint_c`, `rel_humidity_pct`, `wind_speed_mph`, `wind_gust_mph`, `wind_dir_deg`, `precip_mm`, `pressure_hpa`, plus derived `vpd_kpa`, `fosberg_fwi`, and `drought_kbdi_index` (291 pre-scraped rows in `noaa_real_world_iot_poc_dataset.csv`) | **1) Stage 3 Residual Baseline:** Anchors the linear regression $\widehat{\text{Panel\_Temp}}_t = \hat{\alpha} + \hat{\beta} \cdot \text{NOAA\_Temp}_t$ so `iot_sensor_agent` distinguishes outdoor heatwaves from internal electrical faults ($Z_{\text{anomaly}} > 3.0$). **2) Statewide Hotspot Ranking:** Uses the 30-station California snapshots ([Summer Peak `2026-08-02`](https://mesonet.agron.iastate.edu/sites/hist.phtml?station=JAQ&network=CA_ASOS&mode=daily&year=2026&month=8&day=02), [Autumn Heatwave `2026-10-05`](https://mesonet.agron.iastate.edu/sites/hist.phtml?station=GOO&network=CA_ASOS&mode=daily&year=2026&month=10&day=05), [Winter Baseline `2025-12-17`](https://mesonet.agron.iastate.edu/sites/hist.phtml?station=BFL&network=CA_ASOS&mode=daily&year=2025&month=12&day=17)) and [Santa Ana Red Flag Peaks](https://climateexplorer.app/articles/california-santa-ana-fire-weather-october-2026) to rank fire-prone areas. |
| **2. Interagency RAWS (Remote Automatic Weather Stations)** (`noaa_macro_series` — WUI & Foothill Fuel Extension) | [NIFC Interagency RAWS Dataset](https://data-nifc.opendata.arcgis.com/datasets/nifc::public-view-interagency-remote-automatic-weather-stations-raws/about), [NWCG Standards for Fire Weather Stations](https://raws.nifc.gov/sites/default/files/inline-files/NWCG%20Standards%20for%20Fire%20Weather%20Stations_2019_1.pdf) | Hourly wildland station telemetry across ~2,200 remote canyon/forest sites: **10-hour dead fuel stick moisture (%)**, **fuel temperature**, 20-ft wind speed/gust, solar radiation, air temperature, and relative humidity | **Solves Airport Siting Bias for WUI Policies:** While NOAA ASOS stations sit at urban/regional airports, [RAWS stations](https://data-nifc.opendata.arcgis.com/datasets/nifc::public-view-interagency-remote-automatic-weather-stations-raws/about) sit directly in wildland-urban interface (WUI) canyons and forests. Feeds `10hr_fuel_moisture_pct` into Stage 1 Hard Threshold Rules (`10hr_fuel_moisture_pct < 6%` + wind $> 25\text{ mph}$ $\rightarrow$ Critical WUI Brush Ignition Hazard). |
| **3. NIFC Perimeters & Fuel Moisture Layers** (`Phase 1: Entity & LOB Context Router`) | [NIFC Open Data Hub](https://data-nifc.opendata.arcgis.com/datasets/nifc::public-view-interagency-remote-automatic-weather-stations-raws/about), [NIFC PMS 426-3 Reference](https://raws.nifc.gov/sites/default/files/inline-files/pms426-3.pdf) | Geospatial polygons of historical burn scars, active wildfire perimeters, WUI classification tiers, and regional live/dead fuel moisture indices | **Powers Geospatial Underwriting Enrichment:** Used in Phase 1 (`Entity & LOB Context Router`) and Agent 2 (`occupancy_risk_agent` Exposure scoring) to calculate distance from the insured property to historical fire corridors and assign regional WUI exposure multipliers at policy quote/renewal. |
| **4. 2025 EN54 Indoor Fire & Electrical Cable Overload Dataset (V2)** (`property_micro_series` — Indoor Gas/PM & False-Alarm Filter) | [Mendeley Data `npk2zcm85h/2` (June 2025)](https://data.mendeley.com/datasets/npk2zcm85h/2) | **305,304 rows × 16 columns** (10-second sampling across distributed multi-sensor nodes in an EN 54 test room): `CO2`, `CO`, `H2`, `PM` (particulate matter), `air_temperature`, `rel_humidity`, `UV`, labeled across 4 real fires (including **NHXMH electrical cable overload** and beech wood) and 3 nuisance sources (`Ethanol`, `Deodorant`, `Hairspray`) | **Proves True Pre-Ignition Cable Overload vs. Nuisance Discrimination:** Maps real `CO`, `H2`, `PM`, and `air_temperature` curves into `property_micro_series` (`smoke_ppm`, `ambient_indoor_temp_c`, `gas_h2_ppm`). Allows `iot_sensor_agent` to distinguish genuine electrical insulation overheating (`H2`/`CO` surge during NHXMH cable overload) from benign indoor nuisance events (cooking ethanol or aerosol sprays), preventing false mid-term underwriting holds. |
| **5. 2026 Outdoor Smoke Detection Dataset (BME688 / BME690)** (`property_micro_series` — WUI Perimeter Plume Node) | [Mendeley Data `48j7mm8k56` (March 2026)](https://data.mendeley.com/datasets/48j7mm8k56), [Bosch Sensortec BME688/BME690 Platform](https://www.bosch-sensortec.com/en/software-tools/software/bme688-and-bme690-software/) | **131,370 annotated rows** (~51.6 hours across 20 CSVs / 5 sensing nodes) recorded 100m downwind of burning pine, olive, pine needles, and scrub vegetation under 17 metal-oxide heater profiles | **Demonstrates Perimeter Wildfire Plume Arrival in Active Monitoring:** Collapsed into a normalized `outdoor_smoke_index` channel on exterior WUI property nodes. When combined with high [RAWS](https://data-nifc.opendata.arcgis.com/datasets/nifc::public-view-interagency-remote-automatic-weather-stations-raws/about) wind speeds, it triggers an immediate mid-term Active Monitoring alert (`ΔS >= +15.0`) indicating an active smoke/ember plume within 100 meters of the insured structure. |

### 3.2 Where We Rely on Gemini-Driven Synthetic Data (and Why)

Public fire-sensing datasets ([2025 EN54](https://data.mendeley.com/datasets/npk2zcm85h/2) and [2026 BME688/690](https://data.mendeley.com/datasets/48j7mm8k56)) capture short-duration combustion experiments, whereas P&C insurance underwriting and weekly/monthly portfolio monitoring require multi-week building mechanical telemetry, insurance application forms, and localized adverse media. We bridge this gap using **Gemini-driven structured generation** anchored to real [IEM NOAA ASOS](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&station=UKI&year=2026&month=09) and [RAWS](https://data-nifc.opendata.arcgis.com/datasets/nifc::public-view-interagency-remote-automatic-weather-stations-raws/about) timelines:

> [!IMPORTANT] Realism Guardrail Policy
> All Gemini generator prompts strictly prohibit the word **"synthetic"**, placeholder disclaimer disclaimers, or raw automated denial codes from appearing in generated policy forms, website descriptions, or news text. Every artifact must read as authentic commercial documentation.

1. **Hybrid Building Mechanical & Electrical Telemetry (`data_factory/synthetic_iot_gen.py`):**
   - Gemini defines the physics regime and operational context (e.g. electrical panel vintage, load fluctuations, fault progression rates), while NumPy and SciPy synthesize the 30-to-90-day daily/hourly continuous series for `panel_temp_c`, `load_kw`, `arc_fault_count`, and `sprinkler_psi`.
   - **Why Hybrid is Required:** No public repository records 90-day synchronized fire main water pressure decay alongside sub-panel thermal drift and regional ASOS weather. Generating $\text{Panel\_Temp}_t = \alpha + \gamma \cdot \text{NOAA\_Temp}_t + \epsilon_t + \text{FaultDrift}_t$ guarantees mathematically valid cross-correlations for our Huber regressor and Isolation Forest.
2. **Gemini Structured ACORD Applications & Deceptive Company Website Text (`data_factory/synthetic_occupancy_gen.py`):**
   - Uses `google-genai` structured outputs (Pydantic schema enforcement) to emit compliant **ACORD 125/140** and **ACORD 80** JSON payloads paired with authentic-looking commercial website text.
   - **Why Gemini is Required:** Captures realistic nuances of commercial underwriting fraud and operational drift—e.g., an applicant declaring "General Merchandise Storage" on ACORD 140, while their corporate website markets "High-Density Lithium-Ion Battery Module Assembly & Laser Welding".
3. **Gemini-Driven Weather-Synced Local & Business News Feeds (`data_factory/synthetic_news_gen.py`):**
   - Uses Gemini to synthesize realistic local journalism, OSHA inspection citations, municipal water department notices, and utility transformer blowout reports within a 5-mile radius of the property, synchronized to real [NOAA Red Flag heatwave dates](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&year=2026&month=10&mode=monthly&station=UKI).

### 3.3 Canonical Hybrid Test Archetypes

1. **Archetype 1 — Benign Baseline (True Low Risk):**
   - **Real Macro Truth:** Mild coastal weather from [LAX ASOS (`KLAX`)](https://mesonet.agron.iastate.edu/sites/hist.phtml?station=LAX&network=CA_ASOS) or [Greensboro (`KGSO`)](https://mesonet.agron.iastate.edu/sites/hist.phtml?station=GSO&network=NC_ASOS) (`21°C–27°C`, `55%–80%` RH, low KBDI).
   - **Real + Synthetic Micro Data:** [EN54](https://data.mendeley.com/datasets/npk2zcm85h/2) background/nuisance trace (brief deodorant/ethanol spike cleanly rejected as non-fire); electrical panel tracks outdoor temperature smoothly ($r > 0.85$, $Z_{\text{anomaly}} < 1.0$); `sprinkler_psi` steady at `65 PSI`; ACORD shows Fire-Resistive construction with NFPA 13 sprinklers; zero adverse news.
2. **Archetype 2 — Macro Environmental WUI Surge (External High Risk):**
   - **Real Macro Truth:** Severe heatwave and Red Flag wind event from [Ukiah WUI (`KUKI` Oct 3–9, 2026)](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&year=2026&month=10&mode=monthly&station=UKI), [Twentynine Palms (`KNXP` Aug 2, 2026)](https://mesonet.agron.iastate.edu/sites/hist.phtml?station=JAQ&network=CA_ASOS&mode=daily&year=2026&month=8&day=02), or [Santa Ana Event (`KCMA` 51 mph gusts)](https://climateexplorer.app/articles/california-santa-ana-fire-weather-october-2026) paired with [RAWS](https://data-nifc.opendata.arcgis.com/datasets/nifc::public-view-interagency-remote-automatic-weather-stations-raws/about) `10hr_fuel_moisture < 5%`.
   - **Real + Synthetic Micro Data:** [2026 BME688/690 Outdoor Smoke Dataset](https://data.mendeley.com/datasets/48j7mm8k56) injects a downwind vegetation smoke plume (`100m` perimeter); building HVAC/panel load rises in correlation with outdoor heat ($Z_{\text{anomaly}} \approx 0$, proving no internal electrical fault); ACORD 80 shows wood-shake roof in a high-hazard [NIFC WUI corridor](https://raws.nifc.gov/sites/default/files/inline-files/pms426-3.pdf); news generator logs utility transformer sparks within 3 miles.
3. **Archetype 3 — Micro Internal Fault / Divergent Anomaly (Internal High Risk):**
   - **Real Macro Truth:** Cool, post-rain late-October weather from [Ukiah (`KUKI` Oct 21–31, 2026)](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&year=2026&month=10&mode=monthly&station=UKI) (`16.1°C–21.7°C`, `65%–80%` RH).
   - **Real + Synthetic Micro Data:** Despite cool outdoor weather, sub-panel temperature drifts upward $+0.85^\circ\text{C/day}$ ($Z_{\text{anomaly}}$ climbing from `9.57` to `26.04`), `arc_fault_count` exceeds 6/day, [EN54 NHXMH electrical cable overload trace](https://data.mendeley.com/datasets/npk2zcm85h/2) shows elevated `H2`/`CO` insulation outgassing, and `sprinkler_psi` drops to `28 PSI`. ACORD + URL check flags undeclared lithium-ion battery assembly; news logs an OSHA electrical citation.
4. **Archetype 4 — Mid-Term Degradation (Active Monitoring Trigger):**
   - **Submission Baseline (Day 0):** Bound at `LOW` risk (`Hazard Score = 22.0`) during benign early-September weather ([`KUKI` Sep 1–5, 2026](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&station=UKI&year=2026&month=09)).
   - **Active Monitoring Scan (Day 30 / Day 60):** Combines October WUI aridity surge + steady 30-day machinery thermal drift + municipal water main break news, pushing `final_hazard_score` by $\Delta S \ge +15.0$ and triggering an automated **Actuarial Reserving Step-Up** and **Loss Control Inspection**.

## 4. Phase 1: Input Normalization & LOB Context Router

Before dispatching the three specialist agents, the orchestrator normalizes the property entity:
- **Basic Input Resolution:** Takes `property_name`, `address`, `lob` (`COMMERCIAL` | `RESIDENTIAL`), and tentative `company_url`.
- **Geospatial Enrichment:** Resolves latitude/longitude, county FIPS code, nearest [NOAA ASOS](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&station=UKI&year=2026&month=09) and [Interagency RAWS](https://data-nifc.opendata.arcgis.com/datasets/nifc::public-view-interagency-remote-automatic-weather-stations-raws/about) weather station IDs, [NIFC Wildland-Urban Interface (WUI)](https://raws.nifc.gov/sites/default/files/inline-files/pms426-3.pdf) classification, and distance to nearest responding fire station and hydrant.
- **LOB Context Switch:**
  - `COMMERCIAL`: Loads rules for industrial machinery, high-piled storage, commercial cooking (UL-300 hood systems), hazardous materials, OSHA compliance, and ACORD 125/140 schemas.
  - `RESIDENTIAL`: Loads rules for roof age/material, electrical panel vintage (e.g., Federal Pacific, Zinsco, knob-and-tube), space heaters/wood stoves, WUI brush clearance, and ACORD 80 schemas.

## 5. Phase 2: Deep-Dive Specification of the Three Specialist Agents

### Agent 1: IoT & Environmental Sensor Agent (`iot_sensor_agent`)

**Objective:** Quantify physical and environmental ignition probability by combining robust statistical regression, multivariate unsupervised anomaly detection, and supervised tree-based classification with TreeSHAP explainability across macro weather ([NOAA ASOS](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&station=UKI&year=2026&month=09) + [RAWS](https://data-nifc.opendata.arcgis.com/datasets/nifc::public-view-interagency-remote-automatic-weather-stations-raws/about)) and micro building telemetry ([EN54](https://data.mendeley.com/datasets/npk2zcm85h/2) + [BME688/690](https://data.mendeley.com/datasets/48j7mm8k56) + synced panel/sprinkler series).

- **Inputs:**
  - `noaa_macro_series`: 30-to-90-day daily/hourly table (`temp_c`, `rel_humidity_pct`, `wind_speed_mph`, `wind_gust_mph`, `precip_mm`, `drought_kbdi_index`, `vpd_kpa`, `fosberg_fwi`, `raws_10hr_fuel_moisture_pct`, `red_flag_condition`).
  - `property_micro_series`: 30-to-90-day daily/hourly + event burst table (`panel_temp_c`, `load_kw`, `arc_fault_count`, `ambient_indoor_temp_c`, `smoke_ppm`, `en54_co_ppm`, `en54_h2_ppm`, `bme_outdoor_smoke_index`, `sprinkler_psi`).
- **5-Stage Machine Learning & Physics Pipeline:**
  1. **Hard Threshold & Suppression Safeguards:**
     - `sprinkler_psi < 40` (in sprinklered structures) $\rightarrow$ Critical Suppression Failure (`HIGH`, `is_critical_veto_candidate = True`).
     - `arc_fault_count > 5` per 24h $\rightarrow$ Acute Electrical Arcing (`HIGH`, `is_critical_veto_candidate = True`).
     - Critical WUI condition: `raws_10hr_fuel_moisture_pct < 6.0` combined with `bme_outdoor_smoke_index > 0.70` or `wind_gust_mph > 28.0` $\rightarrow$ Severe Wildland Threat (`HIGH`).
  2. **Robust Trend Analysis (Scikit-Learn `HuberRegressor`):**
     - Replaces ordinary least squares with outlier-resistant Huber M-estimation for 7-day and 30-day slope parameters ($\beta$).
     - Upward internal thermal drift ($\beta_{\text{Huber}} > +0.5^\circ\text{C/day}$) or steady sprinkler pressure decay ($\beta_{\text{Huber}} < -0.3\text{ PSI/day}$) escalates tier without being skewed by transient noise.
  3. **Multivariate Anomaly Detection (Scikit-Learn `IsolationForest` + Huber Baseline):**
     - **Huber Regression Baseline:** Fits $\widehat{\text{Panel\_Temp}}_t = \hat{\alpha} + \hat{\beta} \cdot \text{NOAA\_Temp}_t$ and derives standardized residual $Z_{\text{anomaly}} = \frac{e_t - \mu_e}{\sigma_e}$.
     - **Unsupervised Isolation Forest:** Evaluates the 5-dimensional feature space (`panel_temp_c`, `sprinkler_psi`, `arc_fault_count`, `load_kw`, `noaa_temp_c`) with contamination factor $c = 0.05$.
     - When $Z_{\text{anomaly}} > 3.0$ AND the Isolation Forest flags an anomaly (`is_outlier == -1`), the system confirms a **Critical Divergent Internal Fault** (`is_critical_veto_candidate = True`).
  4. **Supervised Sensor Classification (XGBoost / LightGBM Benchmark):**
     - Trained on the full 305,304 rows of the [2025 EN54 Dataset](https://data.mendeley.com/datasets/npk2zcm85h/2) (16 channels: $CO, H_2, CO_2, PM, \text{UV}, \text{Temp}$) and 131,370 rows of [2026 BME688](https://data.mendeley.com/datasets/48j7mm8k56).
     - Multi-class classifier distinguishes:
       - `CLASS_0_NORMAL`: Ambient baseline.
       - `CLASS_1_CABLE_OVERLOAD`: NHXMH pre-ignition insulation pyrolysis ($H_2 / CO$ surge).
       - `CLASS_2_NUISANCE_AEROSOL`: Deodorant, ethanol, hairspray ($PM$ surge without $H_2$). Suppresses false alarms.
       - `CLASS_3_VEGETATION_SMOKE`: Exterior wildfire downwind plume.
     - Serialized to `models/sensor_classifier_xgb.json` (benchmarked against `RandomForestClassifier`).
  5. **TreeSHAP Explainability (`shap`):**
     - Uses `shap.TreeExplainer` on the Stage 4 model to extract exact local feature attribution values ($\phi_i$).
     - Populates `RiskDriver.description` with mathematical attribution (e.g., "$H_2$ outgassing contributed $+42\%$ to cable overload classification, while $PM_{10}$ aerosol attribution was rejected as benign").

### Agent 2: Occupancy & COPE Risk Agent (`occupancy_risk_agent`)

**Objective:** Evaluate structural vulnerability, operational ignition sources, fuel load, and fire suppression adequacy using the insurance **COPE** framework (Construction, Occupancy, Protection, Exposure).

- **Inputs:**
  - `acord_payload`: Structured JSON or document representing **ACORD 125/140** (Commercial) or **ACORD 80** (Residential).
  - `website_scrape_text`: Scraped or synthesized company website text detailing operations, machinery, and services.
- **3-Stage Internal Pipeline:**
  1. **COPE Extraction & Scoring:**
     - *Construction:* ISO Construction Class (1 = Frame to 6 = Fire-Resistive), build year, roof condition, wiring updates.
     - *Occupancy:* Ignition sources (welding, commercial fryers, woodworking dust, kilns, spray booths) and fuel loads (plastics, flammable liquids, lithium-ion batteries, high-rack storage).
     - *Protection:* NFPA 13 wet/dry sprinkler coverage, central station fire alarm, Ansul hood suppression, fire hydrant distance ($< 500\text{ ft}$), ISO Public Protection Class (PPC 1–10).
     - *Exposure:* Neighboring industrial hazards or [NIFC WUI vegetation density](https://raws.nifc.gov/sites/default/files/inline-files/pms426-3.pdf).
  2. **Declared vs. Actual Discrepancy Check:**
     - Cross-checks ACORD occupancy description against `website_scrape_text`.
     - Undeclared high-hazard operations (e.g., applicant declares "Warehouse - General Merchandise" on ACORD 140, but URL advertises "Custom Chemical Blending & Aerosol Packaging") trigger an immediate `HIGH` risk tier and misrepresentation flag.
  3. **Suppression Deficit Matrix:**
     - High ignition/fuel load + missing or impaired sprinkler protection forces `risk_tier = HIGH` with `is_critical_veto_candidate = True`.

### Agent 3: News & External Intelligence Agent (`news_intel_agent`)

**Objective:** Detect external, behavioral, regulatory, and neighborhood fire precursors around the property and business entity.

- **Inputs:**
  - `entity_context`: Company name, property address, lat/lon coordinates, 5-mile radial bounding box.
  - `news_articles`: Timestamped synthetic or live news articles, OSHA citations, municipal code violations, and utility incident logs.
- **3-Stage Internal Pipeline:**
  1. **Entity & Geospatial Filtering:**
     - Classifies records into **Property/Company Direct Matches** vs. **Area/Neighborhood Matches** (1-to-5-mile radius).
  2. **Fire Peril Taxonomy Classification:**
     - *Physical & Regulatory Precursors:* Prior small fires, OSHA safety/electrical citations, fire marshal inspection failures.
     - *Neighborhood & Infrastructure Perils:* Serial arson activity, utility grid brownouts/transformer fires, municipal water main breaks affecting hydrant pressure, civil unrest.
     - *Moral Hazard & Distress Indicators:* Bankruptcy filings, severe litigation, mass layoffs, or abandoned neighboring structures.
  3. **Temporal Decay Weighting:**
     - Weights each event by recency using exponential decay:
       $$w(\Delta t) = e^{-\lambda \Delta t}$$
       where $\Delta t$ is days since publication, ensuring recent spikes drive active monitoring alerts while older resolved events decay.

## 6. Standardized Inter-Agent Data Contract (`schemas/contracts.py`)

All three agents return this exact Pydantic schema to guarantee deterministic downstream processing:

```python
from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, Field


class LOBType(str, Enum):
    COMMERCIAL = "COMMERCIAL"
    RESIDENTIAL = "RESIDENTIAL"


class RiskTier(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class ExecutionMode(str, Enum):
    SUBMISSION_RENEWAL = "SUBMISSION_RENEWAL"
    ACTIVE_MONITORING = "ACTIVE_MONITORING"


class RiskDriver(BaseModel):
    driver_code: str = Field(..., description="Standardized code, e.g., IOT_THERMAL_ANOMALY")
    severity: RiskTier
    is_critical_veto_candidate: bool = Field(
        default=False,
        description="True if this single finding warrants a HIGH verdict when hard_veto is enabled"
    )
    description: str = Field(..., description="Audit explanation citing exact metrics or text evidence")


class AgentVerdict(BaseModel):
    agent_id: str
    property_id: str
    lob: LOBType
    risk_tier: RiskTier
    hazard_score: float = Field(..., ge=0.0, le=100.0, description="0-35.9 LOW, 36-69.9 MEDIUM, 70-100 HIGH")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Data completeness and certainty score")
    risk_drivers: List[RiskDriver]


class BusinessImpactVerdict(BaseModel):
    property_id: str
    lob: LOBType
    execution_mode: ExecutionMode
    final_hazard_score: float
    final_risk_tier: RiskTier
    aggregate_confidence: float
    veto_triggered: bool
    score_delta_from_baseline: Optional[float] = None
    risk_avoidance_action: str
    risk_pricing_signal: str
    reserving_trigger: str
    audit_trail: List[str]
```

## 7. Phase 3: Deterministic Final Decision Layer

The Final Decision Layer (`decision_layer/verdict_calculator.py`) contains **zero LLM calls**. It executes repeatable actuarial math governed by `config/settings.yaml`.

### Configuration (`config/settings.yaml`)

```yaml
decision_engine_config:
  enable_hard_veto: true                  # Toggle: true = Hard Veto enabled, false = Pure Weighted Average
  hard_veto_confidence_threshold: 0.80
  hard_veto_floor_score: 75.0
  low_confidence_review_threshold: 0.60
  monitoring_delta_alert_threshold: 15.0  # Mid-term score increase that triggers an Active Monitoring alert
  lob_weights:
    COMMERCIAL:
      iot_sensor_agent: 0.40
      occupancy_risk_agent: 0.45
      news_intel_agent: 0.15
    RESIDENTIAL:
      iot_sensor_agent: 0.45
      occupancy_risk_agent: 0.40
      news_intel_agent: 0.15
```

### Mathematical Formulation

1. **Confidence-Weighted Base Score ($S_{\text{weighted}}$):**
   $$C_{\text{agg}} = \sum_{i \in \{\text{IoT, Occ, News}\}} W_i \cdot C_i$$
   $$S_{\text{weighted}} = \frac{\sum_{i \in \{\text{IoT, Occ, News}\}} (W_i \cdot C_i \cdot S_i)}{C_{\text{agg}}}$$

2. **Configurable Veto Override ($S_{\text{final}}$):**
   - If `enable_hard_veto == True` AND (any agent outputs `risk_tier == "HIGH"`, `confidence >= 0.80`, and has at least one `RiskDriver` with `is_critical_veto_candidate == True`), specifically confirmed when Huber residual $Z_{\text{anomaly}} > 3.0$ and Isolation Forest flag an internal fault:
     $$S_{\text{final}} = \max(S_{\text{weighted}}, 75.0)$$
   - Else:
     $$S_{\text{final}} = S_{\text{weighted}}$$

3. **Deterministic Tier Boundaries:**
   - `LOW`: $0.0 \le S_{\text{final}} < 36.0$
   - `MEDIUM`: $36.0 \le S_{\text{final}} < 70.0$
   - `HIGH`: $70.0 \le S_{\text{final}} \le 100.0$

4. **Active Monitoring Delta Check ($\Delta S$):**
   - In `ACTIVE_MONITORING` mode (weekly/monthly batch), compares current $S_{\text{final}}$ against bound baseline $S_{\text{baseline}}$:
     $$\Delta S = S_{\text{final}} - S_{\text{baseline}}$$
   - If $\Delta S \ge 15.0$ or `final_risk_tier` escalates upward, triggers an immediate mid-term intervention and reserve adjustment.

## 8. Deterministic Business Impact Matrix

| Final Verdict & State | 1. Deterministic Fire Model | 2. Risk Avoidance (Underwriting / Loss Control) | 3. Risk Pricing (Submission / Renewal) | 4. Reserving Trigger (Actuarial / Portfolio) |
| :--- | :--- | :--- | :--- | :--- |
| **LOW Tier** ($0.0 - 35.9$) | Low ignition probability; strong suppression & normal NOAA/IoT correlation | **Submission:** Auto-Bind eligible. **Active:** Routine automated monitoring only. | **Preferred Tier:** Apply $-5\%$ to $-15\%$ smart-sensor & protective credit. | **Lower Reserve Trigger:** Set IBNR fire reserve at $0.85\times$ standard LOB base factor. |
| **MEDIUM Tier** ($36.0 - 69.9$) | Moderate hazard or emerging sensor/news drift; manageable with fixes | **Submission:** Conditional Bind (require 30-day fix). **Active:** Issue automated policyholder advisory. | **Technical Debit:** Apply $+10\%$ to $+35\%$ fire peril load or raise deductible. | **Watchlist Reserve:** Hold $1.25\times$ base fire reserve until remediation is verified. |
| **HIGH Tier** ($70.0 - 100.0$) | Severe unmitigated fire hazard or critical IoT thermal/pressure anomaly | **Submission:** Auto-Decline or Pre-Bind Hold. **Active:** Dispatch emergency loss-control engineering visit. | **Distressed Load:** Apply $+50\%$ to $+150\%$ surcharge; attach protective safeguard clause. | **Higher Reserve Trigger:** Immediate actuarial step-up ($2.0\times$ base) for imminent large-loss exposure. |
| **Active Spike** ($\Delta S \ge +15.0$) | Rapid mid-term risk deterioration between weekly/monthly scans | **Active:** Flag account for underwriter intervention & mandatory sensor/site check. | **Renewal Flag:** Lock account from auto-renewal; queue for re-rating at expiration. | **Mid-Term Step-Up:** Reallocate portfolio catastrophe/attritional fire buffer immediately. |
| **Low Confidence** ($C_{\text{agg}} < 0.60$) | Insufficient telemetry or incomplete ACORD disclosures | **Information Hold:** Request missing ACORD fields or sensor reconnection before binding. | **Neutral Hold:** Withhold preferred credits; price at manual class base rate. | **Conservative Buffer:** Apply $1.35\times$ uncertainty load until data completeness clears $0.75$. |

## 9. Phased PoC Implementation Plan

### Phase 1: Data Foundation & Hybrid Synthetic Factory (Days 1–3)
- **Milestone 1.1 — Macro Weather & Fuel Ingestion (`data_factory/noaa_ingestor.py`):**
  - Load the 291-row real-world NOAA/ASOS dataset (`noaa_real_world_iot_poc_dataset.csv`) scraped from [IEM ASOS](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&station=UKI&year=2026&month=09) and [ClimateExplorer GHCNh](https://climateexplorer.app/articles/california-santa-ana-fire-weather-october-2026), and add a [RAWS 10-hour fuel stick moisture](https://data-nifc.opendata.arcgis.com/datasets/nifc::public-view-interagency-remote-automatic-weather-stations-raws/about) and [NIFC WUI exposure](https://raws.nifc.gov/sites/default/files/inline-files/pms426-3.pdf) lookup table.
- **Milestone 1.2 — Micro Sensor Benchmark Normalizer (`data_factory/micro_benchmark_loader.py`):**
  - Extract canonical time-series slices from the [2025 EN54 Indoor Fire Dataset V2](https://data.mendeley.com/datasets/npk2zcm85h/2) (specifically NHXMH electrical cable overload vs. ethanol/deodorant nuisance runs) and the [2026 BME688/BME690 Outdoor Smoke Dataset](https://data.mendeley.com/datasets/48j7mm8k56) (100m downwind vegetation smoke plumes), mapping them to normalized `en54_h2_ppm`, `en54_co_ppm`, `smoke_ppm`, and `bme_outdoor_smoke_index` columns.
- **Milestone 1.3 — NOAA-Anchored Synthetic Generator (`data_factory/scenario_builder.py`):**
  - Synthesize the missing insurance-specific channels (`panel_temp_c`, `sprinkler_psi`, `arc_fault_count`, `load_kw`), ACORD 125/140 & ACORD 80 JSONs, mock company website text, and timestamped local news for all 4 Canonical Archetypes.

### Phase 2: Specialist Agent Engines & Deterministic Math (Days 4–6)
- **Milestone 2.1 — `iot_sensor_agent` (`agents/iot_sensor_agent.py`):**
  - Integrate the verified functions from `poc_fire_risk_detector.py` (`rank_fire_prone_areas`, `detect_temporal_anomalies`, `simulate_and_detect_building_fault`) with the [EN54](https://data.mendeley.com/datasets/npk2zcm85h/2) false-alarm filter and [BME688/690](https://data.mendeley.com/datasets/48j7mm8k56) outdoor plume detector to emit a validated `AgentVerdict`.
- **Milestone 2.2 — `occupancy_risk_agent` (`agents/occupancy_risk_agent.py`):**
  - Implement deterministic COPE scoring rules plus an LLM-assisted discrepancy detector comparing declared ACORD occupancy against scraped company website text.
- **Milestone 2.3 — `news_intel_agent` (`agents/news_intel_agent.py`):**
  - Implement 5-mile radial geospatial filtering, peril taxonomy tagging (OSHA electrical violations, water main breaks, utility transformer fires), and exponential recency decay $w(\Delta t) = e^{-\lambda \Delta t}$.

### Phase 3: LangGraph Orchestrator & Deterministic Decision Layer (Days 7–8)
- **Milestone 3.1 — Pydantic Contracts & Verdict Calculator (`schemas/contracts.py`, `decision_layer/verdict_calculator.py`):**
  - Implement the zero-LLM confidence-weighted aggregation formula ($S_{\text{weighted}}$), the configurable `enable_hard_veto` override ($\max(S_{\text{weighted}}, 75.0)$), and the Active Monitoring delta check ($\Delta S \ge +15.0$).
- **Milestone 3.2 — Dual-Mode LangGraph Workflow (`orchestrator/graph.py`):**
  - Wire the Phase 1 `Entity & LOB Context Router` to fan out in parallel to all three specialist agents and fan in to the Phase 3 `BusinessImpactVerdict` mapper.

### Phase 4: API Endpoints & Interactive PoC Dashboard (Days 9–10)
- **Milestone 4.1 — FastAPI Underwriting & Cron Service (`orchestrator/submission_api.py`, `orchestrator/active_monitor_cron.py`):**
  - Expose `POST /v1/underwrite/submission` for synchronous quote evaluation and `POST /v1/monitor/batch-scan` for weekly/monthly portfolio delta scanning.
- **Milestone 4.2 — Streamlit Underwriter & Actuarial Cockpit (`ui/dashboard.py`):**
  - Build a 3-tab PoC UI:
    1. **Regional Fire Hotspot Map:** Visualizes the 30 California stations from `noaa_real_world_iot_poc_dataset.csv` across Summer Peak ([`2026-08-02`](https://mesonet.agron.iastate.edu/sites/hist.phtml?station=JAQ&network=CA_ASOS&mode=daily&year=2026&month=8&day=02)), Autumn Heatwave ([`2026-10-05`](https://mesonet.agron.iastate.edu/sites/hist.phtml?station=GOO&network=CA_ASOS&mode=daily&year=2026&month=10&day=05)), and Winter Baseline ([`2025-12-17`](https://mesonet.agron.iastate.edu/sites/hist.phtml?station=BFL&network=CA_ASOS&mode=daily&year=2025&month=12&day=17)).
    2. **Property Telemetry & Fault Inspector:** Plots [Ukiah (`KUKI`)](https://mesonet.agron.iastate.edu/sites/hist.phtml?network=CA_ASOS&year=2026&month=10&mode=monthly&station=UKI) outdoor temperature against sub-panel thermal drift ($Z_{\text{anomaly}} > 3.0$) and [EN54 cable overload vs. nuisance](https://data.mendeley.com/datasets/npk2zcm85h/2) signatures.
    3. **Underwriting & Reserving Verdict Card:** Displays the side-by-side `AgentVerdict` breakdown, Hard Veto toggle, pricing multiplier, and IBNR reserve trigger across the 4 Canonical Archetypes.

## 10. Repository Structure

```text
fire-risk-ai/
├── README.md                                # Master project guide & documentation
├── architecture_final.md                    # Master technical specification & dataset catalog
├── implementation_plan.md                   # Phased PoC execution roadmap & milestones
├── context.md                               # Active checkpoints & progress tracker
├── requirements.txt                         # Python dependencies
├── config/
│   ├── settings.yaml                        # LOB weights, hard_veto toggle, thresholds
│   └── loader.py                            # Typed YAML settings loader
├── notebooks/                               # Interactive Supervised Model Training
│   └── 01_train_sensor_classifier.ipynb     # Step-by-step EN54/BME688 ML training, benchmarking & SHAP
├── models/                                  # Serialized Machine Learning Artifacts
│   ├── sensor_classifier_xgb.json           # Trained XGBoost EN54/BME688 multi-class model
│   ├── sensor_classifier_rf.joblib          # Trained Random Forest classifier (for SHAP TreeExplainer)
│   └── iso_forest.joblib                    # Scikit-learn Isolation Forest multivariate model
├── data_factory/                            # Phase 0: Hybrid Real + Synthetic Data Factory
│   ├── noaa_real_world_iot_poc_dataset.csv  # 291 real-world scraped NOAA/ASOS station records
│   ├── noaa_ingestor.py                     # Fetches/loads real NOAA ASOS & RAWS fuel series
│   ├── micro_benchmark_loader.py            # Loads 2025 EN54 & 2026 BME688/690 real sensor slices
│   ├── synthetic_iot_gen.py                 # Generates NOAA-synced panel_temp_c, sprinkler_psi & arcs
│   ├── synthetic_occupancy_gen.py           # Generates ACORD 125/140 & ACORD 80 JSONs + mock URL text
│   ├── synthetic_news_gen.py                # Generates timestamped area & entity news articles
│   ├── scenario_builder.py                  # Bundles the 4 canonical archetypes for end-to-end testing
│   └── generated_samples/                   # Serialized archetype JSONs and telemetry CSVs
├── schemas/
│   └── contracts.py                         # Pydantic contracts (AgentVerdict, BusinessImpactVerdict, ExecutiveMemo)
├── agents/                                  # Phase 2: Specialist Agents
│   ├── poc_fire_risk_detector.py            # HuberRegressor baseline anomaly engine
│   ├── iot_sensor_agent.py                  # Rules + Huber drift + IsoForest + Supervised XGBoost + SHAP
│   ├── occupancy_risk_agent.py              # COPE parser, URL vs ACORD discrepancy checker
│   └── news_intel_agent.py                  # Geo/entity filter, peril tagger, temporal decay scorer
├── decision_layer/                          # Phase 3: Deterministic Engine
│   ├── verdict_calculator.py                # Weighted math, configurable hard veto, delta tracker
│   └── business_impact_mapper.py            # Maps scores to Avoidance, Pricing, and Reserving actions
├── orchestrator/                            # Phase 1 & 4: Execution & AI Synthesis
│   ├── graph.py                             # LangGraph StateGraph workflow & AI synthesis node
│   └── submission_api.py                    # FastAPI endpoint for Synchronous Underwriting
├── ui/
│   └── dashboard.py                         # Streamlit underwriter-centric cockpit (3 views)
└── tests/
    └── test_poc_archetypes.py               # Automated Pytest suite (6/6 tests passing)
```
